@extends('layouts.app')

@section('title', 'My Account — Bazaario')

@section('styles')
<style>
    .page-container {
        max-width: 1000px;
        margin: 0 auto;
        padding: 40px 24px;
    }
    .page-header {
        font-family: 'Fraunces', serif;
        font-size: 2.5rem;
        color: #0F172A;
        margin-bottom: 32px;
    }
    
    .tab-bar {
        display: flex;
        border-bottom: 1px solid rgba(15,23,42,0.12);
        margin-bottom: 32px;
    }
    .tab-item {
        padding: 16px 32px;
        font-weight: 600;
        color: #64748B;
        text-decoration: none;
        border-bottom: 3px solid transparent;
        font-size: 1.125rem;
    }
    .tab-item.active {
        color: #0F172A;
        border-bottom-color: #F5A623;
    }
    
    /* Layouts */
    .profile-layout { display: flex; gap: 48px; }
    .profile-sidebar { flex: 0 0 250px; text-align: center; }
    .profile-main { flex: 1; }
    
    .avatar-lg {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        background: #0F172A;
        color: white;
        font-size: 2.5rem;
        font-weight: 600;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 16px auto;
    }
    .btn-edit-photo {
        background: white;
        border: 1px solid rgba(15,23,42,0.12);
        padding: 8px 16px;
        border-radius: 9999px;
        font-size: 0.875rem;
        cursor: pointer;
    }
    
    .section-box {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 32px;
        margin-bottom: 32px;
    }
    .box-title { font-family: 'Fraunces', serif; font-size: 1.5rem; margin-bottom: 24px; color: #0F172A; }
    
    .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
    .form-group { margin-bottom: 20px; }
    .form-group.full { grid-column: 1 / -1; }
    .form-label { display: block; font-size: 0.875rem; font-weight: 500; color: #334155; margin-bottom: 8px; }
    .form-input { width: 100%; padding: 12px; border: 1px solid rgba(15,23,42,0.12); border-radius: 8px; font-family: 'Inter', sans-serif; box-sizing: border-box; }
    
    .address-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 24px; }
    .address-card { border: 1px solid rgba(15,23,42,0.12); border-radius: 8px; padding: 20px; position: relative; }
    .address-tag { position: absolute; top: 16px; right: 16px; font-size: 0.75rem; background: #F1F5F9; padding: 2px 8px; border-radius: 4px; }
    .address-card h4 { font-weight: 600; margin-bottom: 8px; }
    .address-card p { font-size: 0.875rem; color: #64748B; line-height: 1.5; margin-bottom: 16px; }
    .address-actions { display: flex; gap: 12px; }
    .address-actions button { background: none; border: none; font-size: 0.875rem; color: #F5A623; font-weight: 600; cursor: pointer; padding: 0; }
    
    .btn-add-address { display: inline-block; padding: 10px 20px; border: 1px dashed rgba(15,23,42,0.2); border-radius: 8px; color: #0F172A; font-weight: 500; text-align: center; cursor: pointer; background: transparent; }
    .btn-save { background: #F5A623; color: #1E1B16; border: none; padding: 12px 32px; border-radius: 9999px; font-weight: 600; cursor: pointer; }
    
    /* Orders Tab */
    .orders-layout { display: none; } /* toggled via JS if needed, or static demo */
    .filter-tabs { display: flex; gap: 16px; margin-bottom: 24px; }
    .filter-tab { padding: 6px 16px; border-radius: 9999px; font-size: 0.875rem; background: #F1F5F9; color: #334155; cursor: pointer; }
    .filter-tab.active { background: #0F172A; color: white; }
    
    .order-card {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 24px;
        margin-bottom: 24px;
    }
    .order-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        border-bottom: 1px solid rgba(15,23,42,0.08);
        padding-bottom: 16px;
        margin-bottom: 16px;
    }
    .order-id { font-family: 'JetBrains Mono', monospace; font-weight: 700; color: #0F172A; font-size: 1.125rem; margin-bottom: 4px; }
    .order-date { font-size: 0.875rem; color: #64748B; }
    .order-amount { font-family: 'JetBrains Mono', monospace; font-weight: 700; color: #F5A623; font-size: 1.25rem; text-align: right; }
    .order-items-count { font-size: 0.875rem; color: #64748B; text-align: right; }
    
    .order-seller-group { margin-bottom: 16px; }
    .seller-header { font-size: 0.875rem; font-weight: 600; margin-bottom: 8px; display: flex; justify-content: space-between; }
    
    .badge-green { background: #DCFCE7; color: #166534; font-size: 0.75rem; padding: 2px 8px; border-radius: 9999px; }
    .badge-amber { background: #FEF3C7; color: #92400E; font-size: 0.75rem; padding: 2px 8px; border-radius: 9999px; }
    .badge-red { background: #FEE2E2; color: #991B1B; font-size: 0.75rem; padding: 2px 8px; border-radius: 9999px; }
    
    .order-actions { display: flex; gap: 12px; margin-top: 24px; }
    .btn-action { padding: 8px 16px; border-radius: 9999px; font-size: 0.875rem; font-weight: 500; cursor: pointer; }
    .btn-action.primary { background: #0F172A; color: white; border: none; }
    .btn-action.secondary { background: transparent; border: 1px solid #0F172A; color: #0F172A; }
</style>
@endsection

@section('content')
<div class="page-container">
    <h1 class="page-header">My Account</h1>
    
    <div class="tab-bar">
        <a href="#" class="tab-item active" onclick="switchTab('profile', event)">Profile</a>
        <a href="#" class="tab-item" onclick="switchTab('orders', event)">My Orders</a>
    </div>
    
    <!-- PROFILE TAB -->
    <div id="profile-tab" class="profile-layout">
        <div class="profile-sidebar">
            <div class="avatar-lg">RS</div>
            <button class="btn-edit-photo">Edit Photo</button>
        </div>
        <div class="profile-main">
            <div class="section-box">
                <h2 class="box-title">Personal Information</h2>
                <div class="form-grid">
                    <div class="form-group full">
                        <label class="form-label">Full Name</label>
                        <input type="text" class="form-input" value="Rahul Sharma">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email Address</label>
                        <input type="email" class="form-input" value="rahul.sharma@example.com">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Phone Number</label>
                        <input type="tel" class="form-input" value="+91 98765 43210">
                    </div>
                </div>
            </div>
            
            <div class="section-box">
                <h2 class="box-title">Saved Addresses</h2>
                <div class="address-grid">
                    <div class="address-card">
                        <span class="address-tag">Home</span>
                        <h4>Rahul Sharma</h4>
                        <p>Flat 402, Sunshine Apartments<br>Koramangala 4th Block<br>Bengaluru, Karnataka 560034</p>
                        <div class="address-actions">
                            <button>Edit</button>
                            <button style="color:#EF4444;">Delete</button>
                        </div>
                    </div>
                    <div class="address-card">
                        <span class="address-tag">Work</span>
                        <h4>Rahul Sharma</h4>
                        <p>Tech Park Tower B, Level 5<br>Outer Ring Road<br>Bengaluru, Karnataka 560103</p>
                        <div class="address-actions">
                            <button>Edit</button>
                            <button style="color:#EF4444;">Delete</button>
                        </div>
                    </div>
                </div>
                <button class="btn-add-address">+ Add New Address</button>
            </div>
            
            <div class="section-box">
                <h2 class="box-title">Change Password</h2>
                <div class="form-grid">
                    <div class="form-group full">
                        <label class="form-label">Current Password</label>
                        <input type="password" class="form-input" placeholder="Enter current password">
                    </div>
                    <div class="form-group">
                        <label class="form-label">New Password</label>
                        <input type="password" class="form-input" placeholder="Enter new password">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Confirm New Password</label>
                        <input type="password" class="form-input" placeholder="Repeat new password">
                    </div>
                </div>
            </div>
            
            <button class="btn-save">Save Changes</button>
        </div>
    </div>
    
    <!-- ORDERS TAB -->
    <div id="orders-tab" class="orders-layout">
        <div class="filter-tabs">
            <div class="filter-tab active">All Orders</div>
            <div class="filter-tab">Processing</div>
            <div class="filter-tab">Delivered</div>
            <div class="filter-tab">Cancelled</div>
        </div>
        
        <!-- Order 1 -->
        <div class="order-card">
            <div class="order-header">
                <div>
                    <div class="order-id">#BZR-2024-08471</div>
                    <div class="order-date">Placed on 28 Jul 2024</div>
                </div>
                <div>
                    <div class="order-amount">₹7,509</div>
                    <div class="order-items-count">4 items from 2 sellers</div>
                </div>
            </div>
            
            <div class="order-seller-group">
                <div class="seller-header">
                    <span>The Leather Workshop (2 items)</span>
                    <span class="badge-green">Delivered</span>
                </div>
            </div>
            <div class="order-seller-group">
                <div class="seller-header">
                    <span>TechParts Direct (2 items)</span>
                    <span class="badge-amber">In Transit</span>
                </div>
            </div>
            
            <div class="order-actions">
                <button class="btn-action primary">Track Order</button>
                <button class="btn-action secondary">Leave Review</button>
            </div>
        </div>
        
        <!-- Order 2 -->
        <div class="order-card">
            <div class="order-header">
                <div>
                    <div class="order-id">#BZR-2024-07203</div>
                    <div class="order-date">Placed on 15 Jul 2024</div>
                </div>
                <div>
                    <div class="order-amount">₹1,299</div>
                    <div class="order-items-count">1 item from 1 seller</div>
                </div>
            </div>
            
            <div class="order-seller-group">
                <div class="seller-header">
                    <span>Heritage Spices (1 item)</span>
                    <span class="badge-green">Delivered</span>
                </div>
            </div>
            
            <div class="order-actions">
                <button class="btn-action secondary">Leave Review</button>
                <button class="btn-action secondary">Buy Again</button>
            </div>
        </div>
        
        <!-- Order 3 -->
        <div class="order-card">
            <div class="order-header">
                <div>
                    <div class="order-id">#BZR-2024-06890</div>
                    <div class="order-date">Placed on 3 Jul 2024</div>
                </div>
                <div>
                    <div class="order-amount">₹3,999</div>
                    <div class="order-items-count">1 item from 1 seller</div>
                </div>
            </div>
            
            <div class="order-seller-group">
                <div class="seller-header">
                    <span>Active Gear (1 item)</span>
                    <span class="badge-red">Cancelled</span>
                </div>
            </div>
        </div>
        
    </div>
</div>

<script>
    function switchTab(tab, event) {
        event.preventDefault();
        
        // Update tabs
        document.querySelectorAll('.tab-item').forEach(el => el.classList.remove('active'));
        event.target.classList.add('active');
        
        // Update content
        if (tab === 'profile') {
            document.getElementById('profile-tab').style.display = 'flex';
            document.getElementById('orders-tab').style.display = 'none';
        } else {
            document.getElementById('profile-tab').style.display = 'none';
            document.getElementById('orders-tab').style.display = 'block';
        }
    }
</script>
@endsection
