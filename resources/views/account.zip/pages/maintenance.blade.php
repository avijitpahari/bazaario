@extends('layouts.auth')

@section('title', 'Maintenance')

@section('styles')
<style>
    body { background-color: #FFFDF8; font-family: 'Inter', sans-serif; color: #1E1B16; margin: 0; padding: 0; display: flex; align-items: center; justify-content: center; min-height: 100vh; flex-direction: column; }
    .brand-logo { font-family: 'Fraunces', serif; font-size: 2rem; font-weight: 700; color: #0F172A; position: absolute; top: 2rem; text-decoration: none; }
    .brand-logo span { color: #F5A623; }
    
    .maintenance-container { text-align: center; max-width: 500px; padding: 2rem; background: #FFFFFF; border-radius: 13px; border: 1px solid rgba(15,23,42,0.12); box-shadow: 0 10px 25px rgba(0,0,0,0.05); }
    .icon { font-size: 4rem; margin-bottom: 1rem; animation: spin 10s linear infinite; display: inline-block; }
    @keyframes spin { 100% { transform: rotate(360deg); } }
    
    .title { font-family: 'Fraunces', serif; font-size: 2rem; color: #0F172A; margin: 0 0 1rem 0; }
    .desc { font-size: 1rem; color: #475569; margin: 0 0 1.5rem 0; line-height: 1.6; }
    .eta { display: inline-block; background: #fef3c7; color: #d97706; padding: 0.5rem 1rem; border-radius: 8px; font-weight: 600; font-size: 0.875rem; margin-bottom: 2rem; }
    
    .notify-form { display: flex; gap: 0.5rem; margin-top: 1rem; }
    .input-field { flex: 1; padding: 0.75rem 1rem; border: 1px solid rgba(15,23,42,0.12); border-radius: 8px; font-family: 'Inter', sans-serif; outline: none; }
    .input-field:focus { border-color: #F5A623; }
    .btn-amber { background: #F5A623; color: white; border-radius: 8px; padding: 0.75rem 1.5rem; border: none; cursor: pointer; font-weight: 600; font-family: 'Inter', sans-serif; }
    .btn-amber:hover { background: #d97706; }
</style>
@endsection

@section('content')
<a href="#" class="brand-logo">Bazaar<span>io</span></a>

<div class="maintenance-container">
    <div class="icon">⚙️</div>
    <h1 class="title">We're sprucing up the market</h1>
    <p class="desc">Bazaario is undergoing scheduled maintenance to improve your experience. We'll be back online shortly.</p>
    
    <div class="eta">Expected back: Today by 2:00 PM IST</div>
    
    <div style="text-align: left; margin-top: 1rem; border-top: 1px solid rgba(15,23,42,0.08); padding-top: 1.5rem;">
        <label style="font-weight: 500; font-size: 0.875rem; color: #0F172A;">Notify me when we're back</label>
        <form class="notify-form" action="#" method="POST" onsubmit="event.preventDefault(); alert('Thanks! We will notify you.');">
            <input type="email" class="input-field" placeholder="Enter your email" required>
            <button type="submit" class="btn-amber">Notify Me</button>
        </form>
    </div>
</div>
@endsection
