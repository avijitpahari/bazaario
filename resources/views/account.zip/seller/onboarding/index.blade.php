@extends('layouts.auth')

@section('title', 'Seller Onboarding — Bazaario')

@section('styles')
<style>
    body {
        background-color: #FFFDF8;
        color: #1E1B16;
        font-family: 'Inter', sans-serif;
    }
    h1, h2, h3, h4, h5, h6 {
        font-family: 'Fraunces', serif;
        color: #0F172A;
    }
    .mono {
        font-family: 'JetBrains Mono', monospace;
    }
    .wizard-container {
        max-width: 560px;
        margin: 40px auto;
        padding: 0 20px;
    }
    .progress-bar {
        display: flex;
        justify-content: space-between;
        margin-bottom: 40px;
        position: relative;
    }
    .progress-bar::before {
        content: '';
        position: absolute;
        top: 15px;
        left: 0;
        right: 0;
        height: 2px;
        background: rgba(15,23,42,0.12);
        z-index: 1;
    }
    .step-indicator {
        position: relative;
        z-index: 2;
        background: #FFFDF8;
        padding: 0 10px;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 8px;
    }
    .step-circle {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        background: #FFFDF8;
        border: 2px solid rgba(15,23,42,0.12);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        color: rgba(15,23,42,0.4);
    }
    .step-indicator.active .step-circle {
        background: #F5A623;
        border-color: #F5A623;
        color: #FFFDF8;
    }
    .step-indicator.completed .step-circle {
        background: #16A34A;
        border-color: #16A34A;
        color: #FFFDF8;
    }
    .step-label {
        font-size: 14px;
        font-weight: 500;
        color: rgba(15,23,42,0.6);
    }
    .step-indicator.active .step-label {
        color: #0F172A;
    }
    .card {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 32px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        color: #0F172A;
    }
    .form-control {
        width: 100%;
        padding: 12px 16px;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 8px;
        font-family: inherit;
        font-size: 15px;
        transition: border-color 0.2s;
    }
    .form-control:focus {
        outline: none;
        border-color: #F5A623;
    }
    .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 12px 24px;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
        border: none;
        font-family: inherit;
        font-size: 15px;
    }
    .btn-amber {
        background: #F5A623;
        color: #FFFFFF;
    }
    .btn-amber:hover {
        background: #e09612;
    }
    .btn-outline-slate {
        background: transparent;
        border: 1px solid #0F172A;
        color: #0F172A;
    }
    .btn-outline-slate:hover {
        background: #0F172A;
        color: #FFFFFF;
    }
    .step-panel {
        display: none;
    }
    .step-panel.active {
        display: block;
    }
    .upload-area {
        border: 2px dashed rgba(15,23,42,0.2);
        border-radius: 8px;
        padding: 40px 20px;
        text-align: center;
        cursor: pointer;
        transition: border-color 0.2s;
        margin-bottom: 20px;
    }
    .upload-area:hover {
        border-color: #F5A623;
    }
    .upload-icon {
        font-size: 32px;
        color: rgba(15,23,42,0.4);
        margin-bottom: 12px;
    }
    .success-icon {
        width: 64px;
        height: 64px;
        background: #16A34A;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 24px;
        color: white;
    }
    .success-icon svg {
        width: 32px;
        height: 32px;
    }
    .reference-box {
        background: rgba(245,166,35,0.12);
        border: 1px solid rgba(245,166,35,0.4);
        border-radius: 8px;
        padding: 16px;
        text-align: center;
        margin: 24px 0;
        color: #F5A623;
        font-size: 18px;
        font-weight: 600;
    }
    .flex-between {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
    }
    .text-center {
        text-align: center;
    }
</style>
@endsection

@section('content')
<div class="wizard-container">
    <div class="progress-bar">
        <div class="step-indicator active" id="indicator-1">
            <div class="step-circle">1</div>
            <div class="step-label">Basic Details</div>
        </div>
        <div class="step-indicator" id="indicator-2">
            <div class="step-circle">2</div>
            <div class="step-label">Shop Details</div>
        </div>
        <div class="step-indicator" id="indicator-3">
            <div class="step-circle">3</div>
            <div class="step-label">Confirmation</div>
        </div>
    </div>

    <!-- Step 1: Basic Details -->
    <div class="card step-panel active" id="step-1">
        <h2 style="margin-top: 0; margin-bottom: 24px;">Seller Application</h2>
        <div class="form-group">
            <label class="form-label">Full Name</label>
            <input type="text" class="form-control" placeholder="John Doe">
        </div>
        <div class="form-group">
            <label class="form-label">Email Address</label>
            <input type="email" class="form-control" placeholder="john@example.com">
        </div>
        <div class="form-group">
            <label class="form-label">Phone Number</label>
            <input type="tel" class="form-control" placeholder="+91 98765 43210">
        </div>
        <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" class="form-control" placeholder="••••••••">
        </div>
        <div class="form-group" style="margin-bottom: 32px;">
            <label class="form-label">Confirm Password</label>
            <input type="password" class="form-control" placeholder="••••••••">
        </div>
        <button type="button" class="btn btn-amber" style="width: 100%;" onclick="nextStep(2)">Continue</button>
    </div>

    <!-- Step 2: Shop Details -->
    <div class="card step-panel" id="step-2">
        <h2 style="margin-top: 0; margin-bottom: 24px;">Shop Details</h2>
        <div class="upload-area">
            <div class="upload-icon">📷</div>
            <div style="font-weight: 500; color: #0F172A; margin-bottom: 4px;">Upload Shop Logo</div>
            <div style="font-size: 14px; color: rgba(15,23,42,0.6);">PNG, JPG up to 2MB</div>
        </div>
        <div class="form-group">
            <label class="form-label">Shop Name</label>
            <input type="text" class="form-control" placeholder="Artisan Goods Co.">
        </div>
        <div class="form-group">
            <label class="form-label">Shop Description</label>
            <textarea class="form-control" rows="4" placeholder="Tell customers what makes your stall special..."></textarea>
        </div>
        <div class="form-group" style="margin-bottom: 32px;">
            <label class="form-label">Primary Category</label>
            <select class="form-control">
                <option value="">Select a category</option>
                <option value="accessories">Accessories</option>
                <option value="bags">Bags</option>
                <option value="apparel">Apparel</option>
                <option value="home">Home Goods</option>
            </select>
        </div>
        <div class="flex-between">
            <button type="button" class="btn btn-outline-slate" onclick="nextStep(1)">Back</button>
            <button type="button" class="btn btn-amber" onclick="nextStep(3)">Submit Application</button>
        </div>
    </div>

    <!-- Step 3: Confirmation -->
    <div class="card step-panel text-center" id="step-3">
        <div class="success-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="20 6 9 17 4 12"></polyline>
            </svg>
        </div>
        <h2 style="margin-top: 0; margin-bottom: 16px;">Application Submitted!</h2>
        <p style="color: rgba(15,23,42,0.7); line-height: 1.6; margin-bottom: 0;">
            Your seller application is under review. We'll notify you by email within 24-48 hours once approved.
        </p>
        <div class="reference-box mono">
            APP-2024-03847
        </div>
        <button type="button" class="btn btn-outline-slate" onclick="window.location.href='/'">Return to Homepage</button>
    </div>
</div>

<script>
    function nextStep(step) {
        document.querySelectorAll('.step-panel').forEach(panel => panel.classList.remove('active'));
        document.querySelectorAll('.step-indicator').forEach(indicator => indicator.classList.remove('active', 'completed'));
        
        document.getElementById('step-' + step).classList.add('active');
        
        for (let i = 1; i <= 3; i++) {
            const indicator = document.getElementById('indicator-' + i);
            if (i < step) {
                indicator.classList.add('completed');
            } else if (i === step) {
                indicator.classList.add('active');
            }
        }
    }
</script>
@endsection
