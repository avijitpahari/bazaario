@extends('layouts.seller')

@section('title', 'Dashboard — Bazaario Seller')

@section('styles')
<style>
    .page-header {
        margin-bottom: 32px;
    }
    .page-title {
        font-family: 'Fraunces', serif;
        font-size: 32px;
        color: #0F172A;
        margin: 0 0 8px 0;
    }
    .page-subtitle {
        color: rgba(15,23,42,0.6);
        font-size: 16px;
    }
    .date-badge {
        display: inline-block;
        padding: 6px 12px;
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 9999px;
        font-size: 14px;
        font-weight: 500;
        color: #0F172A;
        margin-top: 16px;
    }
    .stats-scroll {
        display: flex;
        gap: 20px;
        overflow-x: auto;
        padding-bottom: 16px;
        margin-bottom: 16px;
        scrollbar-width: none;
    }
    .stats-scroll::-webkit-scrollbar {
        display: none;
    }
    .stat-card {
        min-width: 240px;
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 24px;
    }
    .stat-label {
        font-size: 14px;
        color: rgba(15,23,42,0.6);
        margin-bottom: 12px;
        font-weight: 500;
    }
    .stat-value {
        font-family: 'JetBrains Mono', monospace;
        font-size: 28px;
        font-weight: 700;
        color: #F5A623;
        margin-bottom: 8px;
    }
    .stat-value.green {
        color: #16A34A;
    }
    .stat-trend {
        font-size: 13px;
        font-weight: 500;
    }
    .trend-up {
        color: #16A34A;
    }
    .trend-neutral {
        color: rgba(15,23,42,0.5);
    }
    .trend-alert {
        color: #F5A623;
    }
    .alert-banner {
        background: rgba(245,166,35,0.12);
        border: 1px solid rgba(245,166,35,0.4);
        border-radius: 8px;
        padding: 16px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 32px;
    }
    .alert-text {
        color: #1E1B16;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .alert-link {
        color: #F5A623;
        text-decoration: none;
        font-weight: 600;
    }
    .alert-link:hover {
        text-decoration: underline;
    }
    .table-card {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        overflow: hidden;
    }
    .table-header {
        padding: 20px 24px;
        border-bottom: 1px solid rgba(15,23,42,0.12);
    }
    .table-header h2 {
        margin: 0;
        font-size: 20px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
    }
    th {
        text-align: left;
        padding: 16px 24px;
        font-size: 13px;
        font-weight: 600;
        color: rgba(15,23,42,0.6);
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 1px solid rgba(15,23,42,0.12);
    }
    td {
        padding: 16px 24px;
        font-size: 14px;
        border-bottom: 1px solid rgba(15,23,42,0.06);
        color: #1E1B16;
    }
    tr:last-child td {
        border-bottom: none;
    }
    .mono-text {
        font-family: 'JetBrains Mono', monospace;
    }
    .pill {
        display: inline-flex;
        align-items: center;
        padding: 4px 10px;
        border-radius: 9999px;
        font-size: 12px;
        font-weight: 600;
    }
    .pill-amber {
        background: rgba(245,166,35,0.12);
        color: #d18a16;
    }
    .pill-green {
        background: rgba(22,163,74,0.12);
        color: #16A34A;
    }
    .pill-red {
        background: rgba(220,38,38,0.12);
        color: #DC2626;
    }
    .action-link {
        color: #0F172A;
        font-weight: 600;
        text-decoration: none;
    }
    .action-link:hover {
        color: #F5A623;
    }
</style>
@endsection

@section('content')
<div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 24px 40px;">
    <div class="page-header">
        <h1 class="page-title">Dashboard</h1>
        <div class="page-subtitle">Good morning, Artisan Goods Co.</div>
        <div class="date-badge">August 25, 2024</div>
    </div>

    <div class="stats-scroll">
        <div class="stat-card">
            <div class="stat-label">Orders This Week</div>
            <div class="stat-value">47</div>
            <div class="stat-trend trend-up">↑ +12% vs last week</div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Revenue This Week</div>
            <div class="stat-value">₹1,24,890</div>
            <div class="stat-trend trend-up">↑ +8% vs last week</div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Products Listed</div>
            <div class="stat-value">138</div>
            <div class="stat-trend trend-neutral">Active</div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Low Stock Items</div>
            <div class="stat-value">6</div>
            <div class="stat-trend trend-alert">⚠ Needs attention</div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Trust Score</div>
            <div class="stat-value green">94/100</div>
            <div class="stat-trend trend-up">Excellent standing</div>
        </div>
    </div>

    <div class="alert-banner">
        <div class="alert-text">
            <span style="font-size: 18px; color: #F5A623;">⚠</span>
            6 products are running low on stock. Update stock levels to avoid missed orders.
        </div>
        <a href="/seller/products?filter=low-stock" class="alert-link">View products</a>
    </div>

    <div class="table-card">
        <div class="table-header">
            <h2>Recent Orders</h2>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="mono-text" style="color: #F5A623; font-weight: 600;">#BZR-08471</td>
                    <td>Rahul S.</td>
                    <td>2 items</td>
                    <td class="mono-text">₹3,097</td>
                    <td><span class="pill pill-amber">Pending</span></td>
                    <td>25 Aug</td>
                    <td><a href="#" class="action-link">View</a></td>
                </tr>
                <tr>
                    <td class="mono-text" style="color: #F5A623; font-weight: 600;">#BZR-08469</td>
                    <td>Priya M.</td>
                    <td>1 item</td>
                    <td class="mono-text">₹1,299</td>
                    <td><span class="pill pill-amber">Packed</span></td>
                    <td>24 Aug</td>
                    <td><a href="#" class="action-link">View</a></td>
                </tr>
                <tr>
                    <td class="mono-text" style="color: #F5A623; font-weight: 600;">#BZR-08460</td>
                    <td>Arun K.</td>
                    <td>3 items</td>
                    <td class="mono-text">₹5,247</td>
                    <td><span class="pill pill-green">Shipped</span></td>
                    <td>23 Aug</td>
                    <td><a href="#" class="action-link">View</a></td>
                </tr>
                <tr>
                    <td class="mono-text" style="color: #F5A623; font-weight: 600;">#BZR-08451</td>
                    <td>Meena R.</td>
                    <td>1 item</td>
                    <td class="mono-text">₹849</td>
                    <td><span class="pill pill-green">Delivered</span></td>
                    <td>22 Aug</td>
                    <td><a href="#" class="action-link">View</a></td>
                </tr>
                <tr>
                    <td class="mono-text" style="color: #F5A623; font-weight: 600;">#BZR-08439</td>
                    <td>Vikram P.</td>
                    <td>2 items</td>
                    <td class="mono-text">₹2,198</td>
                    <td><span class="pill pill-green">Shipped</span></td>
                    <td>21 Aug</td>
                    <td><a href="#" class="action-link">View</a></td>
                </tr>
                <tr>
                    <td class="mono-text" style="color: #F5A623; font-weight: 600;">#BZR-08421</td>
                    <td>Sunita D.</td>
                    <td>4 items</td>
                    <td class="mono-text">₹7,096</td>
                    <td><span class="pill pill-green">Delivered</span></td>
                    <td>20 Aug</td>
                    <td><a href="#" class="action-link">View</a></td>
                </tr>
                <tr>
                    <td class="mono-text" style="color: #F5A623; font-weight: 600;">#BZR-08410</td>
                    <td>Arjun B.</td>
                    <td>1 item</td>
                    <td class="mono-text">₹449</td>
                    <td><span class="pill pill-red">Cancelled</span></td>
                    <td>19 Aug</td>
                    <td><a href="#" class="action-link">View</a></td>
                </tr>
                <tr>
                    <td class="mono-text" style="color: #F5A623; font-weight: 600;">#BZR-08398</td>
                    <td>Kavita L.</td>
                    <td>2 items</td>
                    <td class="mono-text">₹1,648</td>
                    <td><span class="pill pill-green">Delivered</span></td>
                    <td>18 Aug</td>
                    <td><a href="#" class="action-link">View</a></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
@endsection
