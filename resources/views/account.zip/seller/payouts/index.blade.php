@extends('layouts.seller')

@section('title', 'Payouts & Settings — Bazaario Seller')

@section('styles')
<style>
    .page-header {
        margin-bottom: 24px;
    }
    .page-title {
        font-family: 'Fraunces', serif;
        font-size: 32px;
        color: #0F172A;
        margin: 0;
    }
    .card {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        margin-bottom: 24px;
    }
    .info-card {
        border-left: 4px solid #F5A623;
        padding: 20px 24px;
    }
    .info-title {
        font-weight: 700;
        color: #0F172A;
        font-size: 16px;
        margin-bottom: 8px;
    }
    .info-text {
        color: rgba(15,23,42,0.7);
        font-size: 15px;
    }
    .stats-row {
        display: flex;
        gap: 24px;
        margin-bottom: 24px;
    }
    .stat-card {
        flex: 1;
        padding: 24px;
    }
    .stat-label {
        font-size: 14px;
        color: rgba(15,23,42,0.6);
        margin-bottom: 12px;
        font-weight: 500;
    }
    .stat-value {
        font-family: 'JetBrains Mono', monospace;
        font-size: 28px;
        font-weight: 700;
        color: #0F172A;
    }
    .stat-value.net {
        color: #16A34A;
        font-size: 32px;
    }
    .table-header {
        padding: 20px 24px;
        border-bottom: 1px solid rgba(15,23,42,0.12);
    }
    .table-header h2 {
        margin: 0;
        font-size: 20px;
        font-family: 'Fraunces', serif;
    }
    table {
        width: 100%;
        border-collapse: collapse;
    }
    th {
        text-align: left;
        padding: 16px 24px;
        font-size: 13px;
        font-weight: 600;
        color: rgba(15,23,42,0.6);
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 1px solid rgba(15,23,42,0.12);
    }
    td {
        padding: 16px 24px;
        font-size: 14px;
        border-bottom: 1px solid rgba(15,23,42,0.06);
        color: #1E1B16;
    }
    tr:last-child td {
        border-bottom: none;
    }
    .mono-text {
        font-family: 'JetBrains Mono', monospace;
    }
    .pill {
        display: inline-flex;
        align-items: center;
        padding: 4px 10px;
        border-radius: 9999px;
        font-size: 12px;
        font-weight: 600;
    }
    .pill-green {
        background: rgba(22,163,74,0.12);
        color: #16A34A;
    }
    .settings-section {
        padding: 32px;
    }
    .settings-title {
        font-family: 'Fraunces', serif;
        font-size: 20px;
        color: #0F172A;
        margin: 0 0 24px 0;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        color: #0F172A;
        font-size: 14px;
    }
    .form-control {
        width: 100%;
        padding: 12px 16px;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 8px;
        font-family: inherit;
        font-size: 15px;
        transition: border-color 0.2s;
        box-sizing: border-box;
    }
    .form-control:focus {
        outline: none;
        border-color: #F5A623;
    }
    .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 12px 24px;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
        border: none;
        font-family: inherit;
        font-size: 15px;
    }
    .btn-amber {
        background: #F5A623;
        color: #FFFFFF;
    }
    .btn-amber:hover {
        background: #e09612;
    }
</style>
@endsection

@section('content')
<div class="container" style="max-width: 1000px; margin: 0 auto; padding: 0 24px 40px;">
    <div class="page-header">
        <h1 class="page-title">Payouts & Settings</h1>
    </div>

    <div class="card info-card">
        <div class="info-title">Platform Commission Rate: 8% per transaction</div>
        <div class="info-text">For every ₹100 sale, ₹8 is retained as platform commission. Your net payout is ₹92.</div>
    </div>

    <div class="stats-row">
        <div class="card stat-card">
            <div class="stat-label">Gross Sales (this month)</div>
            <div class="stat-value">₹1,24,890</div>
        </div>
        <div class="card stat-card">
            <div class="stat-label">Commission Deducted (8%)</div>
            <div class="stat-value" style="color: #DC2626;">-₹9,991</div>
        </div>
        <div class="card stat-card">
            <div class="stat-label">Net Payout</div>
            <div class="stat-value net">₹1,14,899</div>
        </div>
    </div>

    <div class="card">
        <div class="table-header">
            <h2>Payout History</h2>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Payout ID</th>
                    <th>Period</th>
                    <th>Gross</th>
                    <th>Commission</th>
                    <th>Net</th>
                    <th>Status</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="mono-text" style="color: #F5A623; font-weight: 600;">#PAY-4821</td>
                    <td>Aug 1-15</td>
                    <td class="mono-text">₹62,450</td>
                    <td class="mono-text" style="color: #DC2626;">₹4,996</td>
                    <td class="mono-text" style="font-weight: 600;">₹57,454</td>
                    <td><span class="pill pill-green">Paid</span></td>
                    <td>17 Aug</td>
                </tr>
                <tr>
                    <td class="mono-text" style="color: #F5A623; font-weight: 600;">#PAY-4736</td>
                    <td>Jul 16-31</td>
                    <td class="mono-text">₹71,200</td>
                    <td class="mono-text" style="color: #DC2626;">₹5,696</td>
                    <td class="mono-text" style="font-weight: 600;">₹65,504</td>
                    <td><span class="pill pill-green">Paid</span></td>
                    <td>1 Aug</td>
                </tr>
                <tr>
                    <td class="mono-text" style="color: #F5A623; font-weight: 600;">#PAY-4651</td>
                    <td>Jul 1-15</td>
                    <td class="mono-text">₹53,890</td>
                    <td class="mono-text" style="color: #DC2626;">₹4,311</td>
                    <td class="mono-text" style="font-weight: 600;">₹49,579</td>
                    <td><span class="pill pill-green">Paid</span></td>
                    <td>16 Jul</td>
                </tr>
                <tr>
                    <td class="mono-text" style="color: #F5A623; font-weight: 600;">#PAY-4560</td>
                    <td>Jun 16-30</td>
                    <td class="mono-text">₹48,320</td>
                    <td class="mono-text" style="color: #DC2626;">₹3,866</td>
                    <td class="mono-text" style="font-weight: 600;">₹44,454</td>
                    <td><span class="pill pill-green">Paid</span></td>
                    <td>1 Jul</td>
                </tr>
                <tr>
                    <td class="mono-text" style="color: #F5A623; font-weight: 600;">#PAY-4481</td>
                    <td>Jun 1-15</td>
                    <td class="mono-text">₹67,110</td>
                    <td class="mono-text" style="color: #DC2626;">₹5,369</td>
                    <td class="mono-text" style="font-weight: 600;">₹61,741</td>
                    <td><span class="pill pill-green">Paid</span></td>
                    <td>16 Jun</td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="card settings-section">
        <h2 class="settings-title">Shop Profile</h2>
        <div class="form-group">
            <label class="form-label">Shop Name</label>
            <input type="text" class="form-control" value="Artisan Goods Co.">
        </div>
        <div class="form-group">
            <label class="form-label">Tagline</label>
            <input type="text" class="form-control" value="Handcrafted leather goods for everyday use">
        </div>
        <div class="form-group">
            <label class="form-label">Description</label>
            <textarea class="form-control" rows="4">We specialize in creating premium, handcrafted leather goods. Every item is stitched by hand using traditional techniques and the finest full-grain leather sourced directly from local tanneries.</textarea>
        </div>
        <div class="form-group" style="margin-bottom: 24px;">
            <label class="form-label">Category</label>
            <select class="form-control">
                <option value="accessories" selected>Accessories</option>
                <option value="bags">Bags</option>
                <option value="apparel">Apparel</option>
                <option value="home">Home Goods</option>
            </select>
        </div>
        <button type="button" class="btn btn-amber">Save Changes</button>
    </div>

    <div class="card settings-section">
        <h2 class="settings-title">Security Settings</h2>
        <div class="form-group">
            <label class="form-label">Current Password</label>
            <input type="password" class="form-control" placeholder="••••••••">
        </div>
        <div class="form-group">
            <label class="form-label">New Password</label>
            <input type="password" class="form-control" placeholder="••••••••">
        </div>
        <div class="form-group" style="margin-bottom: 24px;">
            <label class="form-label">Confirm New Password</label>
            <input type="password" class="form-control" placeholder="••••••••">
        </div>
        <button type="button" class="btn btn-amber">Update Password</button>
    </div>
</div>
@endsection
