@extends('layouts.seller')

@section('title', 'Orders — Bazaario Seller')

@section('styles')
<style>
    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
    }
    .page-title {
        font-family: 'Fraunces', serif;
        font-size: 32px;
        color: #0F172A;
        margin: 0;
    }
    .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 8px 16px;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
        border: none;
        font-family: inherit;
        font-size: 14px;
        text-decoration: none;
    }
    .btn-amber {
        background: #F5A623;
        color: #FFFFFF;
    }
    .btn-amber:hover {
        background: #e09612;
    }
    .btn-outline-slate {
        background: transparent;
        border: 1px solid #0F172A;
        color: #0F172A;
    }
    .btn-outline-slate:hover {
        background: #0F172A;
        color: #FFFFFF;
    }
    .tabs {
        display: flex;
        gap: 8px;
        margin-bottom: 24px;
        overflow-x: auto;
        padding-bottom: 4px;
    }
    .tab-pill {
        padding: 8px 16px;
        border-radius: 9999px;
        font-weight: 600;
        font-size: 14px;
        color: rgba(15,23,42,0.6);
        background: transparent;
        cursor: pointer;
        white-space: nowrap;
    }
    .tab-pill.active {
        background: rgba(245,166,35,0.12);
        color: #F5A623;
        border-bottom: 2px solid #F5A623;
        border-radius: 9999px 9999px 0 0;
    }
    .tab-pill:hover:not(.active) {
        background: rgba(15,23,42,0.04);
        color: #0F172A;
    }
    .orders-grid {
        display: grid;
        gap: 20px;
    }
    .order-card {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 24px;
    }
    .order-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        padding-bottom: 16px;
        border-bottom: 1px solid rgba(15,23,42,0.08);
    }
    .order-id {
        font-family: 'JetBrains Mono', monospace;
        font-size: 16px;
        font-weight: 700;
        color: #F5A623;
    }
    .order-customer {
        font-weight: 600;
        color: #0F172A;
        margin-left: 12px;
    }
    .order-date {
        color: rgba(15,23,42,0.5);
        font-size: 14px;
        margin-left: 12px;
    }
    .status-pill {
        display: inline-flex;
        align-items: center;
        padding: 4px 10px;
        border-radius: 9999px;
        font-size: 12px;
        font-weight: 600;
    }
    .status-pending { background: rgba(245,166,35,0.12); color: #d18a16; }
    .status-packed { background: rgba(59,130,246,0.12); color: #3B82F6; }
    .status-shipped { background: rgba(139,92,246,0.12); color: #8B5CF6; }
    .status-delivered { background: rgba(22,163,74,0.12); color: #16A34A; }
    .status-cancelled { background: rgba(220,38,38,0.12); color: #DC2626; }
    .order-items {
        margin-bottom: 20px;
        color: #1E1B16;
        font-size: 15px;
    }
    .order-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .order-total {
        font-family: 'JetBrains Mono', monospace;
        font-size: 20px;
        font-weight: 700;
        color: #0F172A;
    }
    .order-actions {
        display: flex;
        gap: 12px;
    }
</style>
@endsection

@section('content')
<div class="container" style="max-width: 1000px; margin: 0 auto; padding: 0 24px 40px;">
    <div class="page-header">
        <h1 class="page-title">Orders</h1>
        <button class="btn btn-outline-slate">Export CSV</button>
    </div>

    <div class="tabs">
        <div class="tab-pill active">All (32)</div>
        <div class="tab-pill">Pending (8)</div>
        <div class="tab-pill">Packed (5)</div>
        <div class="tab-pill">Shipped (12)</div>
        <div class="tab-pill">Delivered (95)</div>
        <div class="tab-pill">Cancelled (4)</div>
    </div>

    <div class="orders-grid">
        <!-- Order 1 -->
        <div class="order-card">
            <div class="order-header">
                <div>
                    <span class="order-id">#BZR-08471</span>
                    <span class="order-customer">Rahul S.</span>
                    <span class="order-date">25 Aug</span>
                </div>
                <span class="status-pill status-pending">Pending</span>
            </div>
            <div class="order-items">
                Wallet &times;1 + Card Holder &times;2
            </div>
            <div class="order-footer">
                <div class="order-total">₹3,097</div>
                <div class="order-actions">
                    <button class="btn btn-outline-slate">View Details</button>
                    <button class="btn btn-amber">Mark as Packed</button>
                </div>
            </div>
        </div>

        <!-- Order 2 -->
        <div class="order-card">
            <div class="order-header">
                <div>
                    <span class="order-id">#BZR-08469</span>
                    <span class="order-customer">Priya M.</span>
                    <span class="order-date">24 Aug</span>
                </div>
                <span class="status-pill status-packed">Packed</span>
            </div>
            <div class="order-items">
                Wallet &times;1
            </div>
            <div class="order-footer">
                <div class="order-total">₹1,299</div>
                <div class="order-actions">
                    <button class="btn btn-outline-slate">View Details</button>
                    <button class="btn btn-amber">Mark as Shipped</button>
                </div>
            </div>
        </div>

        <!-- Order 3 -->
        <div class="order-card">
            <div class="order-header">
                <div>
                    <span class="order-id">#BZR-08460</span>
                    <span class="order-customer">Arun K.</span>
                    <span class="order-date">23 Aug</span>
                </div>
                <span class="status-pill status-shipped">Shipped</span>
            </div>
            <div class="order-items">
                Belt &times;1 + Bag &times;1 + Strap &times;1
            </div>
            <div class="order-footer">
                <div class="order-total">₹7,597</div>
                <div class="order-actions">
                    <button class="btn btn-outline-slate">View Details</button>
                    <button class="btn btn-amber">Mark as Delivered</button>
                </div>
            </div>
        </div>

        <!-- Order 4 -->
        <div class="order-card">
            <div class="order-header">
                <div>
                    <span class="order-id">#BZR-08451</span>
                    <span class="order-customer">Meena R.</span>
                    <span class="order-date">22 Aug</span>
                </div>
                <span class="status-pill status-delivered">Delivered</span>
            </div>
            <div class="order-items">
                Cutting Board &times;1
            </div>
            <div class="order-footer">
                <div class="order-total">₹849</div>
                <div class="order-actions">
                    <button class="btn btn-outline-slate">View Details</button>
                </div>
            </div>
        </div>

        <!-- Order 5 -->
        <div class="order-card">
            <div class="order-header">
                <div>
                    <span class="order-id">#BZR-08439</span>
                    <span class="order-customer">Vikram P.</span>
                    <span class="order-date">21 Aug</span>
                </div>
                <span class="status-pill status-shipped">Shipped</span>
            </div>
            <div class="order-items">
                Passport Cover &times;2
            </div>
            <div class="order-footer">
                <div class="order-total">₹1,298</div>
                <div class="order-actions">
                    <button class="btn btn-outline-slate">View Details</button>
                    <button class="btn btn-amber">Mark as Delivered</button>
                </div>
            </div>
        </div>

        <!-- Order 6 -->
        <div class="order-card">
            <div class="order-header">
                <div>
                    <span class="order-id">#BZR-08421</span>
                    <span class="order-customer">Sunita D.</span>
                    <span class="order-date">20 Aug</span>
                </div>
                <span class="status-pill status-delivered">Delivered</span>
            </div>
            <div class="order-items">
                Messenger Bag &times;1
            </div>
            <div class="order-footer">
                <div class="order-total">₹4,999</div>
                <div class="order-actions">
                    <button class="btn btn-outline-slate">View Details</button>
                </div>
            </div>
        </div>

        <!-- Order 7 -->
        <div class="order-card">
            <div class="order-header">
                <div>
                    <span class="order-id">#BZR-08410</span>
                    <span class="order-customer">Arjun B.</span>
                    <span class="order-date">19 Aug</span>
                </div>
                <span class="status-pill status-cancelled">Cancelled</span>
            </div>
            <div class="order-items">
                Keychain Set &times;1
            </div>
            <div class="order-footer">
                <div class="order-total">₹299</div>
                <div class="order-actions">
                    <button class="btn btn-outline-slate">View Details</button>
                </div>
            </div>
        </div>

        <!-- Order 8 -->
        <div class="order-card">
            <div class="order-header">
                <div>
                    <span class="order-id">#BZR-08398</span>
                    <span class="order-customer">Kavita L.</span>
                    <span class="order-date">18 Aug</span>
                </div>
                <span class="status-pill status-delivered">Delivered</span>
            </div>
            <div class="order-items">
                Journal Cover &times;2
            </div>
            <div class="order-footer">
                <div class="order-total">₹2,198</div>
                <div class="order-actions">
                    <button class="btn btn-outline-slate">View Details</button>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
