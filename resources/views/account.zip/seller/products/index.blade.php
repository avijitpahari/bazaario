@extends('layouts.seller')

@section('title', 'Products — Bazaario Seller')

@section('styles')
<style>
    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
    }
    .page-title {
        font-family: 'Fraunces', serif;
        font-size: 32px;
        color: #0F172A;
        margin: 0;
    }
    .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 10px 20px;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
        border: none;
        font-family: inherit;
        font-size: 14px;
        text-decoration: none;
    }
    .btn-amber {
        background: #F5A623;
        color: #FFFFFF;
    }
    .btn-amber:hover {
        background: #e09612;
    }
    .filters-bar {
        display: flex;
        gap: 16px;
        margin-bottom: 24px;
    }
    .form-control {
        padding: 10px 16px;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 8px;
        font-family: inherit;
        font-size: 14px;
        background: #FFFFFF;
        min-width: 200px;
    }
    .form-control:focus {
        outline: none;
        border-color: #F5A623;
    }
    .search-input {
        flex: 1;
    }
    .table-card {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        overflow: hidden;
        margin-bottom: 24px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
    }
    th {
        text-align: left;
        padding: 16px;
        font-size: 13px;
        font-weight: 600;
        color: rgba(15,23,42,0.6);
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 1px solid rgba(15,23,42,0.12);
    }
    td {
        padding: 16px;
        font-size: 14px;
        border-bottom: 1px solid rgba(15,23,42,0.06);
        color: #1E1B16;
        vertical-align: middle;
    }
    tr:last-child td {
        border-bottom: none;
    }
    .img-placeholder {
        width: 40px;
        height: 40px;
        background: rgba(15,23,42,0.08);
        border-radius: 6px;
        display: inline-block;
    }
    .mono-text {
        font-family: 'JetBrains Mono', monospace;
    }
    .pill {
        display: inline-flex;
        align-items: center;
        padding: 4px 10px;
        border-radius: 9999px;
        font-size: 12px;
        font-weight: 600;
    }
    .pill-green {
        background: rgba(22,163,74,0.12);
        color: #16A34A;
    }
    .pill-amber {
        background: rgba(245,166,35,0.12);
        color: #d18a16;
    }
    .pill-red {
        background: rgba(220,38,38,0.12);
        color: #DC2626;
    }
    .pill-slate {
        background: rgba(15,23,42,0.08);
        color: #0F172A;
    }
    .actions {
        color: #0F172A;
        font-weight: 500;
    }
    .actions a {
        color: inherit;
        text-decoration: none;
    }
    .actions a:hover {
        color: #F5A623;
    }
    .pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 8px;
    }
    .page-btn {
        padding: 8px 12px;
        border: 1px solid rgba(15,23,42,0.12);
        background: #FFFFFF;
        border-radius: 6px;
        color: #0F172A;
        font-weight: 500;
        font-size: 14px;
        cursor: pointer;
        text-decoration: none;
    }
    .page-btn.active {
        background: #0F172A;
        color: #FFFFFF;
        border-color: #0F172A;
    }
    .page-btn:hover:not(.active) {
        border-color: #0F172A;
    }
</style>
@endsection

@section('content')
<div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 24px 40px;">
    <div class="page-header">
        <h1 class="page-title">My Products</h1>
        <a href="/seller/products/create" class="btn btn-amber">Add Product</a>
    </div>

    <div class="filters-bar">
        <input type="text" class="form-control search-input" placeholder="Search products...">
        <select class="form-control">
            <option value="all">All Statuses</option>
            <option value="active">Active</option>
            <option value="draft">Draft</option>
            <option value="out_of_stock">Out of Stock</option>
        </select>
        <select class="form-control">
            <option value="all">All Categories</option>
            <option value="accessories">Accessories</option>
            <option value="bags">Bags</option>
            <option value="travel">Travel</option>
            <option value="tech">Tech</option>
            <option value="stationery">Stationery</option>
        </select>
    </div>

    <div class="table-card">
        <table>
            <thead>
                <tr>
                    <th style="width: 40px;"><input type="checkbox"></th>
                    <th style="width: 60px;">Image</th>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Stock</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><input type="checkbox"></td>
                    <td><div class="img-placeholder"></div></td>
                    <td style="font-weight: 500;">Handstitched Leather Wallet</td>
                    <td>Accessories</td>
                    <td class="mono-text">82</td>
                    <td class="mono-text">₹1,299</td>
                    <td><span class="pill pill-green">Active</span></td>
                    <td class="actions"><a href="#">Edit</a> · <a href="#">Delete</a></td>
                </tr>
                <tr>
                    <td><input type="checkbox"></td>
                    <td><div class="img-placeholder"></div></td>
                    <td style="font-weight: 500;">Leather Card Holder</td>
                    <td>Accessories</td>
                    <td class="mono-text">45</td>
                    <td class="mono-text">₹899</td>
                    <td><span class="pill pill-green">Active</span></td>
                    <td class="actions"><a href="#">Edit</a> · <a href="#">Delete</a></td>
                </tr>
                <tr>
                    <td><input type="checkbox"></td>
                    <td><div class="img-placeholder"></div></td>
                    <td style="font-weight: 500;">Full-Grain Leather Belt</td>
                    <td>Accessories</td>
                    <td class="mono-text">12</td>
                    <td class="mono-text">₹1,799</td>
                    <td><span class="pill pill-green">Active</span></td>
                    <td class="actions"><a href="#">Edit</a> · <a href="#">Delete</a></td>
                </tr>
                <tr>
                    <td><input type="checkbox"></td>
                    <td><div class="img-placeholder"></div></td>
                    <td style="font-weight: 500;">Leather Passport Cover</td>
                    <td>Travel</td>
                    <td class="mono-text" style="color: #F5A623;">6</td>
                    <td class="mono-text">₹649</td>
                    <td><span class="pill pill-amber">Low Stock</span></td>
                    <td class="actions"><a href="#">Edit</a> · <a href="#">Delete</a></td>
                </tr>
                <tr>
                    <td><input type="checkbox"></td>
                    <td><div class="img-placeholder"></div></td>
                    <td style="font-weight: 500;">Leather Laptop Sleeve 13"</td>
                    <td>Tech</td>
                    <td class="mono-text" style="color: #DC2626;">0</td>
                    <td class="mono-text">₹2,499</td>
                    <td><span class="pill pill-red">Out of Stock</span></td>
                    <td class="actions"><a href="#">Edit</a> · <a href="#">Delete</a></td>
                </tr>
                <tr>
                    <td><input type="checkbox"></td>
                    <td><div class="img-placeholder"></div></td>
                    <td style="font-weight: 500;">Leather Messenger Bag</td>
                    <td>Bags</td>
                    <td class="mono-text">28</td>
                    <td class="mono-text">₹4,999</td>
                    <td><span class="pill pill-green">Active</span></td>
                    <td class="actions"><a href="#">Edit</a> · <a href="#">Delete</a></td>
                </tr>
                <tr>
                    <td><input type="checkbox"></td>
                    <td><div class="img-placeholder"></div></td>
                    <td style="font-weight: 500;">Suede Coin Purse</td>
                    <td>Accessories</td>
                    <td class="mono-text" style="color: #F5A623;">3</td>
                    <td class="mono-text">₹549</td>
                    <td><span class="pill pill-amber">Low Stock</span></td>
                    <td class="actions"><a href="#">Edit</a> · <a href="#">Delete</a></td>
                </tr>
                <tr>
                    <td><input type="checkbox"></td>
                    <td><div class="img-placeholder"></div></td>
                    <td style="font-weight: 500;">Leather Watch Strap</td>
                    <td>Accessories</td>
                    <td class="mono-text">54</td>
                    <td class="mono-text">₹799</td>
                    <td><span class="pill pill-green">Active</span></td>
                    <td class="actions"><a href="#">Edit</a> · <a href="#">Delete</a></td>
                </tr>
                <tr>
                    <td><input type="checkbox"></td>
                    <td><div class="img-placeholder"></div></td>
                    <td style="font-weight: 500;">Leather Keychain Set</td>
                    <td>Accessories</td>
                    <td class="mono-text">0</td>
                    <td class="mono-text">₹299</td>
                    <td><span class="pill pill-slate">Draft</span></td>
                    <td class="actions"><a href="#">Edit</a> · <a href="#">Delete</a></td>
                </tr>
                <tr>
                    <td><input type="checkbox"></td>
                    <td><div class="img-placeholder"></div></td>
                    <td style="font-weight: 500;">Leather Journal Cover</td>
                    <td>Stationery</td>
                    <td class="mono-text">19</td>
                    <td class="mono-text">₹1,099</td>
                    <td><span class="pill pill-green">Active</span></td>
                    <td class="actions"><a href="#">Edit</a> · <a href="#">Delete</a></td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="pagination">
        <a href="#" class="page-btn">Previous</a>
        <a href="#" class="page-btn active">1</a>
        <a href="#" class="page-btn">2</a>
        <a href="#" class="page-btn">3</a>
        <a href="#" class="page-btn">Next</a>
    </div>
</div>
@endsection
