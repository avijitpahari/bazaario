@extends('layouts.seller')

@section('title', 'Add Product — Bazaario Seller')

@section('styles')
<style>
    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
    }
    .page-title {
        font-family: 'Fraunces', serif;
        font-size: 32px;
        color: #0F172A;
        margin: 0;
    }
    .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 10px 20px;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
        border: none;
        font-family: inherit;
        font-size: 14px;
        text-decoration: none;
    }
    .btn-amber {
        background: #F5A623;
        color: #FFFFFF;
    }
    .btn-amber:hover {
        background: #e09612;
    }
    .btn-outline-slate {
        background: transparent;
        border: 1px solid #0F172A;
        color: #0F172A;
    }
    .btn-outline-slate:hover {
        background: #0F172A;
        color: #FFFFFF;
    }
    .header-actions {
        display: flex;
        gap: 12px;
    }
    .form-card {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 32px;
        margin-bottom: 24px;
    }
    .card-title {
        font-family: 'Fraunces', serif;
        font-size: 20px;
        color: #0F172A;
        margin: 0 0 24px 0;
    }
    .upload-main {
        height: 300px;
        border: 2px dashed rgba(15,23,42,0.2);
        border-radius: 12px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s;
        margin-bottom: 16px;
    }
    .upload-main:hover {
        border-color: #F5A623;
        background: rgba(245,166,35,0.02);
    }
    .upload-icon {
        font-size: 40px;
        color: rgba(15,23,42,0.3);
        margin-bottom: 16px;
    }
    .upload-text-primary {
        font-weight: 600;
        color: #0F172A;
        margin-bottom: 8px;
        font-size: 16px;
    }
    .upload-text-secondary {
        font-size: 14px;
        color: rgba(15,23,42,0.5);
    }
    .thumbnails {
        display: flex;
        gap: 16px;
    }
    .thumbnail-slot {
        width: 80px;
        height: 80px;
        border: 2px dashed rgba(15,23,42,0.2);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
    }
    .form-group {
        margin-bottom: 24px;
    }
    .form-row {
        display: flex;
        gap: 24px;
        margin-bottom: 24px;
    }
    .form-row .form-group {
        flex: 1;
        margin-bottom: 0;
    }
    .form-label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        color: #0F172A;
        font-size: 14px;
    }
    .form-control {
        width: 100%;
        padding: 12px 16px;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 8px;
        font-family: inherit;
        font-size: 15px;
        transition: border-color 0.2s;
        box-sizing: border-box;
    }
    .form-control:focus {
        outline: none;
        border-color: #F5A623;
    }
    .input-with-prefix {
        position: relative;
    }
    .input-prefix {
        position: absolute;
        left: 16px;
        top: 50%;
        transform: translateY(-50%);
        color: rgba(15,23,42,0.5);
        font-family: 'JetBrains Mono', monospace;
    }
    .input-with-prefix .form-control {
        padding-left: 36px;
    }
    .toggle-container {
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .toggle-switch {
        position: relative;
        width: 44px;
        height: 24px;
        background: rgba(15,23,42,0.12);
        border-radius: 9999px;
        cursor: pointer;
        transition: all 0.2s;
    }
    .toggle-switch::after {
        content: '';
        position: absolute;
        width: 18px;
        height: 18px;
        background: #FFFFFF;
        border-radius: 50%;
        top: 3px;
        left: 3px;
        transition: all 0.2s;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .toggle-switch.active {
        background: #16A34A;
    }
    .toggle-switch.active::after {
        left: 23px;
    }
    .sticky-bottom {
        position: fixed;
        bottom: 0;
        left: 64px;
        right: 0;
        background: #FFFFFF;
        border-top: 1px solid rgba(15,23,42,0.12);
        padding: 16px 40px;
        display: flex;
        justify-content: flex-end;
        gap: 16px;
        z-index: 100;
        box-shadow: 0 -4px 12px rgba(0,0,0,0.03);
    }
</style>
@endsection

@section('content')
<div class="container" style="max-width: 800px; margin: 0 auto; padding: 0 24px 100px;">
    <div class="page-header">
        <h1 class="page-title">Add New Product</h1>
        <div class="header-actions">
            <button type="button" class="btn btn-outline-slate">Save as Draft</button>
            <button type="button" class="btn btn-amber">Publish</button>
        </div>
    </div>

    <div class="form-card">
        <h2 class="card-title">Product Images</h2>
        <div class="upload-main">
            <div class="upload-icon">📷</div>
            <div class="upload-text-primary">Drag & drop or click to upload</div>
            <div class="upload-text-secondary">Up to 8 images · PNG, JPG up to 5MB</div>
        </div>
        <div class="thumbnails">
            <div class="thumbnail-slot"><span style="color: rgba(15,23,42,0.3); font-size: 20px;">+</span></div>
            <div class="thumbnail-slot"><span style="color: rgba(15,23,42,0.3); font-size: 20px;">+</span></div>
            <div class="thumbnail-slot"><span style="color: rgba(15,23,42,0.3); font-size: 20px;">+</span></div>
        </div>
    </div>

    <div class="form-card">
        <h2 class="card-title">Basic Details</h2>
        <div class="form-group">
            <label class="form-label">Product Name *</label>
            <input type="text" class="form-control" placeholder="e.g. Handstitched Leather Wallet">
        </div>
        <div class="form-group">
            <label class="form-label">Category *</label>
            <select class="form-control">
                <option value="">Select a category</option>
                <option value="accessories">Accessories</option>
                <option value="bags">Bags</option>
                <option value="travel">Travel</option>
                <option value="tech">Tech</option>
                <option value="stationery">Stationery</option>
                <option value="other">Other</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Description *</label>
            <div style="border: 1px solid rgba(15,23,42,0.12); border-radius: 8px 8px 0 0; padding: 8px 16px; border-bottom: none; background: rgba(15,23,42,0.02); display: flex; gap: 12px; color: rgba(15,23,42,0.6);">
                <span style="font-weight: bold; cursor: pointer;">B</span>
                <span style="font-style: italic; cursor: pointer;">I</span>
                <span style="text-decoration: underline; cursor: pointer;">U</span>
                <span style="margin-left: 12px; cursor: pointer;">≣</span>
            </div>
            <textarea class="form-control" rows="4" style="border-radius: 0 0 8px 8px;" placeholder="Describe your product..."></textarea>
        </div>
        <div class="form-group">
            <label class="form-label">Tags</label>
            <input type="text" class="form-control" placeholder="leather, wallet, handmade, gift (comma separated)">
        </div>
    </div>

    <div class="form-card">
        <h2 class="card-title">Pricing & Stock</h2>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Price *</label>
                <div class="input-with-prefix">
                    <span class="input-prefix">₹</span>
                    <input type="number" class="form-control" placeholder="0.00" style="font-family: 'JetBrains Mono', monospace;">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Compare-at Price</label>
                <div class="input-with-prefix">
                    <span class="input-prefix">₹</span>
                    <input type="number" class="form-control" placeholder="0.00" style="font-family: 'JetBrains Mono', monospace;">
                </div>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Stock Quantity *</label>
                <input type="number" class="form-control" placeholder="0" style="font-family: 'JetBrains Mono', monospace;">
            </div>
            <div class="form-group">
                <label class="form-label">SKU (Optional)</label>
                <input type="text" class="form-control" placeholder="e.g. LTH-WAL-001">
            </div>
            <div class="form-group">
                <label class="form-label">Low Stock Alert at</label>
                <input type="number" class="form-control" value="5" style="font-family: 'JetBrains Mono', monospace;">
            </div>
        </div>
    </div>

    <div class="form-card">
        <h2 class="card-title">Shipping</h2>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Weight (grams)</label>
                <input type="number" class="form-control" placeholder="0">
            </div>
            <div class="form-group" style="flex: 2;">
                <label class="form-label">Dimensions (L × W × H in cm)</label>
                <div style="display: flex; gap: 8px;">
                    <input type="number" class="form-control" placeholder="L">
                    <input type="number" class="form-control" placeholder="W">
                    <input type="number" class="form-control" placeholder="H">
                </div>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Processing Time</label>
                <select class="form-control">
                    <option value="1-2">1-2 days</option>
                    <option value="3-5">3-5 days</option>
                    <option value="7+">1 week+</option>
                </select>
            </div>
            <div class="form-group" style="display: flex; align-items: flex-end;">
                <div class="toggle-container" style="padding-bottom: 12px;">
                    <div class="toggle-switch" onclick="this.classList.toggle('active')"></div>
                    <span style="font-weight: 500; color: #0F172A;">Free shipping</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="sticky-bottom">
    <button type="button" class="btn btn-outline-slate">Save as Draft</button>
    <button type="button" class="btn btn-amber">Publish Product</button>
</div>
@endsection
