@extends('layouts.auth')

@section('title', 'Register — Bazaario')

@section('styles')
<style>
    .split-layout {
        display: flex;
        min-height: 100vh;
    }
    
    .left-panel {
        flex: 0 0 40%;
        background-color: #0F172A;
        color: white;
        padding: 60px 40px;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }
    .brand-logo {
        font-family: 'Fraunces', serif;
        font-size: 2rem;
        color: #F5A623;
        margin-bottom: auto;
        text-decoration: none;
    }
    .panel-content { margin-bottom: auto; }
    .panel-title {
        font-family: 'Fraunces', serif;
        font-size: 3rem;
        line-height: 1.1;
        margin-bottom: 24px;
    }
    .panel-subtitle {
        font-size: 1.125rem;
        color: #94A3B8;
        line-height: 1.6;
    }
    
    .right-panel {
        flex: 1;
        background-color: #FFFDF8;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 40px;
        overflow-y: auto;
    }
    .auth-container {
        width: 100%;
        max-width: 480px;
        padding: 40px 0;
    }
    .auth-title {
        font-family: 'Fraunces', serif;
        font-size: 2.5rem;
        color: #0F172A;
        margin-bottom: 32px;
    }
    
    /* Role Selector */
    .role-selector {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
        margin-bottom: 32px;
    }
    .role-card {
        background: #FFFFFF;
        border: 2px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 20px;
        cursor: pointer;
        transition: all 0.2s;
    }
    .role-card.active {
        border-color: #F5A623;
        background: #FFFAF0;
    }
    .role-icon { font-size: 2rem; margin-bottom: 12px; }
    .role-title { font-weight: 600; color: #0F172A; margin-bottom: 4px; }
    .role-desc { font-size: 0.75rem; color: #64748B; line-height: 1.4; }
    
    .form-group { margin-bottom: 20px; }
    .form-label { display: block; font-size: 0.875rem; font-weight: 500; color: #334155; margin-bottom: 8px; }
    .form-input {
        width: 100%; padding: 14px; border: 1px solid rgba(15,23,42,0.12); border-radius: 8px; font-family: 'Inter', sans-serif; font-size: 1rem; box-sizing: border-box;
    }
    .form-input:focus { outline: none; border-color: #F5A623; box-shadow: 0 0 0 3px rgba(245,166,35,0.1); }
    
    .terms-wrap { display: flex; align-items: flex-start; gap: 12px; margin: 24px 0; font-size: 0.875rem; color: #334155; }
    .terms-wrap input { margin-top: 4px; }
    .terms-wrap a { color: #0F172A; font-weight: 600; }
    
    .btn-submit {
        background: #F5A623; color: #1E1B16; border: none; width: 100%; padding: 16px; border-radius: 8px; font-weight: 600; font-size: 1rem; cursor: pointer;
    }
    
    .auth-footer { text-align: center; font-size: 0.875rem; color: #334155; margin-top: 32px; }
    .auth-footer a { color: #0F172A; font-weight: 600; text-decoration: none; }
</style>
@endsection

@section('content')
<div class="split-layout">
    <div class="left-panel">
        <a href="/" class="brand-logo">Bazaario.</a>
        <div class="panel-content">
            <h1 class="panel-title">Join the community</h1>
            <p class="panel-subtitle">Create an account to start exploring thousands of unique products or open your own stall.</p>
        </div>
        <div style="font-size: 0.875rem; color: #64748B;">© 2024 Bazaario Marketplace</div>
    </div>
    
    <div class="right-panel">
        <div class="auth-container">
            <h2 class="auth-title">Create Account</h2>
            
            <div class="role-selector">
                <div class="role-card active">
                    <div class="role-icon">🛍️</div>
                    <div class="role-title">I'm a Customer</div>
                    <div class="role-desc">Browse and buy from thousands of sellers</div>
                </div>
                <div class="role-card">
                    <div class="role-icon">🏪</div>
                    <div class="role-title">I'm a Seller</div>
                    <div class="role-desc">Open your own stall and start selling</div>
                </div>
            </div>
            
            <form action="#" method="POST">
                <div class="form-group">
                    <label class="form-label">Full Name</label>
                    <input type="text" class="form-input" placeholder="Rahul Sharma" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Email Address</label>
                    <input type="email" class="form-input" placeholder="you@example.com" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Password</label>
                    <input type="password" class="form-input" placeholder="Create a strong password" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Confirm Password</label>
                    <input type="password" class="form-input" placeholder="Repeat password" required>
                </div>
                
                <label class="terms-wrap">
                    <input type="checkbox" required>
                    <span>I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>.</span>
                </label>
                
                <button type="button" onclick="window.location.href='/account'" class="btn-submit">Create Account</button>
            </form>
            
            <div class="auth-footer">
                Already have an account? <a href="/login">Log in</a>
            </div>
        </div>
    </div>
</div>
@endsection
