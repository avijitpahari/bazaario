@extends('layouts.auth')

@section('title', 'Log In — Bazaario')

@section('styles')
<style>
    .split-layout {
        display: flex;
        min-height: 100vh;
    }
    
    .left-panel {
        flex: 0 0 40%;
        background-color: #0F172A;
        color: white;
        padding: 60px 40px;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }
    .brand-logo {
        font-family: 'Fraunces', serif;
        font-size: 2rem;
        color: #F5A623;
        margin-bottom: auto;
        text-decoration: none;
    }
    .panel-content { margin-bottom: auto; }
    .panel-title {
        font-family: 'Fraunces', serif;
        font-size: 3rem;
        line-height: 1.1;
        margin-bottom: 24px;
    }
    .panel-subtitle {
        font-size: 1.125rem;
        color: #94A3B8;
        line-height: 1.6;
    }
    
    .right-panel {
        flex: 1;
        background-color: #FFFDF8; /* Ivory */
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 40px;
    }
    .auth-container {
        width: 100%;
        max-width: 400px;
    }
    .auth-title {
        font-family: 'Fraunces', serif;
        font-size: 2.5rem;
        color: #0F172A;
        margin-bottom: 32px;
    }
    
    .form-group {
        margin-bottom: 24px;
    }
    .form-label {
        display: block;
        font-size: 0.875rem;
        font-weight: 500;
        color: #334155;
        margin-bottom: 8px;
    }
    .form-input {
        width: 100%;
        padding: 14px;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 8px;
        font-family: 'Inter', sans-serif;
        font-size: 1rem;
        box-sizing: border-box;
    }
    .form-input:focus {
        outline: none;
        border-color: #F5A623;
        box-shadow: 0 0 0 3px rgba(245,166,35,0.1);
    }
    
    .pwd-header {
        display: flex;
        justify-content: space-between;
        align-items: baseline;
    }
    .forgot-link {
        font-size: 0.875rem;
        color: #F5A623;
        text-decoration: none;
        font-weight: 500;
    }
    .pwd-wrapper {
        position: relative;
    }
    .toggle-pwd {
        position: absolute;
        right: 14px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: #64748B;
        cursor: pointer;
        font-size: 0.875rem;
    }
    
    .btn-submit {
        background: #F5A623;
        color: #1E1B16;
        border: none;
        width: 100%;
        padding: 16px;
        border-radius: 8px;
        font-weight: 600;
        font-size: 1rem;
        cursor: pointer;
        margin-top: 8px;
    }
    
    .divider {
        display: flex;
        align-items: center;
        text-align: center;
        margin: 32px 0;
        color: #94A3B8;
        font-size: 0.875rem;
    }
    .divider::before, .divider::after {
        content: '';
        flex: 1;
        border-bottom: 1px solid rgba(15,23,42,0.12);
    }
    .divider::before { margin-right: 16px; }
    .divider::after { margin-left: 16px; }
    
    .auth-footer {
        text-align: center;
        font-size: 0.875rem;
        color: #334155;
    }
    .auth-footer a {
        color: #0F172A;
        font-weight: 600;
        text-decoration: none;
    }
</style>
@endsection

@section('content')
<div class="split-layout">
    <div class="left-panel">
        <a href="/" class="brand-logo">Bazaario.</a>
        <div class="panel-content">
            <h1 class="panel-title">Welcome back to the market</h1>
            <p class="panel-subtitle">Sign in to access your orders, saved items, and personalized recommendations.</p>
        </div>
        <div style="font-size: 0.875rem; color: #64748B;">© 2024 Bazaario Marketplace</div>
    </div>
    
    <div class="right-panel">
        <div class="auth-container">
            <h2 class="auth-title">Log In</h2>
            
            <form action="#" method="POST">
                <div class="form-group">
                    <label class="form-label">Email Address</label>
                    <input type="email" class="form-input" placeholder="you@example.com" required>
                </div>
                
                <div class="form-group">
                    <div class="pwd-header">
                        <label class="form-label">Password</label>
                        <a href="#" class="forgot-link">Forgot password?</a>
                    </div>
                    <div class="pwd-wrapper">
                        <input type="password" class="form-input" placeholder="••••••••" required>
                        <button type="button" class="toggle-pwd">Show</button>
                    </div>
                </div>
                
                <button type="button" onclick="window.location.href='/account'" class="btn-submit">Log In</button>
            </form>
            
            <div class="divider">or</div>
            
            <div class="auth-footer">
                Don't have an account? <a href="/register">Create an account</a>
            </div>
        </div>
    </div>
</div>
@endsection
