@extends('layouts.app')

@section('title', 'Checkout — Bazaario')

@section('styles')
<style>
    .page-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 40px 24px;
    }
    
    /* Stepper */
    .stepper {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 48px;
        position: relative;
        max-width: 800px;
        margin-left: auto;
        margin-right: auto;
    }
    .stepper::before {
        content: '';
        position: absolute;
        top: 20px;
        left: 40px;
        right: 50%;
        height: 2px;
        background: #16A34A; /* Green completed line */
        z-index: 1;
    }
    .stepper::after {
        content: '';
        position: absolute;
        top: 20px;
        left: 50%;
        right: 40px;
        height: 2px;
        background: #E2E8F0; /* Muted upcoming line */
        z-index: 1;
    }
    
    .step {
        position: relative;
        z-index: 2;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 12px;
        width: 120px;
    }
    .step-circle {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        background: white;
    }
    .step-label { font-size: 0.875rem; font-weight: 500; text-align: center; }
    
    .step.completed .step-circle { background: #16A34A; color: white; }
    .step.completed .step-label { color: #16A34A; }
    
    .step.active .step-circle { background: #F5A623; color: #1E1B16; border: 4px solid #FEF3C7; }
    .step.active .step-label { color: #0F172A; font-weight: 600; }
    
    .step.upcoming .step-circle { background: #E2E8F0; color: #94A3B8; }
    .step.upcoming .step-label { color: #94A3B8; }

    /* Layout */
    .checkout-layout {
        display: flex;
        gap: 48px;
    }
    .main-col { flex: 0 0 60%; }
    .side-col { flex: 0 0 calc(40% - 48px); }
    
    .section-title {
        font-family: 'Fraunces', serif;
        font-size: 1.5rem;
        color: #0F172A;
        margin-bottom: 24px;
    }
    .card {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 32px;
        margin-bottom: 32px;
    }
    
    /* Form */
    .form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
    .form-group { margin-bottom: 20px; }
    .form-group.full { grid-column: 1 / -1; }
    .form-label { display: block; font-size: 0.875rem; font-weight: 500; color: #334155; margin-bottom: 8px; }
    .form-input {
        width: 100%;
        padding: 12px;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 8px;
        font-family: 'Inter', sans-serif;
        font-size: 1rem;
        box-sizing: border-box;
    }
    .form-input:focus { outline: none; border-color: #F5A623; box-shadow: 0 0 0 3px rgba(245,166,35,0.1); }
    
    .checkbox-wrap {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-top: 16px;
        font-size: 0.875rem;
        color: #334155;
    }
    
    /* Payment Options */
    .payment-option {
        display: flex;
        align-items: center;
        padding: 16px;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 8px;
        margin-bottom: 12px;
        cursor: pointer;
    }
    .payment-option.active {
        border-color: #F5A623;
        background: #FFFAF0;
    }
    .payment-option.disabled {
        background: #F8FAFC;
        opacity: 0.6;
        cursor: not-allowed;
    }
    .radio-btn {
        width: 20px; height: 20px; border-radius: 50%; border: 2px solid #CBD5E1; margin-right: 16px; position: relative;
    }
    .payment-option.active .radio-btn { border-color: #F5A623; }
    .payment-option.active .radio-btn::after {
        content: ''; position: absolute; top: 4px; left: 4px; width: 8px; height: 8px; border-radius: 50%; background: #F5A623;
    }
    .pay-label { flex: 1; font-weight: 500; color: #0F172A; }
    .tag-soon { background: #E2E8F0; color: #64748B; font-size: 0.75rem; padding: 2px 8px; border-radius: 9999px; }
    
    /* Summary */
    .summary-group {
        margin-bottom: 16px;
        padding-bottom: 16px;
        border-bottom: 1px dashed rgba(15,23,42,0.12);
    }
    .group-name { font-size: 0.75rem; color: #64748B; text-transform: uppercase; margin-bottom: 8px; }
    .summary-item { display: flex; justify-content: space-between; font-size: 0.875rem; margin-bottom: 8px; color: #334155; }
    .summary-item span:last-child { font-family: 'JetBrains Mono', monospace; }
    
    .totals-row { display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 0.875rem; color: #334155; }
    .totals-row.final { border-top: 1px solid rgba(15,23,42,0.12); padding-top: 16px; margin-top: 16px; font-size: 1.25rem; font-weight: 600; color: #0F172A; }
    .final-price { font-family: 'JetBrains Mono', monospace; color: #F5A623; font-weight: 700; }
    
    .btn-place {
        background: #F5A623;
        color: #1E1B16;
        border: none;
        width: 100%;
        padding: 16px;
        border-radius: 9999px;
        font-weight: 600;
        font-size: 1rem;
        cursor: pointer;
        margin-top: 24px;
        transition: background 0.2s;
    }
    .btn-place:hover { background: #E49820; }
</style>
@endsection

@section('content')
<div class="page-container">
    
    <div class="stepper">
        <div class="step completed">
            <div class="step-circle">✓</div>
            <div class="step-label">Cart</div>
        </div>
        <div class="step active">
            <div class="step-circle">2</div>
            <div class="step-label">Delivery Details</div>
        </div>
        <div class="step upcoming">
            <div class="step-circle">3</div>
            <div class="step-label">Review</div>
        </div>
    </div>
    
    <form action="/orders/confirmation" method="GET"> <!-- Using GET to show next page for demo -->
        <div class="checkout-layout">
            <div class="main-col">
                <h2 class="section-title">Delivery Address</h2>
                <div class="card">
                    <div class="form-grid">
                        <div class="form-group full">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-input" value="Rahul Sharma" required>
                        </div>
                        <div class="form-group full">
                            <label class="form-label">Phone Number</label>
                            <input type="tel" class="form-input" value="+91 98765 43210" required>
                        </div>
                        <div class="form-group full">
                            <label class="form-label">Address Line 1</label>
                            <input type="text" class="form-input" value="Flat 402, Sunshine Apartments" required>
                        </div>
                        <div class="form-group full">
                            <label class="form-label">Address Line 2 (Optional)</label>
                            <input type="text" class="form-input" value="Koramangala 4th Block">
                        </div>
                        <div class="form-group">
                            <label class="form-label">City</label>
                            <input type="text" class="form-input" value="Bengaluru" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">State</label>
                            <input type="text" class="form-input" value="Karnataka" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">PIN Code</label>
                            <input type="text" class="form-input" value="560034" required>
                        </div>
                    </div>
                    <label class="checkbox-wrap">
                        <input type="checkbox" checked> Save as default address
                    </label>
                </div>
                
                <h2 class="section-title">Payment Method</h2>
                <div class="card">
                    <div class="payment-option active">
                        <div class="radio-btn"></div>
                        <div class="pay-label">Cash on Delivery (COD)</div>
                    </div>
                    <div class="payment-option disabled">
                        <div class="radio-btn"></div>
                        <div class="pay-label">Credit / Debit Card</div>
                        <span class="tag-soon">Coming soon</span>
                    </div>
                    <div class="payment-option disabled">
                        <div class="radio-btn"></div>
                        <div class="pay-label">UPI</div>
                        <span class="tag-soon">Coming soon</span>
                    </div>
                    <div class="payment-option disabled">
                        <div class="radio-btn"></div>
                        <div class="pay-label">Net Banking</div>
                        <span class="tag-soon">Coming soon</span>
                    </div>
                    <div class="payment-option disabled">
                        <div class="radio-btn"></div>
                        <div class="pay-label">Wallets</div>
                        <span class="tag-soon">Coming soon</span>
                    </div>
                </div>
            </div>
            
            <div class="side-col">
                <div class="card" style="position: sticky; top: 24px;">
                    <h2 class="section-title" style="font-size:1.25rem;">Order Summary</h2>
                    
                    <div class="summary-group">
                        <div class="group-name">The Leather Workshop</div>
                        <div class="summary-item"><span>1x Handstitched Wallet</span><span>₹1,299</span></div>
                        <div class="summary-item"><span>2x Leather Card Holder</span><span>₹1,798</span></div>
                        <div class="summary-item" style="color:#64748B; font-size:0.75rem;">Subtotal: ₹3,097</div>
                    </div>
                    
                    <div class="summary-group">
                        <div class="group-name">TechParts Direct</div>
                        <div class="summary-item"><span>1x Wireless Earbuds Pro</span><span>₹2,499</span></div>
                        <div class="summary-item"><span>2x USB-C Hub 7-port</span><span>₹2,398</span></div>
                        <div class="summary-item"><span>1x Phone Stand</span><span>₹349</span></div>
                        <div class="summary-item" style="color:#64748B; font-size:0.75rem;">Subtotal: ₹5,246</div>
                    </div>
                    
                    <div class="totals-row">
                        <span>Items Subtotal</span>
                        <span style="font-family:'JetBrains Mono';">₹8,343</span>
                    </div>
                    <div class="totals-row">
                        <span>Discount (FIRST10)</span>
                        <span style="font-family:'JetBrains Mono'; color:#16A34A;">-₹834</span>
                    </div>
                    <div class="totals-row">
                        <span>Delivery</span>
                        <span style="color:#16A34A;">FREE</span>
                    </div>
                    
                    <div class="totals-row final">
                        <span>Total to Pay</span>
                        <span class="final-price">₹7,509</span>
                    </div>
                    
                    <button type="submit" class="btn-place">Place Order</button>
                    <p style="text-align:center; font-size:0.75rem; color:#64748B; margin-top:16px;">By placing your order, you agree to Bazaario's Terms of Service and Privacy Policy.</p>
                </div>
            </div>
        </div>
    </form>
</div>
@endsection
