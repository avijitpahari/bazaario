@extends('layouts.app')

@section('title', 'The Leather Workshop — Bazaario')

@section('styles')
<style>
    .seller-banner {
        background-color: #0F172A;
        height: 200px;
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 80px;
    }
    .banner-content {
        color: white;
        text-align: center;
        position: relative;
        z-index: 10;
        padding-bottom: 20px;
    }
    .shop-name {
        font-family: 'Fraunces', serif;
        font-size: 2.5rem;
        margin-bottom: 8px;
    }
    .shop-tagline {
        color: #94A3B8;
        font-size: 1.125rem;
    }
    .seller-avatar {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        background-color: #334155;
        border: 6px solid #FFFDF8;
        position: absolute;
        bottom: -60px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 20;
    }
    
    .stats-row {
        display: flex;
        justify-content: center;
        gap: 24px;
        margin-top: 16px;
    }
    .trust-badge {
        background: #16A34A;
        color: white;
        font-size: 0.75rem;
        padding: 4px 12px;
        border-radius: 9999px;
        font-weight: 600;
    }
    .stat-pill {
        background: rgba(255,255,255,0.1);
        color: white;
        font-size: 0.75rem;
        padding: 4px 12px;
        border-radius: 9999px;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 24px 60px 24px;
    }
    
    .shop-bio {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 32px;
        text-align: center;
        max-width: 800px;
        margin: 0 auto 48px auto;
    }
    .shop-bio p {
        color: #334155;
        line-height: 1.6;
        margin-bottom: 16px;
    }
    .bio-meta {
        font-size: 0.875rem;
        color: #64748B;
        display: flex;
        justify-content: center;
        gap: 24px;
    }
    
    .section-title {
        font-family: 'Fraunces', serif;
        font-size: 2rem;
        margin-bottom: 24px;
        color: #0F172A;
    }
    
    .filter-bar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        padding-bottom: 16px;
        border-bottom: 1px solid rgba(15,23,42,0.12);
    }
    .category-pills { display: flex; gap: 12px; }
    .pill {
        padding: 6px 16px;
        border-radius: 9999px;
        font-size: 0.875rem;
        font-weight: 500;
        color: #1E1B16;
        text-decoration: none;
        background: #F1F5F9;
    }
    .pill.active { background: #F5A623; }
    
    /* Reuse Product Grid Styles */
    .product-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 24px;
        margin-bottom: 60px;
    }
    .product-card {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        overflow: hidden;
        display: flex;
        flex-direction: column;
    }
    .product-image { height: 200px; background-color: #E2E8F0; }
    .product-info { padding: 16px; display: flex; flex-direction: column; flex: 1; }
    .product-name { font-weight: 600; font-size: 1rem; color: #0F172A; margin-bottom: 8px; text-decoration: none; }
    .product-rating { font-size: 0.875rem; color: #F5A623; margin-bottom: 12px; }
    .product-footer { display: flex; justify-content: space-between; align-items: center; margin-top: auto; }
    .product-price { font-family: 'JetBrains Mono', monospace; font-size: 1.25rem; font-weight: 700; color: #F5A623; }
    .btn-add { background: #0F172A; color: white; border: none; padding: 8px 16px; border-radius: 9999px; font-size: 0.875rem; cursor: pointer; }

    /* Reviews section */
    .reviews-layout {
        display: flex;
        gap: 48px;
    }
    .rating-summary {
        flex: 0 0 300px;
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 24px;
    }
    .big-rating { font-family: 'JetBrains Mono', monospace; font-size: 3rem; font-weight: 700; color: #F5A623; margin-bottom: 8px; }
    .bar-chart { margin-top: 16px; }
    .bar-row { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; font-size: 0.75rem; color: #64748B; }
    .bar-track { flex: 1; height: 8px; background: #F1F5F9; border-radius: 4px; overflow: hidden; }
    .bar-fill { height: 100%; background: #F5A623; }
    
    .reviews-list { flex: 1; display: flex; flex-direction: column; gap: 16px; }
    .review-card {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 24px;
    }
    .review-header { display: flex; justify-content: space-between; margin-bottom: 12px; }
    .review-author { font-weight: 600; font-size: 1rem; }
    .review-date { font-size: 0.875rem; color: #94A3B8; }
    .review-stars { color: #F5A623; margin-bottom: 8px; font-size: 0.875rem; }
</style>
@endsection

@section('content')
<div class="seller-banner">
    <div class="banner-content">
        <h1 class="shop-name">The Leather Workshop</h1>
        <p class="shop-tagline">Handcrafted genuine leather goods for everyday carry.</p>
        <div class="stats-row">
            <span class="trust-badge">Trust Score: 96/100</span>
            <span class="stat-pill">182 Products</span>
            <span class="stat-pill">4.9★ Rating</span>
        </div>
    </div>
    <div class="seller-avatar"></div>
</div>

<div class="container">
    <div class="shop-bio">
        <p>Welcome to The Leather Workshop! We are a small team of artisans dedicated to crafting high-quality, durable leather goods. Every item is cut, stitched, and finished by hand using premium full-grain leather sourced from ethical tanneries.</p>
        <div class="bio-meta">
            <span>📍 Jaipur, India</span>
            <span>📅 Est. 2018</span>
        </div>
    </div>

    <h2 class="section-title">All Products</h2>
    <div class="filter-bar">
        <div class="category-pills">
            <a href="#" class="pill active">All</a>
            <a href="#" class="pill">Wallets</a>
            <a href="#" class="pill">Bags</a>
            <a href="#" class="pill">Accessories</a>
        </div>
        <select style="padding:8px 12px; border-radius:6px; border:1px solid #CBD5E1;">
            <option>Most Popular</option>
            <option>Newest</option>
            <option>Price: Low to High</option>
        </select>
    </div>

    <div class="product-grid">
        <!-- Products -->
        <div class="product-card">
            <div class="product-image" style="background:#D6D3D1;"></div>
            <div class="product-info">
                <a href="#" class="product-name">Handstitched Leather Wallet</a>
                <div class="product-rating">★★★★★</div>
                <div class="product-footer">
                    <span class="product-price">₹1,299</span>
                    <button class="btn-add">Add</button>
                </div>
            </div>
        </div>
        <div class="product-card">
            <div class="product-image" style="background:#E7E5E4;"></div>
            <div class="product-info">
                <a href="#" class="product-name">Classic Leather Belt</a>
                <div class="product-rating">★★★★☆</div>
                <div class="product-footer">
                    <span class="product-price">₹899</span>
                    <button class="btn-add">Add</button>
                </div>
            </div>
        </div>
        <div class="product-card">
            <div class="product-image" style="background:#A8A29E;"></div>
            <div class="product-info">
                <a href="#" class="product-name">Minimalist Card Holder</a>
                <div class="product-rating">★★★★★</div>
                <div class="product-footer">
                    <span class="product-price">₹499</span>
                    <button class="btn-add">Add</button>
                </div>
            </div>
        </div>
        <div class="product-card">
            <div class="product-image" style="background:#78716C;"></div>
            <div class="product-info">
                <a href="#" class="product-name">Leather Messenger Bag</a>
                <div class="product-rating">★★★★★</div>
                <div class="product-footer">
                    <span class="product-price">₹4,599</span>
                    <button class="btn-add">Add</button>
                </div>
            </div>
        </div>
        <div class="product-card">
            <div class="product-image" style="background:#D6D3D1;"></div>
            <div class="product-info">
                <a href="#" class="product-name">Key Organizer</a>
                <div class="product-rating">★★★★☆</div>
                <div class="product-footer">
                    <span class="product-price">₹349</span>
                    <button class="btn-add">Add</button>
                </div>
            </div>
        </div>
        <div class="product-card">
            <div class="product-image" style="background:#E7E5E4;"></div>
            <div class="product-info">
                <a href="#" class="product-name">Passport Cover</a>
                <div class="product-rating">★★★★★</div>
                <div class="product-footer">
                    <span class="product-price">₹799</span>
                    <button class="btn-add">Add</button>
                </div>
            </div>
        </div>
        <div class="product-card">
            <div class="product-image" style="background:#A8A29E;"></div>
            <div class="product-info">
                <a href="#" class="product-name">Leather Notebook Cover</a>
                <div class="product-rating">★★★★★</div>
                <div class="product-footer">
                    <span class="product-price">₹1,199</span>
                    <button class="btn-add">Add</button>
                </div>
            </div>
        </div>
        <div class="product-card">
            <div class="product-image" style="background:#78716C;"></div>
            <div class="product-info">
                <a href="#" class="product-name">Camera Strap</a>
                <div class="product-rating">★★★★☆</div>
                <div class="product-footer">
                    <span class="product-price">₹999</span>
                    <button class="btn-add">Add</button>
                </div>
            </div>
        </div>
    </div>

    <h2 class="section-title">What customers say</h2>
    <div class="reviews-layout">
        <div class="rating-summary">
            <div style="text-align:center;">
                <div class="big-rating">4.9</div>
                <div style="color:#F5A623; font-size:1.25rem;">★★★★★</div>
                <div style="color:#64748B; font-size:0.875rem; margin-top:8px;">Based on 342 reviews</div>
            </div>
            <div class="bar-chart">
                <div class="bar-row"><span>5★</span><div class="bar-track"><div class="bar-fill" style="width: 90%;"></div></div><span>308</span></div>
                <div class="bar-row"><span>4★</span><div class="bar-track"><div class="bar-fill" style="width: 8%;"></div></div><span>26</span></div>
                <div class="bar-row"><span>3★</span><div class="bar-track"><div class="bar-fill" style="width: 2%;"></div></div><span>6</span></div>
                <div class="bar-row"><span>2★</span><div class="bar-track"><div class="bar-fill" style="width: 0%;"></div></div><span>0</span></div>
                <div class="bar-row"><span>1★</span><div class="bar-track"><div class="bar-fill" style="width: 0.5%;"></div></div><span>2</span></div>
            </div>
        </div>
        
        <div class="reviews-list">
            <div class="review-card">
                <div class="review-header">
                    <div class="review-author">Anjali D.</div>
                    <div class="review-date">2 days ago</div>
                </div>
                <div class="review-stars">★★★★★</div>
                <p>The craftsmanship on this wallet is incredible. The leather feels premium and it smells amazing. Fast shipping too!</p>
            </div>
            <div class="review-card">
                <div class="review-header">
                    <div class="review-author">Karan W.</div>
                    <div class="review-date">1 week ago</div>
                </div>
                <div class="review-stars">★★★★★</div>
                <p>Bought the messenger bag for work. It fits my laptop perfectly and I've already gotten so many compliments on it. Worth every penny.</p>
            </div>
            <div class="review-card">
                <div class="review-header">
                    <div class="review-author">Priya S.</div>
                    <div class="review-date">2 weeks ago</div>
                </div>
                <div class="review-stars">★★★★☆</div>
                <p>Great card holder, very minimalist. The stitching is perfect. Took a day longer than expected to arrive but the product is solid.</p>
            </div>
        </div>
    </div>
</div>
@endsection
