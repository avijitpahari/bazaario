@extends('layouts.app')

@section('title', 'Order Confirmed — Bazaario')

@section('styles')
<style>
    .page-container {
        max-width: 800px;
        margin: 0 auto;
        padding: 80px 24px;
        text-align: center;
    }
    
    .success-icon {
        width: 80px;
        height: 80px;
        background: #DCFCE7;
        color: #16A34A;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 40px;
        margin: 0 auto 24px auto;
    }
    
    .success-heading {
        font-family: 'Fraunces', serif;
        font-size: 2.5rem;
        color: #0F172A;
        margin-bottom: 16px;
    }
    
    .order-id-box {
        display: inline-block;
        background: #FFFAF0;
        border: 1px solid #F5A623;
        color: #F5A623;
        font-family: 'JetBrains Mono', monospace;
        font-size: 1.25rem;
        font-weight: 700;
        padding: 8px 24px;
        border-radius: 8px;
        margin-bottom: 24px;
    }
    
    .success-text {
        font-size: 1.125rem;
        color: #334155;
        line-height: 1.6;
        margin-bottom: 48px;
    }
    
    .summary-card {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 32px;
        text-align: left;
        margin-bottom: 32px;
    }
    .summary-card h3 {
        font-family: 'Fraunces', serif;
        font-size: 1.5rem;
        margin-bottom: 24px;
        color: #0F172A;
        border-bottom: 1px solid rgba(15,23,42,0.12);
        padding-bottom: 16px;
    }
    
    .item-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 12px;
        color: #334155;
        font-size: 0.875rem;
    }
    .item-row span:last-child {
        font-family: 'JetBrains Mono', monospace;
    }
    .seller-group {
        margin-bottom: 24px;
    }
    .seller-name {
        font-size: 0.75rem;
        color: #64748B;
        text-transform: uppercase;
        margin-bottom: 8px;
        font-weight: 600;
    }
    
    .total-row {
        display: flex;
        justify-content: space-between;
        border-top: 1px solid rgba(15,23,42,0.12);
        padding-top: 16px;
        margin-top: 16px;
        font-size: 1.25rem;
        font-weight: 600;
        color: #0F172A;
    }
    .total-price {
        font-family: 'JetBrains Mono', monospace;
        color: #F5A623;
    }
    
    .delivery-strip {
        background: #ECFCCB;
        color: #3F6212;
        padding: 16px;
        border-radius: 8px;
        font-weight: 500;
        margin-bottom: 48px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
    }
    
    .cta-row {
        display: flex;
        justify-content: center;
        gap: 16px;
    }
    .btn-amber {
        background: #F5A623;
        color: #1E1B16;
        padding: 12px 32px;
        border-radius: 9999px;
        font-weight: 600;
        text-decoration: none;
    }
    .btn-outline-slate {
        background: transparent;
        color: #0F172A;
        border: 2px solid #0F172A;
        padding: 12px 32px;
        border-radius: 9999px;
        font-weight: 600;
        text-decoration: none;
    }
</style>
@endsection

@section('content')
<div class="page-container">
    
    <div class="success-icon">✓</div>
    <h1 class="success-heading">Order Placed Successfully!</h1>
    
    <div class="order-id-box">#BZR-2024-08471</div>
    
    <p class="success-text">Thank you Rahul! Your order has been confirmed and sellers will begin processing it shortly. We've sent a confirmation email with all the details.</p>
    
    <div class="summary-card">
        <h3>Order Summary</h3>
        
        <div class="seller-group">
            <div class="seller-name">The Leather Workshop</div>
            <div class="item-row">
                <span>1x Handstitched Leather Wallet</span>
                <span>₹1,299</span>
            </div>
            <div class="item-row">
                <span>2x Leather Card Holder</span>
                <span>₹1,798</span>
            </div>
        </div>
        
        <div class="seller-group">
            <div class="seller-name">TechParts Direct</div>
            <div class="item-row">
                <span>1x Wireless Earbuds Pro</span>
                <span>₹2,499</span>
            </div>
            <div class="item-row">
                <span>2x USB-C Hub 7-port</span>
                <span>₹2,398</span>
            </div>
            <div class="item-row">
                <span>1x Phone Stand</span>
                <span>₹349</span>
            </div>
        </div>
        
        <div class="item-row" style="color:#16A34A;">
            <span>Discount (FIRST10)</span>
            <span>-₹834</span>
        </div>
        
        <div class="total-row">
            <span>Total Paid (COD)</span>
            <span class="total-price">₹7,509</span>
        </div>
    </div>
    
    <div class="delivery-strip">
        <span>🚚</span> Expected delivery by 28 Aug – 1 Sep 2024
    </div>
    
    <div class="cta-row">
        <a href="/account" class="btn-amber">Track Your Order</a>
        <a href="/products" class="btn-outline-slate">Continue Shopping</a>
    </div>
    
</div>
@endsection
