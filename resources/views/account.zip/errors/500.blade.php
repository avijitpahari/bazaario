@extends('layouts.auth')

@section('title', '500 - Server Error')

@section('styles')
<style>
    body { background-color: #FFFDF8; font-family: 'Inter', sans-serif; color: #1E1B16; margin: 0; padding: 0; display: flex; align-items: center; justify-content: center; min-height: 100vh; position: relative; overflow: hidden; }
    .error-container { text-align: center; z-index: 10; max-width: 600px; padding: 2rem; }
    .error-code { font-family: 'Fraunces', serif; font-size: 120px; font-weight: 700; color: #F5A623; line-height: 1; margin: 0 0 1rem 0; text-shadow: 4px 4px 0px rgba(245, 166, 35, 0.2); }
    .error-title { font-family: 'Fraunces', serif; font-size: 2.5rem; color: #0F172A; margin: 0 0 1rem 0; }
    .error-desc { font-size: 1.125rem; color: #475569; margin: 0 0 2.5rem 0; line-height: 1.6; }
    .btn-group { display: flex; gap: 1rem; justify-content: center; }
    .btn-amber { background: #F5A623; color: white; border-radius: 9999px; padding: 0.8rem 2rem; border: none; cursor: pointer; font-weight: 600; font-size: 1rem; font-family: 'Inter', sans-serif; text-decoration: none; transition: background 0.2s; }
    .btn-amber:hover { background: #d97706; }
    .btn-outline { background: transparent; color: #0F172A; border-radius: 9999px; padding: 0.8rem 2rem; border: 2px solid rgba(15,23,42,0.12); cursor: pointer; font-weight: 600; font-size: 1rem; font-family: 'Inter', sans-serif; text-decoration: none; transition: all 0.2s; }
    .btn-outline:hover { border-color: #0F172A; background: rgba(15,23,42,0.05); }
    
    .bg-decoration { position: absolute; width: 600px; height: 600px; border: 2px dashed rgba(245, 166, 35, 0.2); border-radius: 50%; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 1; pointer-events: none; }
</style>
@endsection

@section('content')
<div class="bg-decoration"></div>

<div class="error-container">
    <h1 class="error-code">500</h1>
    <h2 class="error-title">Server Error</h2>
    <p class="error-desc">Something went wrong on our end. We're working on fixing it. Please try again in a few minutes.</p>
    
    <div class="btn-group">
        <a href="javascript:window.location.reload(true)" class="btn-amber">Try Again</a>
        <a href="{{ route('home') }}" class="btn-outline">Go Home</a>
    </div>
</div>
@endsection
