<footer style="background:var(--primary); color:white; padding:64px 0 24px 0; margin-top: auto;">
    <div class="container">
        <div style="display:flex; flex-wrap:wrap; margin-bottom:48px; gap:40px;">
            
            <div style="flex:1; min-width:240px;">
                <div style="display:flex; align-items:center; gap:8px; margin-bottom:16px;">
                    <div style="width:14px; height:14px; background:var(--accent); border-radius:2px;"></div>
                    <span style="font-family:'Fraunces',serif; font-weight:700; font-size:28px; color:white;">Bazaario</span>
                </div>
                <p style="color:rgba(255,255,255,0.7); font-size:15px; margin-bottom:24px;">Your market, your rules.</p>
                <div style="display:flex; gap:16px;">
                    <!-- Social Icons placeholders, but using raw SVG -->
                    <a href="#" style="color:rgba(255,255,255,0.7);"><svg style="width:20px; height:20px;" fill="currentColor" viewBox="0 0 24 24"><path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/></svg></a>
                    <a href="#" style="color:rgba(255,255,255,0.7);"><svg style="width:20px; height:20px;" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg></a>
                </div>
            </div>

            <div style="flex:1; min-width:160px;">
                <h4 style="color:white; font-family:'Inter',sans-serif; font-size:16px; font-weight:600; margin-bottom:20px;">Shop</h4>
                <ul style="list-style:none; padding:0; display:flex; flex-direction:column; gap:12px;">
                    <li><a href="/products" style="color:rgba(255,255,255,0.7); text-decoration:none; font-size:14px; transition:color 0.2s;" onmouseover="this.style.color='white'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">Browse Products</a></li>
                    <li><a href="/new-arrivals" style="color:rgba(255,255,255,0.7); text-decoration:none; font-size:14px; transition:color 0.2s;" onmouseover="this.style.color='white'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">New Arrivals</a></li>
                    <li><a href="/trending" style="color:rgba(255,255,255,0.7); text-decoration:none; font-size:14px; transition:color 0.2s;" onmouseover="this.style.color='white'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">Trending</a></li>
                    <li><a href="/categories" style="color:rgba(255,255,255,0.7); text-decoration:none; font-size:14px; transition:color 0.2s;" onmouseover="this.style.color='white'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">All Categories</a></li>
                </ul>
            </div>

            <div style="flex:1; min-width:160px;">
                <h4 style="color:white; font-family:'Inter',sans-serif; font-size:16px; font-weight:600; margin-bottom:20px;">Sell</h4>
                <ul style="list-style:none; padding:0; display:flex; flex-direction:column; gap:12px;">
                    <li><a href="/sell" style="color:rgba(255,255,255,0.7); text-decoration:none; font-size:14px; transition:color 0.2s;" onmouseover="this.style.color='white'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">Start Selling</a></li>
                    <li><a href="/seller/dashboard" style="color:rgba(255,255,255,0.7); text-decoration:none; font-size:14px; transition:color 0.2s;" onmouseover="this.style.color='white'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">Seller Dashboard</a></li>
                    <li><a href="/seller-faq" style="color:rgba(255,255,255,0.7); text-decoration:none; font-size:14px; transition:color 0.2s;" onmouseover="this.style.color='white'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">Seller FAQ</a></li>
                    <li><a href="/commissions" style="color:rgba(255,255,255,0.7); text-decoration:none; font-size:14px; transition:color 0.2s;" onmouseover="this.style.color='white'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">Commission Rates</a></li>
                </ul>
            </div>

            <div style="flex:1; min-width:160px;">
                <h4 style="color:white; font-family:'Inter',sans-serif; font-size:16px; font-weight:600; margin-bottom:20px;">Company</h4>
                <ul style="list-style:none; padding:0; display:flex; flex-direction:column; gap:12px;">
                    <li><a href="/about" style="color:rgba(255,255,255,0.7); text-decoration:none; font-size:14px; transition:color 0.2s;" onmouseover="this.style.color='white'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">About</a></li>
                    <li><a href="/blog" style="color:rgba(255,255,255,0.7); text-decoration:none; font-size:14px; transition:color 0.2s;" onmouseover="this.style.color='white'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">Blog</a></li>
                    <li><a href="/careers" style="color:rgba(255,255,255,0.7); text-decoration:none; font-size:14px; transition:color 0.2s;" onmouseover="this.style.color='white'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">Careers</a></li>
                    <li><a href="/contact" style="color:rgba(255,255,255,0.7); text-decoration:none; font-size:14px; transition:color 0.2s;" onmouseover="this.style.color='white'" onmouseout="this.style.color='rgba(255,255,255,0.7)'">Contact</a></li>
                </ul>
            </div>
            
        </div>
        
        <div style="border-top:1px solid rgba(255,255,255,0.1); padding-top:24px; display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:16px;">
            <p style="color:rgba(255,255,255,0.5); font-size:14px; margin:0;">&copy; {{ date('Y') }} Bazaario Inc. All rights reserved.</p>
            <div style="display:flex; gap:24px;">
                <a href="/privacy" style="color:rgba(255,255,255,0.5); text-decoration:none; font-size:14px; transition:color 0.2s;" onmouseover="this.style.color='white'" onmouseout="this.style.color='rgba(255,255,255,0.5)'">Privacy Policy</a>
                <a href="/terms" style="color:rgba(255,255,255,0.5); text-decoration:none; font-size:14px; transition:color 0.2s;" onmouseover="this.style.color='white'" onmouseout="this.style.color='rgba(255,255,255,0.5)'">Terms of Service</a>
            </div>
        </div>
    </div>
</footer>
