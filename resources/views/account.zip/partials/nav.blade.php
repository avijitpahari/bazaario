<nav class="main-nav" style="position:sticky; top:0; z-index:100; background:var(--bg); border-bottom:1px solid var(--border);">
    <div class="container" style="display:flex; align-items:center; justify-content:space-between; height:64px;">
        
        <div class="nav-left" style="display:flex; align-items:center;">
            <a href="/" style="display:flex; align-items:center; gap:8px;">
                <div style="width:12px; height:12px; background:var(--accent); border-radius:2px;"></div>
                <span style="font-family:'Fraunces',serif; font-weight:700; font-size:24px; color:var(--primary);">Bazaario</span>
            </a>
        </div>
        
        <div class="nav-center" style="flex:1; max-width:500px; margin:0 32px; display:flex; align-items:center;">
            <div style="display:flex; width:100%; position:relative;">
                <input type="text" placeholder="Search products, stalls..." style="width:100%; padding:10px 16px 10px 40px; border:1px solid var(--border); border-radius:var(--radius-pill) 0 0 var(--radius-pill); border-right:none; font-family:'Inter',sans-serif; font-size:14px; outline:none; background:var(--surface);">
                <svg style="position:absolute; left:14px; top:11px; width:18px; height:18px; color:rgba(15,23,42,0.4);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                <button style="padding:0 16px; background:var(--surface); border:1px solid var(--border); border-radius:0 var(--radius-pill) var(--radius-pill) 0; border-left:1px solid var(--border); cursor:pointer; color:var(--text); font-weight:500; font-size:14px; display:flex; align-items:center; gap:6px;">
                    Categories
                    <svg style="width:14px; height:14px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                </button>
            </div>
        </div>

        <div class="nav-right" style="display:flex; align-items:center; gap:20px;">
            <div style="font-weight:500; font-size:14px; color:var(--primary); cursor:pointer;">EN</div>
            
            <a href="/cart" style="position:relative; color:var(--primary); display:flex; align-items:center;">
                <svg style="width:24px; height:24px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>
                <span style="position:absolute; top:-6px; right:-8px; background:var(--accent); color:white; font-size:11px; font-weight:700; padding:2px 6px; border-radius:10px; font-family:'Inter',sans-serif;">3</span>
            </a>
            
            <div style="position:relative; cursor:pointer;" onclick="document.getElementById('user-dropdown').classList.toggle('show')">
                <div style="display:flex; align-items:center; gap:8px;">
                    <div style="width:32px; height:32px; background:var(--primary); border-radius:50%; color:white; display:flex; align-items:center; justify-content:center; font-size:14px; font-weight:600;">U</div>
                </div>
                <div id="user-dropdown" style="display:none; position:absolute; right:0; top:45px; background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-sm); box-shadow:var(--shadow); width:180px; padding:8px 0; z-index:110;">
                    <a href="/login" style="display:block; padding:8px 16px; font-size:14px; color:var(--text);">Sign In</a>
                    <a href="/account" style="display:block; padding:8px 16px; font-size:14px; color:var(--text);">My Account</a>
                </div>
            </div>
            
            <button id="mobile-menu-toggle" style="display:none; background:none; border:none; cursor:pointer; color:var(--primary);">
                <svg style="width:24px; height:24px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
            </button>
        </div>
    </div>
    
    <div id="mobile-menu" style="display:none; background:var(--surface); border-top:1px solid var(--border); padding:16px;">
        <div style="margin-bottom:16px;">
            <input type="text" placeholder="Search..." style="width:100%; padding:10px; border:1px solid var(--border); border-radius:var(--radius-sm);">
        </div>
        <a href="/login" style="display:block; padding:12px 0; border-bottom:1px solid var(--border);">Sign In</a>
        <a href="/account" style="display:block; padding:12px 0; border-bottom:1px solid var(--border);">My Account</a>
        <a href="/categories" style="display:block; padding:12px 0;">All Categories</a>
    </div>
    
    <style>
        @media (max-width: 768px) {
            .nav-center { display: none !important; }
            #mobile-menu-toggle { display: block !important; }
            .nav-right .en-lang { display: none; }
        }
        #user-dropdown.show { display: block !important; }
    </style>
</nav>
