@extends('layouts.app')

@section('title', 'Bazaario — The market for everything')

@section('styles')
<style>
    .hero-section {
        background-color: #0F172A;
        color: #FFFFFF;
        padding: 80px 24px;
        text-align: center;
    }
    .hero-heading {
        font-family: 'Fraunces', serif;
        font-size: 4rem;
        font-weight: 700;
        margin-bottom: 24px;
    }
    .hero-heading .accent-italic {
        color: #F5A623;
        font-style: italic;
    }
    .hero-subtext {
        font-family: 'Inter', sans-serif;
        font-size: 1.25rem;
        max-width: 600px;
        margin: 0 auto 40px auto;
        color: #E2E8F0;
        line-height: 1.6;
    }
    .hero-buttons {
        display: flex;
        gap: 16px;
        justify-content: center;
        margin-bottom: 60px;
    }
    .hero-stats {
        display: flex;
        justify-content: center;
        gap: 48px;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        padding-top: 40px;
    }
    .stat-item {
        display: flex;
        flex-direction: column;
    }
    .stat-number {
        font-family: 'JetBrains Mono', monospace;
        font-size: 2rem;
        font-weight: 700;
        color: #F5A623;
    }
    .stat-label {
        font-size: 0.875rem;
        color: #94A3B8;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    .section-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 60px 24px;
    }
    .section-title {
        font-family: 'Fraunces', serif;
        font-size: 2.5rem;
        color: #0F172A;
        margin-bottom: 40px;
    }
    
    .stall-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 24px;
    }
    .stall-card {
        border-radius: 13px;
        padding: 24px;
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        text-decoration: none;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .stall-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 10px 25px rgba(15,23,42,0.1);
    }
    .stall-avatar {
        width: 80px;
        height: 80px;
        border-radius: 9999px;
        margin-bottom: 16px;
        object-fit: cover;
        background-color: rgba(255,255,255,0.2);
    }
    .stall-name {
        font-family: 'Fraunces', serif;
        font-size: 1.5rem;
        font-weight: 600;
        margin-bottom: 8px;
    }
    .stall-category {
        font-size: 0.875rem;
        padding: 4px 12px;
        border-radius: 9999px;
        background: rgba(0,0,0,0.05);
        margin-bottom: 16px;
    }
    .stall-meta {
        display: flex;
        gap: 16px;
        font-size: 0.875rem;
        margin-bottom: 24px;
    }
    .stall-card.bg-slate { background: #0F172A; color: white; }
    .stall-card.bg-slate .stall-category { background: rgba(255,255,255,0.1); }
    .stall-card.bg-amber { background: #F5A623; color: #1E1B16; }
    .stall-card.bg-white { background: #FFFFFF; color: #1E1B16; border: 1px solid rgba(15,23,42,0.12); }
    .stall-card.border-green { border-left: 6px solid #16A34A; }
    
    .ticker-wrap {
        background: #FFFDF8;
        border-top: 1px solid rgba(15,23,42,0.12);
        border-bottom: 1px solid rgba(15,23,42,0.12);
        padding: 12px 0;
        overflow: hidden;
        white-space: nowrap;
    }
    .ticker {
        display: inline-block;
        animation: ticker 25s linear infinite;
        padding-left: 100%;
    }
    .ticker-item {
        display: inline-flex;
        align-items: center;
        margin-right: 48px;
        font-size: 0.875rem;
        color: #1E1B16;
    }
    .ticker-item::before {
        content: '';
        display: inline-block;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background-color: #F5A623;
        margin-right: 12px;
    }
    @keyframes ticker {
        0% { transform: translate3d(0, 0, 0); }
        100% { transform: translate3d(-100%, 0, 0); }
    }
    
    .category-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
        gap: 16px;
    }
    .category-card {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 24px 16px;
        text-align: center;
        text-decoration: none;
        color: #1E1B16;
        transition: all 0.2s ease;
    }
    .category-card:hover {
        border-color: #F5A623;
        box-shadow: 0 4px 12px rgba(245, 166, 35, 0.15);
    }
    .cat-icon { font-size: 2rem; margin-bottom: 12px; display: block; }
    .cat-name { font-weight: 600; margin-bottom: 4px; display: block; }
    .cat-count { font-size: 0.75rem; color: #64748B; }
    
    .seller-cta {
        background-color: #0F172A;
        color: white;
        padding: 80px 24px;
        margin-top: 60px;
    }
    .seller-cta-container {
        max-width: 1200px;
        margin: 0 auto;
        text-align: center;
    }
    .seller-cta h2 {
        font-family: 'Fraunces', serif;
        font-size: 2.5rem;
        margin-bottom: 48px;
    }
    .steps-row {
        display: flex;
        justify-content: space-between;
        gap: 32px;
        margin-bottom: 48px;
    }
    .step {
        flex: 1;
        text-align: left;
        padding: 24px;
        background: rgba(255,255,255,0.05);
        border-radius: 13px;
    }
    .step-number {
        font-family: 'JetBrains Mono', monospace;
        color: #F5A623;
        font-size: 1.25rem;
        font-weight: 700;
        margin-bottom: 12px;
    }
    .step-title {
        font-weight: 600;
        font-size: 1.25rem;
        margin-bottom: 8px;
    }
    .step-desc {
        color: #94A3B8;
        font-size: 0.875rem;
        line-height: 1.5;
    }
    
    /* Global utilities usually in layout, redefining here if needed */
    .btn-amber { background: #F5A623; color: #1E1B16; padding: 12px 24px; border-radius: 9999px; font-weight: 600; text-decoration: none; display: inline-block; }
    .btn-outline-white { background: transparent; color: white; border: 1px solid white; padding: 12px 24px; border-radius: 9999px; font-weight: 600; text-decoration: none; display: inline-block; }
    .btn-white { background: white; color: #0F172A; padding: 8px 16px; border-radius: 9999px; font-weight: 600; text-decoration: none; font-size: 0.875rem; display: inline-block; }
    .btn-outline-slate { background: transparent; color: #0F172A; border: 1px solid #0F172A; padding: 8px 16px; border-radius: 9999px; font-weight: 600; text-decoration: none; font-size: 0.875rem; display: inline-block; }
</style>
@endsection

@section('content')
<div class="hero-section">
    <h1 class="hero-heading">The market for <span class="accent-italic">everything</span></h1>
    <p class="hero-subtext">Discover thousands of unique products from independent sellers across every category.</p>
    <div class="hero-buttons">
        <a href="/products" class="btn-amber">Browse the market</a>
        <a href="/register" class="btn-outline-white">Open your own stall</a>
    </div>
    <div class="hero-stats">
        <div class="stat-item">
            <span class="stat-number">2,400+</span>
            <span class="stat-label">Sellers</span>
        </div>
        <div class="stat-item">
            <span class="stat-number">180,000+</span>
            <span class="stat-label">Products</span>
        </div>
        <div class="stat-item">
            <span class="stat-number">48</span>
            <span class="stat-label">Categories</span>
        </div>
    </div>
</div>

<div class="ticker-wrap">
    <div class="ticker">
        <span class="ticker-item">Zara A. just ordered from The Leather Workshop</span>
        <span class="ticker-item">New stall 'Nordic Woodcraft' just joined</span>
        <span class="ticker-item">Ravi S. left a 5★ review for Heritage Spices</span>
        <span class="ticker-item">TechParts Direct just restocked USB-C hubs</span>
    </div>
</div>

<div class="section-container">
    <h2 class="section-title">Featured Stalls</h2>
    <div class="stall-grid">
        <div class="stall-card bg-slate">
            <div class="stall-avatar" style="background: #334155;"></div>
            <h3 class="stall-name">The Leather Workshop</h3>
            <span class="stall-category">Handcrafted Goods</span>
            <div class="stall-meta">
                <span>★ 4.9</span>
                <span>342 products</span>
            </div>
            <a href="/stall/leather-workshop" class="btn-white">Visit Stall</a>
        </div>
        
        <div class="stall-card bg-amber">
            <div class="stall-avatar" style="background: #FFFFFF;"></div>
            <h3 class="stall-name">Bloom & Co.</h3>
            <span class="stall-category">Plants & Flowers</span>
            <div class="stall-meta">
                <span>★ 4.8</span>
                <span>120 products</span>
            </div>
            <a href="/stall/bloom-co" class="btn-white">Visit Stall</a>
        </div>
        
        <div class="stall-card bg-white border-green">
            <div class="stall-avatar" style="background: #E2E8F0;"></div>
            <h3 class="stall-name">TechParts Direct</h3>
            <span class="stall-category">Electronics</span>
            <div class="stall-meta">
                <span>★ 4.7</span>
                <span>890 products</span>
            </div>
            <a href="/stall/techparts" class="btn-outline-slate">Visit Stall</a>
        </div>
        
        <div class="stall-card bg-white">
            <div class="stall-avatar" style="background: #FEE2E2;"></div>
            <h3 class="stall-name">Heritage Spices</h3>
            <span class="stall-category">Food & Gourmet</span>
            <div class="stall-meta">
                <span>★ 4.9</span>
                <span>210 products</span>
            </div>
            <a href="/stall/heritage-spices" class="btn-outline-slate">Visit Stall</a>
        </div>
    </div>
</div>

<div class="section-container" style="padding-top: 0;">
    <h2 class="section-title">Shop by Category</h2>
    <div class="category-grid">
        <a href="/products?category=electronics" class="category-card">
            <span class="cat-icon">📱</span>
            <span class="cat-name">Electronics</span>
            <span class="cat-count">12,400 items</span>
        </a>
        <a href="/products?category=fashion" class="category-card">
            <span class="cat-icon">👕</span>
            <span class="cat-name">Fashion</span>
            <span class="cat-count">45,120 items</span>
        </a>
        <a href="/products?category=home-garden" class="category-card">
            <span class="cat-icon">🪴</span>
            <span class="cat-name">Home & Garden</span>
            <span class="cat-count">18,300 items</span>
        </a>
        <a href="/products?category=books" class="category-card">
            <span class="cat-icon">📚</span>
            <span class="cat-name">Books</span>
            <span class="cat-count">32,900 items</span>
        </a>
        <a href="/products?category=sports" class="category-card">
            <span class="cat-icon">⚽</span>
            <span class="cat-name">Sports</span>
            <span class="cat-count">8,500 items</span>
        </a>
        <a href="/products?category=toys" class="category-card">
            <span class="cat-icon">🧸</span>
            <span class="cat-name">Toys</span>
            <span class="cat-count">11,200 items</span>
        </a>
        <a href="/products?category=food-gourmet" class="category-card">
            <span class="cat-icon">🍯</span>
            <span class="cat-name">Food & Gourmet</span>
            <span class="cat-count">6,400 items</span>
        </a>
        <a href="/products?category=art-crafts" class="category-card">
            <span class="cat-icon">🎨</span>
            <span class="cat-name">Art & Crafts</span>
            <span class="cat-count">9,800 items</span>
        </a>
    </div>
</div>

<div class="seller-cta">
    <div class="seller-cta-container">
        <h2>Ready to start selling?</h2>
        <div class="steps-row">
            <div class="step">
                <div class="step-number">01</div>
                <div class="step-title">Register your stall</div>
                <div class="step-desc">Sign up in minutes and verify your identity to join our community of trusted sellers.</div>
            </div>
            <div class="step">
                <div class="step-number">02</div>
                <div class="step-title">List your products</div>
                <div class="step-desc">Add beautiful photos, write detailed descriptions, and set your own prices.</div>
            </div>
            <div class="step">
                <div class="step-number">03</div>
                <div class="step-title">Start earning</div>
                <div class="step-desc">We handle the payments securely. You just pack the orders and ship them out.</div>
            </div>
        </div>
        <a href="/register" class="btn-amber">Become a Seller</a>
    </div>
</div>
@endsection
