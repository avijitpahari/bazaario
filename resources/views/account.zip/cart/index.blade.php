@extends('layouts.app')

@section('title', 'Your Cart — Bazaario')

@section('styles')
<style>
    .page-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 40px 24px;
    }
    .page-header {
        font-family: 'Fraunces', serif;
        font-size: 2.5rem;
        color: #0F172A;
        margin-bottom: 32px;
    }
    
    .cart-layout {
        display: flex;
        gap: 40px;
    }
    .cart-items-section {
        flex: 1;
    }
    .cart-sidebar {
        flex: 0 0 380px;
    }
    
    .seller-group {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        margin-bottom: 24px;
        overflow: hidden;
    }
    .seller-group.border-amber { border-left: 6px solid #F5A623; }
    .seller-group.border-green { border-left: 6px solid #16A34A; }
    
    .seller-header {
        background: #F8FAFC;
        padding: 16px 24px;
        border-bottom: 1px solid rgba(15,23,42,0.08);
        font-weight: 600;
        color: #0F172A;
    }
    .cart-item {
        display: flex;
        padding: 24px;
        border-bottom: 1px solid rgba(15,23,42,0.08);
        align-items: center;
    }
    .cart-item:last-child { border-bottom: none; }
    
    .item-image {
        width: 80px;
        height: 80px;
        background: #E2E8F0;
        border-radius: 8px;
        margin-right: 20px;
    }
    .item-details { flex: 1; }
    .item-title { font-weight: 600; color: #0F172A; margin-bottom: 4px; display: block; text-decoration: none; }
    .item-price { font-family: 'JetBrains Mono', monospace; color: #F5A623; font-weight: 700; }
    
    .item-actions {
        display: flex;
        align-items: center;
        gap: 24px;
    }
    .qty-display { font-size: 0.875rem; color: #64748B; background: #F1F5F9; padding: 4px 12px; border-radius: 9999px; }
    .btn-remove { background: none; border: none; color: #EF4444; font-size: 0.875rem; cursor: pointer; font-weight: 500; }
    
    .group-footer {
        padding: 16px 24px;
        background: #FFFFFF;
        text-align: right;
        font-size: 0.875rem;
        color: #64748B;
        border-top: 1px solid rgba(15,23,42,0.08);
    }
    .group-subtotal { font-family: 'JetBrains Mono', monospace; font-weight: 600; color: #0F172A; font-size: 1rem; margin-left: 8px; }

    .note-banner {
        background: #FEF3C7;
        color: #92400E;
        padding: 12px 20px;
        border-radius: 8px;
        font-size: 0.875rem;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 24px;
    }
    
    .summary-card {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 24px;
        position: sticky;
        top: 24px;
    }
    .summary-title { font-size: 1.25rem; font-weight: 600; margin-bottom: 24px; color: #0F172A; }
    
    .summary-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 16px;
        font-size: 0.875rem;
        color: #334155;
    }
    .summary-row.total {
        border-top: 1px solid rgba(15,23,42,0.12);
        padding-top: 16px;
        margin-top: 16px;
        font-size: 1.25rem;
        font-weight: 600;
        color: #0F172A;
    }
    .summary-price { font-family: 'JetBrains Mono', monospace; }
    .summary-price.discount { color: #16A34A; }
    .summary-price.total-amount { color: #F5A623; font-weight: 700; }
    
    .coupon-box {
        display: flex;
        gap: 8px;
        margin-bottom: 24px;
        border-bottom: 1px solid rgba(15,23,42,0.12);
        padding-bottom: 24px;
    }
    .coupon-input { flex: 1; border: 1px solid rgba(15,23,42,0.12); border-radius: 6px; padding: 8px 12px; font-size: 0.875rem; }
    .btn-apply { background: #0F172A; color: white; border: none; padding: 8px 16px; border-radius: 6px; font-size: 0.875rem; font-weight: 500; cursor: pointer; }
    
    .btn-checkout {
        background: #F5A623;
        color: #1E1B16;
        border: none;
        width: 100%;
        padding: 16px;
        border-radius: 9999px;
        font-weight: 600;
        font-size: 1rem;
        cursor: pointer;
        display: block;
        text-align: center;
        text-decoration: none;
        margin-top: 24px;
    }

    .empty-state {
        display: none; /* hidden state for reference */
        text-align: center;
        padding: 80px 24px;
        background: #FFFFFF;
        border-radius: 13px;
        border: 1px dashed rgba(15,23,42,0.2);
    }
</style>
@endsection

@section('content')
<div class="page-container">
    <h1 class="page-header">Your Cart <span style="color:#94A3B8; font-size:1.5rem;">(5 items)</span></h1>
    
    <div class="note-banner">
        <span>ℹ️</span> Items from different sellers may arrive separately.
    </div>
    
    <div class="cart-layout">
        <div class="cart-items-section">
            
            <!-- Seller Group 1 -->
            <div class="seller-group border-amber">
                <div class="seller-header">From The Leather Workshop</div>
                
                <div class="cart-item">
                    <div class="item-image" style="background:#D6D3D1;"></div>
                    <div class="item-details">
                        <a href="#" class="item-title">Handstitched Leather Wallet</a>
                        <span class="item-price">₹1,299</span>
                    </div>
                    <div class="item-actions">
                        <span class="qty-display">Qty: 1</span>
                        <button class="btn-remove">Remove</button>
                    </div>
                </div>
                
                <div class="cart-item">
                    <div class="item-image" style="background:#A8A29E;"></div>
                    <div class="item-details">
                        <a href="#" class="item-title">Leather Card Holder</a>
                        <span class="item-price">₹899</span>
                    </div>
                    <div class="item-actions">
                        <span class="qty-display">Qty: 2</span>
                        <button class="btn-remove">Remove</button>
                    </div>
                </div>
                
                <div class="group-footer">
                    Group Subtotal: <span class="group-subtotal">₹3,097</span>
                </div>
            </div>
            
            <!-- Seller Group 2 -->
            <div class="seller-group border-green">
                <div class="seller-header">From TechParts Direct</div>
                
                <div class="cart-item">
                    <div class="item-image" style="background:#E2E8F0;"></div>
                    <div class="item-details">
                        <a href="#" class="item-title">Wireless Earbuds Pro</a>
                        <span class="item-price">₹2,499</span>
                    </div>
                    <div class="item-actions">
                        <span class="qty-display">Qty: 1</span>
                        <button class="btn-remove">Remove</button>
                    </div>
                </div>
                
                <div class="cart-item">
                    <div class="item-image" style="background:#F1F5F9;"></div>
                    <div class="item-details">
                        <a href="#" class="item-title">USB-C Hub 7-port</a>
                        <span class="item-price">₹1,199</span>
                    </div>
                    <div class="item-actions">
                        <span class="qty-display">Qty: 2</span>
                        <button class="btn-remove">Remove</button>
                    </div>
                </div>
                
                <div class="cart-item">
                    <div class="item-image" style="background:#CBD5E1;"></div>
                    <div class="item-details">
                        <a href="#" class="item-title">Phone Stand</a>
                        <span class="item-price">₹349</span>
                    </div>
                    <div class="item-actions">
                        <span class="qty-display">Qty: 1</span>
                        <button class="btn-remove">Remove</button>
                    </div>
                </div>
                
                <div class="group-footer">
                    Group Subtotal: <span class="group-subtotal">₹5,246</span>
                </div>
            </div>
            
        </div>
        
        <div class="cart-sidebar">
            <div class="summary-card">
                <h2 class="summary-title">Order Summary</h2>
                
                <div class="coupon-box">
                    <input type="text" class="coupon-input" placeholder="Coupon Code" value="FIRST10">
                    <button class="btn-apply">Apply</button>
                </div>
                
                <div class="summary-row">
                    <span>Subtotal</span>
                    <span class="summary-price">₹8,343</span>
                </div>
                <div class="summary-row">
                    <span>Discount (FIRST10)</span>
                    <span class="summary-price discount">-₹834</span>
                </div>
                <div class="summary-row">
                    <span>Shipping</span>
                    <span class="summary-price" style="color:#64748B;">Calculated at checkout</span>
                </div>
                
                <div class="summary-row total">
                    <span>Total</span>
                    <span class="summary-price total-amount">₹7,509</span>
                </div>
                
                <a href="/checkout" class="btn-checkout">Proceed to Checkout</a>
            </div>
        </div>
    </div>

    <div class="empty-state">
        <div style="font-size: 4rem; margin-bottom: 24px;">🛍️</div>
        <h2 style="font-family:'Fraunces', serif; margin-bottom:12px;">Your cart is empty</h2>
        <p style="color:#64748B; margin-bottom:32px;">Looks like you haven't added anything to your cart yet.</p>
        <a href="/products" class="btn-checkout" style="width:auto; display:inline-block; padding:12px 32px;">Start Shopping</a>
    </div>
</div>
@endsection
