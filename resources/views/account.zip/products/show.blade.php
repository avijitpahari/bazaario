@extends('layouts.app')

@section('title', 'Wireless Earbuds Pro X1 — Bazaario')

@section('styles')
<style>
    .page-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 24px;
    }
    .breadcrumb {
        font-size: 0.875rem;
        color: #64748B;
        margin-bottom: 32px;
    }
    .breadcrumb a {
        color: #0F172A;
        text-decoration: none;
    }
    .breadcrumb a:hover {
        text-decoration: underline;
    }
    
    .product-layout {
        display: flex;
        gap: 48px;
        margin-bottom: 60px;
    }
    .product-gallery {
        flex: 0 0 60%;
    }
    .main-image {
        width: 100%;
        height: 480px;
        background-color: #334155; /* Slate tinted */
        border-radius: 13px;
        margin-bottom: 16px;
    }
    .thumbnail-dots {
        display: flex;
        gap: 12px;
    }
    .thumb {
        width: 80px;
        height: 80px;
        background-color: #E2E8F0;
        border-radius: 8px;
        cursor: pointer;
        border: 2px solid transparent;
    }
    .thumb.active { border-color: #F5A623; }
    
    .product-sidebar {
        flex: 0 0 calc(40% - 48px);
    }
    .summary-card {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 32px;
        position: sticky;
        top: 24px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.05);
    }
    
    .seller-info {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 24px;
        padding-bottom: 16px;
        border-bottom: 1px solid rgba(15,23,42,0.08);
    }
    .seller-name {
        font-weight: 600;
        color: #0F172A;
        text-decoration: none;
    }
    .trust-badge {
        background: #DCFCE7;
        color: #166534;
        font-size: 0.75rem;
        padding: 4px 8px;
        border-radius: 9999px;
        font-weight: 600;
        margin-left: 8px;
    }
    .btn-visit {
        font-size: 0.75rem;
        padding: 4px 12px;
        border: 1px solid #0F172A;
        border-radius: 9999px;
        color: #0F172A;
        text-decoration: none;
    }
    
    .prod-title {
        font-family: 'Fraunces', serif;
        font-size: 28px;
        color: #0F172A;
        margin-bottom: 16px;
        line-height: 1.2;
    }
    .price-wrap {
        margin-bottom: 24px;
    }
    .prod-price {
        font-family: 'JetBrains Mono', monospace;
        color: #F5A623;
        font-size: 32px;
        font-weight: 700;
    }
    .orig-price {
        font-family: 'JetBrains Mono', monospace;
        color: #94A3B8;
        text-decoration: line-through;
        font-size: 18px;
        margin-left: 12px;
    }
    .stock-badge {
        display: inline-block;
        background: #ECFCCB;
        color: #3F6212;
        font-size: 0.875rem;
        padding: 6px 12px;
        border-radius: 9999px;
        font-weight: 500;
        margin-bottom: 24px;
    }
    
    .qty-selector {
        display: flex;
        align-items: center;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 9999px;
        width: fit-content;
        margin-bottom: 24px;
    }
    .qty-btn {
        background: none; border: none; padding: 8px 16px; cursor: pointer; font-size: 1.2rem;
    }
    .qty-val {
        padding: 0 16px; font-weight: 600; font-family: 'JetBrains Mono', monospace;
    }
    
    .action-buttons {
        display: flex;
        flex-direction: column;
        gap: 12px;
        margin-bottom: 16px;
    }
    .btn-cart {
        background: #F5A623;
        color: #1E1B16;
        border: none;
        padding: 16px;
        border-radius: 9999px;
        font-weight: 600;
        font-size: 1rem;
        cursor: pointer;
        width: 100%;
        transition: background 0.2s;
    }
    .btn-buy {
        background: transparent;
        color: #0F172A;
        border: 1px solid #0F172A;
        padding: 16px;
        border-radius: 9999px;
        font-weight: 600;
        font-size: 1rem;
        cursor: pointer;
        width: 100%;
    }
    .delivery-info {
        font-size: 0.875rem;
        color: #64748B;
        text-align: center;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }
    
    /* Tabs & Content */
    .tabs {
        display: flex;
        border-bottom: 1px solid rgba(15,23,42,0.12);
        margin-bottom: 24px;
    }
    .tab {
        padding: 12px 24px;
        font-weight: 600;
        color: #64748B;
        cursor: pointer;
        border-bottom: 2px solid transparent;
    }
    .tab.active {
        color: #0F172A;
        border-bottom-color: #F5A623;
    }
    .tab-content {
        line-height: 1.6;
        color: #334155;
        margin-bottom: 48px;
    }
    .specs-table {
        width: 100%;
        border-collapse: collapse;
    }
    .specs-table th, .specs-table td {
        padding: 12px;
        border-bottom: 1px solid rgba(15,23,42,0.08);
        text-align: left;
    }
    .specs-table th { width: 30%; color: #64748B; font-weight: 500; }
    
    /* Accordion */
    .accordion { margin-bottom: 48px; }
    .accordion-item {
        border-bottom: 1px solid rgba(15,23,42,0.12);
    }
    .accordion-header {
        padding: 16px 0;
        font-weight: 600;
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .accordion-body {
        padding-bottom: 16px;
        color: #64748B;
        display: none;
    }
    
    /* Reviews */
    .reviews-section { margin-bottom: 60px; }
    .reviews-header {
        display: flex;
        align-items: center;
        gap: 16px;
        margin-bottom: 24px;
    }
    .reviews-header h2 { font-family: 'Fraunces', serif; font-size: 1.5rem; }
    .reviews-overall { font-size: 1.25rem; font-weight: 600; color: #F5A623; }
    
    .reviews-scroll {
        display: flex;
        gap: 24px;
        overflow-x: auto;
        padding-bottom: 16px;
    }
    .review-card {
        flex: 0 0 320px;
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 24px;
    }
    .review-user {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 12px;
    }
    .review-avatar { width: 40px; height: 40px; border-radius: 50%; background: #E2E8F0; }
    .review-name { font-weight: 600; font-size: 0.875rem; }
    .review-date { font-size: 0.75rem; color: #94A3B8; }
    .review-stars { color: #F5A623; margin-bottom: 12px; font-size: 0.875rem; }
    .review-text { font-size: 0.875rem; color: #334155; line-height: 1.5; }
    
    /* More from seller */
    .more-scroll {
        display: flex;
        gap: 20px;
        overflow-x: auto;
        padding-bottom: 16px;
    }
    .mini-card {
        flex: 0 0 200px;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        overflow: hidden;
        text-decoration: none;
        color: inherit;
    }
    .mini-img { height: 140px; background: #E2E8F0; }
    .mini-info { padding: 12px; }
    .mini-title { font-weight: 600; font-size: 0.875rem; margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .mini-price { font-family: 'JetBrains Mono', monospace; color: #F5A623; font-weight: 700; font-size: 0.875rem; }
</style>
@endsection

@section('content')
<div class="page-container">
    <div class="breadcrumb">
        <a href="/">Home</a> / <a href="/products?category=electronics">Electronics</a> / Wireless Earbuds Pro X1
    </div>
    
    <div class="product-layout">
        <div class="product-gallery">
            <div class="main-image"></div>
            <div class="thumbnail-dots">
                <div class="thumb active"></div>
                <div class="thumb"></div>
                <div class="thumb"></div>
                <div class="thumb"></div>
            </div>
            
            <div style="margin-top: 48px;">
                <div class="tabs">
                    <div class="tab active">Description</div>
                    <div class="tab">Specifications</div>
                    <div class="tab">Shipping</div>
                </div>
                
                <div class="tab-content">
                    <p>Experience crystal-clear audio and deep bass with the Wireless Earbuds Pro X1. Designed for active lifestyles, these earbuds feature active noise cancellation, a comfortable ergonomic fit, and up to 24 hours of total battery life with the charging case. Whether you're commuting, working out, or just relaxing, the X1 delivers premium sound quality without the hassle of wires.</p>
                    <br>
                    <table class="specs-table">
                        <tr><th>Brand</th><td>TechParts</td></tr>
                        <tr><th>Model</th><td>Pro X1</td></tr>
                        <tr><th>Battery Life</th><td>6 hours (earbuds), 24 hours (with case)</td></tr>
                        <tr><th>Connectivity</th><td>Bluetooth 5.3</td></tr>
                        <tr><th>Weight</th><td>4.5g per earbud</td></tr>
                        <tr><th>Color</th><td>Matte Black</td></tr>
                    </table>
                </div>
                
                <div class="accordion">
                    <div class="accordion-item">
                        <div class="accordion-header" onclick="this.nextElementSibling.style.display = this.nextElementSibling.style.display === 'block' ? 'none' : 'block'">
                            Return Policy <span>+</span>
                        </div>
                        <div class="accordion-body">30-day hassle-free returns. Item must be in original condition with all accessories included. Return shipping costs are covered by the buyer unless the item is defective.</div>
                    </div>
                    <div class="accordion-item">
                        <div class="accordion-header" onclick="this.nextElementSibling.style.display = this.nextElementSibling.style.display === 'block' ? 'none' : 'block'">
                            Shipping Policy <span>+</span>
                        </div>
                        <div class="accordion-body">Seller ships within 2 business days. Standard delivery usually takes 3-5 business days depending on location.</div>
                    </div>
                    <div class="accordion-item">
                        <div class="accordion-header" onclick="this.nextElementSibling.style.display = this.nextElementSibling.style.display === 'block' ? 'none' : 'block'">
                            Payment Policy <span>+</span>
                        </div>
                        <div class="accordion-body">Secure payments handled by Bazaario. Cash on Delivery available for selected pincodes.</div>
                    </div>
                </div>
                
                <div class="reviews-section">
                    <div class="reviews-header">
                        <h2>Customer Reviews</h2>
                        <span class="reviews-overall">★ 4.7 <span style="font-size:1rem; color:#64748B; font-weight:normal;">(312 reviews)</span></span>
                    </div>
                    
                    <div class="reviews-scroll">
                        <div class="review-card">
                            <div class="review-user">
                                <div class="review-avatar"></div>
                                <div>
                                    <div class="review-name">Rahul M.</div>
                                    <div class="review-date">12 Aug 2024</div>
                                </div>
                            </div>
                            <div class="review-stars">★★★★★</div>
                            <div class="review-text">Amazing sound quality and the ANC works really well on my commute. Definitely worth the price!</div>
                        </div>
                        
                        <div class="review-card">
                            <div class="review-user">
                                <div class="review-avatar" style="background:#FEE2E2;"></div>
                                <div>
                                    <div class="review-name">Sneha P.</div>
                                    <div class="review-date">05 Aug 2024</div>
                                </div>
                            </div>
                            <div class="review-stars">★★★★☆</div>
                            <div class="review-text">Good earbuds, battery life is solid. Only giving 4 stars because the case feels a bit plasticky.</div>
                        </div>
                        
                        <div class="review-card">
                            <div class="review-user">
                                <div class="review-avatar" style="background:#DCFCE7;"></div>
                                <div>
                                    <div class="review-name">Vikram S.</div>
                                    <div class="review-date">28 Jul 2024</div>
                                </div>
                            </div>
                            <div class="review-stars">★★★★★</div>
                            <div class="review-text">Fast delivery from TechParts Direct. The pairing was seamless with my phone. Highly recommend.</div>
                        </div>
                    </div>
                </div>
                
                <div>
                    <h2 style="font-family:'Fraunces', serif; margin-bottom:24px;">More from TechParts Direct</h2>
                    <div class="more-scroll">
                        <a href="#" class="mini-card">
                            <div class="mini-img" style="background:#F1F5F9;"></div>
                            <div class="mini-info">
                                <div class="mini-title">USB-C Hub 7-port</div>
                                <div class="mini-price">₹1,199</div>
                            </div>
                        </a>
                        <a href="#" class="mini-card">
                            <div class="mini-img" style="background:#E2E8F0;"></div>
                            <div class="mini-info">
                                <div class="mini-title">Phone Stand</div>
                                <div class="mini-price">₹349</div>
                            </div>
                        </a>
                        <a href="#" class="mini-card">
                            <div class="mini-img" style="background:#CBD5E1;"></div>
                            <div class="mini-info">
                                <div class="mini-title">Fast Charger 65W</div>
                                <div class="mini-price">₹1,499</div>
                            </div>
                        </a>
                        <a href="#" class="mini-card">
                            <div class="mini-img" style="background:#94A3B8;"></div>
                            <div class="mini-info">
                                <div class="mini-title">Laptop Sleeve 14"</div>
                                <div class="mini-price">₹899</div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="product-sidebar">
            <div class="summary-card">
                <div class="seller-info">
                    <div>
                        <a href="/stall/techparts" class="seller-name">TechParts Direct</a>
                        <span class="trust-badge">Trust Score: 94/100</span>
                    </div>
                    <a href="/stall/techparts" class="btn-visit">Visit Stall</a>
                </div>
                
                <h1 class="prod-title">Wireless Earbuds Pro X1</h1>
                
                <div class="price-wrap">
                    <span class="prod-price">₹2,499</span>
                    <span class="orig-price">₹3,999</span>
                </div>
                
                <div class="stock-badge">✓ In Stock — 47 units left</div>
                
                <div class="qty-selector">
                    <button class="qty-btn">−</button>
                    <span class="qty-val">1</span>
                    <button class="qty-btn">+</button>
                </div>
                
                <div class="action-buttons">
                    <button class="btn-cart">Add to Cart</button>
                    <button class="btn-buy">Buy Now</button>
                </div>
                
                <div class="delivery-info">
                    <span>📦 Ships in 2-4 business days</span>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
