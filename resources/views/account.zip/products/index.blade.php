@extends('layouts.app')

@section('title', 'Products — Bazaario')

@section('styles')
<style>
    .page-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 40px 24px;
    }
    .filter-bar {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        padding: 16px 24px;
        margin-bottom: 32px;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 24px;
        justify-content: space-between;
    }
    .category-pills {
        display: flex;
        gap: 12px;
        overflow-x: auto;
        padding-bottom: 4px;
    }
    .pill {
        padding: 6px 16px;
        border-radius: 9999px;
        font-size: 0.875rem;
        font-weight: 500;
        color: #1E1B16;
        text-decoration: none;
        background: #F1F5F9;
        white-space: nowrap;
        transition: background 0.2s;
    }
    .pill.active {
        background: #F5A623;
    }
    .pill:hover:not(.active) {
        background: #E2E8F0;
    }
    .filter-controls {
        display: flex;
        gap: 16px;
        align-items: center;
    }
    .filter-input, .filter-select {
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 6px;
        padding: 8px 12px;
        font-size: 0.875rem;
        background: white;
    }
    .filter-input { width: 80px; }
    .results-count {
        font-size: 0.875rem;
        color: #64748B;
        font-weight: 500;
    }

    .product-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 24px;
    }
    .product-card {
        background: #FFFFFF;
        border: 1px solid rgba(15,23,42,0.12);
        border-radius: 13px;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        transition: box-shadow 0.2s ease;
    }
    .product-card:hover {
        box-shadow: 0 10px 25px rgba(15,23,42,0.08);
    }
    .product-image {
        width: 100%;
        height: 200px;
        background-color: #E2E8F0;
        position: relative;
    }
    .product-badge {
        position: absolute;
        top: 12px;
        left: 12px;
        font-size: 0.75rem;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 9999px;
    }
    .badge-bestseller { background: #F5A623; color: #1E1B16; }
    .badge-lowstock { background: #FEE2E2; color: #991B1B; }
    
    .product-info {
        padding: 16px;
        display: flex;
        flex-direction: column;
        flex: 1;
    }
    .product-seller {
        font-size: 0.75rem;
        color: #64748B;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 4px;
        text-decoration: none;
    }
    .product-name {
        font-family: 'Inter', sans-serif;
        font-weight: 600;
        font-size: 1rem;
        color: #0F172A;
        margin-bottom: 8px;
        text-decoration: none;
        line-height: 1.4;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
    .product-rating {
        font-size: 0.875rem;
        color: #F5A623;
        margin-bottom: 12px;
    }
    .product-rating span { color: #64748B; margin-left: 4px; font-size: 0.75rem; }
    
    .product-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: auto;
    }
    .product-price {
        font-family: 'JetBrains Mono', monospace;
        font-size: 1.25rem;
        font-weight: 700;
        color: #F5A623;
    }
    .btn-add {
        background: #0F172A;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 9999px;
        font-size: 0.875rem;
        font-weight: 500;
        cursor: pointer;
        transition: background 0.2s;
    }
    .btn-add:hover { background: #1E293B; }

    .load-more {
        text-align: center;
        margin-top: 48px;
    }
    .btn-outline {
        background: transparent;
        border: 2px solid #0F172A;
        color: #0F172A;
        padding: 12px 32px;
        border-radius: 9999px;
        font-weight: 600;
        cursor: pointer;
        font-size: 1rem;
    }
    .btn-outline:hover { background: #0F172A; color: white; }

    .empty-state {
        display: none; /* hidden for reference as requested */
        text-align: center;
        padding: 80px 24px;
    }
</style>
@endsection

@section('content')
<div class="page-container">
    <div class="filter-bar">
        <div class="category-pills">
            <a href="#" class="pill active">All</a>
            <a href="#" class="pill">Electronics</a>
            <a href="#" class="pill">Fashion</a>
            <a href="#" class="pill">Home & Garden</a>
            <a href="#" class="pill">Sports</a>
            <a href="#" class="pill">Books</a>
        </div>
        
        <div class="filter-controls">
            <div style="display:flex; align-items:center; gap:8px;">
                <input type="number" placeholder="Min ₹" class="filter-input">
                <span>-</span>
                <input type="number" placeholder="Max ₹" class="filter-input">
            </div>
            <select class="filter-select">
                <option>4★ & above</option>
                <option>3★ & above</option>
                <option>All Ratings</option>
            </select>
            <select class="filter-select">
                <option>Most Popular</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
                <option>Newest</option>
            </select>
        </div>
        
        <div class="results-count">Showing 48 products</div>
    </div>

    <div class="product-grid">
        <!-- Product 1 -->
        <div class="product-card">
            <div class="product-image" style="background: #D6D3D1;">
                <span class="product-badge badge-bestseller">Bestseller</span>
            </div>
            <div class="product-info">
                <a href="/stall/leather-workshop" class="product-seller">The Leather Workshop</a>
                <a href="/products/handstitched-wallet" class="product-name">Handstitched Leather Wallet</a>
                <div class="product-rating">★★★★★ <span>(124)</span></div>
                <div class="product-footer">
                    <span class="product-price">₹1,299</span>
                    <button class="btn-add">Add to Cart</button>
                </div>
            </div>
        </div>

        <!-- Product 2 -->
        <div class="product-card">
            <div class="product-image" style="background: #E2E8F0;">
                <span class="product-badge badge-lowstock">Only 3 left</span>
            </div>
            <div class="product-info">
                <a href="/stall/techparts" class="product-seller">TechParts Direct</a>
                <a href="/products/wireless-earbuds" class="product-name">Wireless Earbuds Pro</a>
                <div class="product-rating">★★★★☆ <span>(89)</span></div>
                <div class="product-footer">
                    <span class="product-price">₹2,499</span>
                    <button class="btn-add">Add to Cart</button>
                </div>
            </div>
        </div>

        <!-- Product 3 -->
        <div class="product-card">
            <div class="product-image" style="background: #F1F5F9;"></div>
            <div class="product-info">
                <a href="/stall/home-essentials" class="product-seller">Home Essentials</a>
                <a href="/products/linen-pillow" class="product-name">Linen Throw Pillow</a>
                <div class="product-rating">★★★★★ <span>(42)</span></div>
                <div class="product-footer">
                    <span class="product-price">₹649</span>
                    <button class="btn-add">Add to Cart</button>
                </div>
            </div>
        </div>

        <!-- Product 4 -->
        <div class="product-card">
            <div class="product-image" style="background: #FFEDD5;"></div>
            <div class="product-info">
                <a href="/stall/heritage-spices" class="product-seller">Heritage Spices</a>
                <a href="/products/spice-blend" class="product-name">Heritage Spice Blend</a>
                <div class="product-rating">★★★★★ <span>(210)</span></div>
                <div class="product-footer">
                    <span class="product-price">₹349</span>
                    <button class="btn-add">Add to Cart</button>
                </div>
            </div>
        </div>

        <!-- Product 5 -->
        <div class="product-card">
            <div class="product-image" style="background: #F3F4F6;"></div>
            <div class="product-info">
                <a href="/stall/active-gear" class="product-seller">Active Gear</a>
                <a href="/products/running-shoes" class="product-name">Running Shoes Ultra</a>
                <div class="product-rating">★★★★☆ <span>(67)</span></div>
                <div class="product-footer">
                    <span class="product-price">₹3,999</span>
                    <button class="btn-add">Add to Cart</button>
                </div>
            </div>
        </div>

        <!-- Product 6 -->
        <div class="product-card">
            <div class="product-image" style="background: #FEF3C7;"></div>
            <div class="product-info">
                <a href="/stall/vintage-finds" class="product-seller">Vintage Finds</a>
                <a href="/products/desk-lamp" class="product-name">Vintage Desk Lamp</a>
                <div class="product-rating">★★★★★ <span>(12)</span></div>
                <div class="product-footer">
                    <span class="product-price">₹1,899</span>
                    <button class="btn-add">Add to Cart</button>
                </div>
            </div>
        </div>

        <!-- Product 7 -->
        <div class="product-card">
            <div class="product-image" style="background: #ECFCCB;"></div>
            <div class="product-info">
                <a href="/stall/eco-home" class="product-seller">Eco Home</a>
                <a href="/products/cutting-board" class="product-name">Bamboo Cutting Board</a>
                <div class="product-rating">★★★★☆ <span>(54)</span></div>
                <div class="product-footer">
                    <span class="product-price">₹849</span>
                    <button class="btn-add">Add to Cart</button>
                </div>
            </div>
        </div>

        <!-- Product 8 -->
        <div class="product-card">
            <div class="product-image" style="background: #F1F5F9;"></div>
            <div class="product-info">
                <a href="/stall/techparts" class="product-seller">TechParts Direct</a>
                <a href="/products/mech-keyboard" class="product-name">Mechanical Keyboard</a>
                <div class="product-rating">★★★★★ <span>(312)</span></div>
                <div class="product-footer">
                    <span class="product-price">₹4,500</span>
                    <button class="btn-add">Add to Cart</button>
                </div>
            </div>
        </div>

        <!-- Product 9 -->
        <div class="product-card">
            <div class="product-image" style="background: #FCE7F3;"></div>
            <div class="product-info">
                <a href="/stall/bloom-co" class="product-seller">Bloom & Co.</a>
                <a href="/products/soy-candle" class="product-name">Hand-Poured Soy Candle</a>
                <div class="product-rating">★★★★★ <span>(88)</span></div>
                <div class="product-footer">
                    <span class="product-price">₹599</span>
                    <button class="btn-add">Add to Cart</button>
                </div>
            </div>
        </div>

        <!-- Product 10 -->
        <div class="product-card">
            <div class="product-image" style="background: #E0F2FE;"></div>
            <div class="product-info">
                <a href="/stall/active-gear" class="product-seller">Active Gear</a>
                <a href="/products/water-bottle" class="product-name">Stainless Water Bottle</a>
                <div class="product-rating">★★★★☆ <span>(145)</span></div>
                <div class="product-footer">
                    <span class="product-price">₹799</span>
                    <button class="btn-add">Add to Cart</button>
                </div>
            </div>
        </div>

        <!-- Product 11 -->
        <div class="product-card">
            <div class="product-image" style="background: #FEF9C3;"></div>
            <div class="product-info">
                <a href="/stall/bloom-co" class="product-seller">Bloom & Co.</a>
                <a href="/products/plant-pot" class="product-name">Ceramic Plant Pot</a>
                <div class="product-rating">★★★★★ <span>(34)</span></div>
                <div class="product-footer">
                    <span class="product-price">₹449</span>
                    <button class="btn-add">Add to Cart</button>
                </div>
            </div>
        </div>

        <!-- Product 12 -->
        <div class="product-card">
            <div class="product-image" style="background: #F3F4F6;"></div>
            <div class="product-info">
                <a href="/stall/leather-workshop" class="product-seller">The Leather Workshop</a>
                <a href="/products/notebook" class="product-name">Hardcover Notebook</a>
                <div class="product-rating">★★★★★ <span>(56)</span></div>
                <div class="product-footer">
                    <span class="product-price">₹299</span>
                    <button class="btn-add">Add to Cart</button>
                </div>
            </div>
        </div>
    </div>

    <div class="load-more">
        <button class="btn-outline">Load More</button>
    </div>

    <div class="empty-state">
        <div style="font-size: 4rem; margin-bottom: 16px;">🔍</div>
        <h3>No products found</h3>
        <p style="color: #64748B; margin-bottom: 24px;">Try adjusting your filters or search query.</p>
        <button class="btn-outline">Clear filters</button>
    </div>
</div>
@endsection
