@extends('layouts.admin')

@section('title', 'Categories')

@section('styles')
<style>
    .page-wrapper { margin-left: 220px; padding-top: 64px; padding-left: 2rem; padding-right: 2rem; padding-bottom: 2rem; background-color: #FFFDF8; min-height: 100vh; font-family: 'Inter', sans-serif; color: #1E1B16; }
    h1, h2, h3 { font-family: 'Fraunces', serif; color: #0F172A; margin-top: 0; }
    .card { background: #FFFFFF; border-radius: 13px; border: 1px solid rgba(15,23,42,0.12); padding: 1.5rem; }
    .header-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
    .btn-amber { background: #F5A623; color: white; border-radius: 9999px; padding: 0.6rem 1.25rem; border: none; cursor: pointer; font-weight: 500; font-size: 0.875rem; font-family: 'Inter', sans-serif; }
    .btn-amber:hover { background: #d97706; }
    .grid-60-40 { display: grid; grid-template-columns: 3fr 2fr; gap: 1.5rem; }
    
    .cat-list { list-style: none; padding: 0; margin: 0; }
    .cat-item { margin-bottom: 0.5rem; }
    .cat-row { display: flex; justify-content: space-between; align-items: center; padding: 0.75rem; border: 1px solid rgba(15,23,42,0.08); border-radius: 8px; background: #fff; transition: background 0.2s; }
    .cat-row:hover { background: #f8fafc; }
    .cat-info { display: flex; align-items: center; gap: 0.5rem; }
    .cat-name { font-weight: 600; color: #0F172A; }
    .cat-count { font-size: 0.75rem; color: #64748b; font-family: 'JetBrains Mono', monospace; background: #f1f5f9; padding: 0.1rem 0.5rem; border-radius: 9999px; }
    .cat-actions { display: flex; gap: 0.5rem; }
    .action-icon { background: none; border: none; cursor: pointer; font-size: 0.875rem; color: #475569; padding: 0.25rem; }
    .action-icon:hover { color: #0F172A; }
    .action-icon.disabled { color: #cbd5e1; cursor: not-allowed; }
    
    .child-list { list-style: none; padding-left: 2rem; margin-top: 0.5rem; }
    
    .form-group { margin-bottom: 1.25rem; }
    .form-label { display: block; font-weight: 500; font-size: 0.875rem; margin-bottom: 0.5rem; color: #0F172A; }
    .form-control { width: 100%; box-sizing: border-box; padding: 0.6rem 1rem; border: 1px solid rgba(15,23,42,0.12); border-radius: 8px; font-family: 'Inter', sans-serif; font-size: 0.875rem; outline: none; transition: border-color 0.2s; }
    .form-control:focus { border-color: #F5A623; }
</style>
@endsection

@section('content')
<div class="page-wrapper">
    <div class="header-row">
        <h1 style="margin: 0;">Categories</h1>
        <button class="btn-amber">Add Category</button>
    </div>
    
    <div class="grid-60-40">
        <div class="card">
            <h2 style="font-size: 1.25rem; margin-bottom: 1.5rem;">Category Hierarchy</h2>
            <ul class="cat-list">
                <li class="cat-item">
                    <div class="cat-row">
                        <div class="cat-info">
                            <span class="cat-name">Electronics</span>
                            <span class="cat-count">142 products</span>
                        </div>
                        <div class="cat-actions">
                            <button class="action-icon" title="Edit">✎ Edit</button>
                            <button class="action-icon disabled" title="Cannot delete category with products">🗑 Delete</button>
                        </div>
                    </div>
                    <ul class="child-list">
                        <li class="cat-item">
                            <div class="cat-row">
                                <div class="cat-info">
                                    <span class="cat-name">Phones & Tablets</span>
                                    <span class="cat-count">48</span>
                                </div>
                                <div class="cat-actions">
                                    <button class="action-icon" title="Edit">✎</button>
                                    <button class="action-icon disabled" title="Delete">🗑</button>
                                </div>
                            </div>
                        </li>
                        <li class="cat-item">
                            <div class="cat-row">
                                <div class="cat-info">
                                    <span class="cat-name">Computers & Laptops</span>
                                    <span class="cat-count">31</span>
                                </div>
                                <div class="cat-actions">
                                    <button class="action-icon" title="Edit">✎</button>
                                    <button class="action-icon disabled" title="Delete">🗑</button>
                                </div>
                            </div>
                        </li>
                        <li class="cat-item">
                            <div class="cat-row">
                                <div class="cat-info">
                                    <span class="cat-name">Audio</span>
                                    <span class="cat-count">28</span>
                                </div>
                                <div class="cat-actions">
                                    <button class="action-icon" title="Edit">✎</button>
                                    <button class="action-icon disabled" title="Delete">🗑</button>
                                </div>
                            </div>
                        </li>
                        <li class="cat-item">
                            <div class="cat-row">
                                <div class="cat-info">
                                    <span class="cat-name">Accessories</span>
                                    <span class="cat-count">35</span>
                                </div>
                                <div class="cat-actions">
                                    <button class="action-icon" title="Edit">✎</button>
                                    <button class="action-icon disabled" title="Delete">🗑</button>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                
                <li class="cat-item">
                    <div class="cat-row">
                        <div class="cat-info">
                            <span class="cat-name">Fashion</span>
                            <span class="cat-count">289 products</span>
                        </div>
                        <div class="cat-actions">
                            <button class="action-icon" title="Edit">✎ Edit</button>
                            <button class="action-icon disabled" title="Delete">🗑 Delete</button>
                        </div>
                    </div>
                    <ul class="child-list">
                        <li class="cat-item">
                            <div class="cat-row">
                                <div class="cat-info">
                                    <span class="cat-name">Men's Clothing</span>
                                    <span class="cat-count">112</span>
                                </div>
                                <div class="cat-actions"><button class="action-icon">✎</button><button class="action-icon disabled">🗑</button></div>
                            </div>
                        </li>
                        <li class="cat-item">
                            <div class="cat-row">
                                <div class="cat-info">
                                    <span class="cat-name">Women's Clothing</span>
                                    <span class="cat-count">134</span>
                                </div>
                                <div class="cat-actions"><button class="action-icon">✎</button><button class="action-icon disabled">🗑</button></div>
                            </div>
                        </li>
                        <li class="cat-item">
                            <div class="cat-row">
                                <div class="cat-info">
                                    <span class="cat-name">Footwear</span>
                                    <span class="cat-count">43</span>
                                </div>
                                <div class="cat-actions"><button class="action-icon">✎</button><button class="action-icon disabled">🗑</button></div>
                            </div>
                        </li>
                    </ul>
                </li>
                
                <li class="cat-item">
                    <div class="cat-row">
                        <div class="cat-info"><span class="cat-name">Home & Garden</span><span class="cat-count">198 products</span></div>
                        <div class="cat-actions"><button class="action-icon">✎ Edit</button><button class="action-icon disabled">🗑 Delete</button></div>
                    </div>
                    <ul class="child-list">
                        <li class="cat-item"><div class="cat-row"><div class="cat-info"><span class="cat-name">Furniture</span><span class="cat-count">67</span></div><div class="cat-actions"><button class="action-icon">✎</button><button class="action-icon disabled">🗑</button></div></div></li>
                        <li class="cat-item"><div class="cat-row"><div class="cat-info"><span class="cat-name">Kitchen</span><span class="cat-count">89</span></div><div class="cat-actions"><button class="action-icon">✎</button><button class="action-icon disabled">🗑</button></div></div></li>
                        <li class="cat-item"><div class="cat-row"><div class="cat-info"><span class="cat-name">Garden</span><span class="cat-count">42</span></div><div class="cat-actions"><button class="action-icon">✎</button><button class="action-icon disabled">🗑</button></div></div></li>
                    </ul>
                </li>
                
                <li class="cat-item"><div class="cat-row"><div class="cat-info"><span class="cat-name">Food & Gourmet</span><span class="cat-count">312 products</span></div><div class="cat-actions"><button class="action-icon">✎ Edit</button><button class="action-icon disabled">🗑 Delete</button></div></div>
                    <ul class="child-list">
                        <li class="cat-item"><div class="cat-row"><div class="cat-info"><span class="cat-name">Spices & Condiments</span><span class="cat-count">89</span></div><div class="cat-actions"><button class="action-icon">✎</button><button class="action-icon disabled">🗑</button></div></div></li>
                        <li class="cat-item"><div class="cat-row"><div class="cat-info"><span class="cat-name">Beverages</span><span class="cat-count">67</span></div><div class="cat-actions"><button class="action-icon">✎</button><button class="action-icon disabled">🗑</button></div></div></li>
                        <li class="cat-item"><div class="cat-row"><div class="cat-info"><span class="cat-name">Snacks</span><span class="cat-count">156</span></div><div class="cat-actions"><button class="action-icon">✎</button><button class="action-icon disabled">🗑</button></div></div></li>
                    </ul>
                </li>
                
                <li class="cat-item"><div class="cat-row"><div class="cat-info"><span class="cat-name">Books</span><span class="cat-count">156 products</span></div><div class="cat-actions"><button class="action-icon">✎ Edit</button><button class="action-icon disabled">🗑 Delete</button></div></div></li>
                <li class="cat-item"><div class="cat-row"><div class="cat-info"><span class="cat-name">Sports</span><span class="cat-count">78 products</span></div><div class="cat-actions"><button class="action-icon">✎ Edit</button><button class="action-icon disabled">🗑 Delete</button></div></div></li>
                <li class="cat-item"><div class="cat-row"><div class="cat-info"><span class="cat-name">Toys</span><span class="cat-count">65 products</span></div><div class="cat-actions"><button class="action-icon">✎ Edit</button><button class="action-icon disabled">🗑 Delete</button></div></div></li>
                <li class="cat-item"><div class="cat-row"><div class="cat-info"><span class="cat-name">Art & Crafts</span><span class="cat-count">93 products</span></div><div class="cat-actions"><button class="action-icon">✎ Edit</button><button class="action-icon disabled">🗑 Delete</button></div></div></li>
            </ul>
        </div>
        
        <div class="card" style="align-self: start;">
            <h2 style="font-size: 1.25rem; margin-bottom: 1.5rem;">Add / Edit Category</h2>
            <form action="#" method="POST">
                <div class="form-group">
                    <label class="form-label">Category Name</label>
                    <input type="text" class="form-control" placeholder="e.g. Vintage Electronics">
                </div>
                <div class="form-group">
                    <label class="form-label">Slug</label>
                    <input type="text" class="form-control" placeholder="e.g. vintage-electronics" readonly style="background: #f8fafc; color: #64748b;">
                </div>
                <div class="form-group">
                    <label class="form-label">Parent Category</label>
                    <select class="form-control">
                        <option value="">-- Top-level category --</option>
                        <option value="1">Electronics</option>
                        <option value="2">Fashion</option>
                        <option value="3">Home & Garden</option>
                        <option value="4">Food & Gourmet</option>
                        <option value="5">Books</option>
                    </select>
                </div>
                <button type="button" class="btn-amber" style="width: 100%; margin-top: 1rem;">Save Category</button>
            </form>
        </div>
    </div>
</div>
@endsection
