@extends('layouts.admin')

@section('title', 'All Orders')

@section('styles')
<style>
    .page-wrapper { margin-left: 220px; padding-top: 64px; padding-left: 2rem; padding-right: 2rem; padding-bottom: 2rem; background-color: #FFFDF8; min-height: 100vh; font-family: 'Inter', sans-serif; color: #1E1B16; }
    h1, h2, h3 { font-family: 'Fraunces', serif; color: #0F172A; }
    .card { background: #FFFFFF; border-radius: 13px; border: 1px solid rgba(15,23,42,0.12); padding: 1.5rem; }
    .header-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
    .header-filters { display: flex; gap: 1rem; align-items: center; }
    .input-field, .select-field { padding: 0.5rem 1rem; border: 1px solid rgba(15,23,42,0.12); border-radius: 8px; font-family: 'Inter', sans-serif; font-size: 0.875rem; outline: none; }
    .table-wrapper { width: 100%; overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; text-align: left; }
    th { border-bottom: 2px solid rgba(15,23,42,0.12); padding: 1rem 0.5rem; color: #0F172A; font-weight: 600; font-size: 0.875rem; }
    td { border-bottom: 1px solid rgba(15,23,42,0.06); padding: 1rem 0.5rem; font-size: 0.875rem; vertical-align: middle; }
    tr:hover { background-color: #f8fafc; }
    .pill { display: inline-block; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 500; }
    .pill-green { background: #dcfce7; color: #16A34A; }
    .pill-amber { background: #fef3c7; color: #d97706; }
    .pill-red { background: #fee2e2; color: #ef4444; }
    .pill-slate { background: #f1f5f9; color: #475569; border: 1px solid rgba(15,23,42,0.08); }
    .seller-tags { display: flex; flex-direction: column; gap: 4px; }
    .mono { font-family: 'JetBrains Mono', monospace; }
    .action-link { color: #475569; text-decoration: none; font-weight: 500; font-size: 0.875rem; }
    .action-link:hover { color: #0F172A; text-decoration: underline; }
    .action-link.resolve-btn { color: #F5A623; font-weight: 600; }
    .action-sep { color: #cbd5e1; margin: 0 0.25rem; }
    
    /* Modal Styles */
    .modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15,23,42,0.6); display: none; align-items: center; justify-content: center; z-index: 1000; }
    .modal-card { background: #fff; width: 500px; border-radius: 13px; padding: 2rem; box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
    .modal-card h2 { margin-top: 0; margin-bottom: 1.5rem; }
    .modal-summary { background: #f8fafc; border-radius: 8px; padding: 1rem; margin-bottom: 1.5rem; border: 1px solid rgba(15,23,42,0.08); }
    .modal-summary p { margin: 0 0 0.5rem 0; font-size: 0.875rem; }
    .form-group { margin-bottom: 1.25rem; }
    .form-label { display: block; font-weight: 500; font-size: 0.875rem; margin-bottom: 0.5rem; color: #0F172A; }
    .form-control { width: 100%; box-sizing: border-box; padding: 0.6rem 1rem; border: 1px solid rgba(15,23,42,0.12); border-radius: 8px; font-family: 'Inter', sans-serif; font-size: 0.875rem; outline: none; }
    .modal-actions { display: flex; justify-content: flex-end; gap: 1rem; margin-top: 2rem; }
    .btn-amber { background: #F5A623; color: white; border-radius: 9999px; padding: 0.6rem 1.25rem; border: none; cursor: pointer; font-weight: 500; }
    .btn-slate { background: #f1f5f9; color: #0F172A; border-radius: 9999px; padding: 0.6rem 1.25rem; border: none; cursor: pointer; font-weight: 500; }
</style>
@endsection

@section('content')
<div class="page-wrapper">
    <div class="header-row">
        <h1 style="margin: 0;">All Orders</h1>
        <div class="header-filters">
            <input type="text" class="input-field" placeholder="Search Order ID or Customer">
            <input type="date" class="input-field" title="Start Date">
            <input type="date" class="input-field" title="End Date">
            <select class="select-field">
                <option value="all">Status: All</option>
                <option value="processing">Processing</option>
                <option value="shipped">Shipped</option>
                <option value="delivered">Delivered</option>
                <option value="cancelled">Cancelled</option>
                <option value="disputed">Disputed</option>
            </select>
        </div>
    </div>
    
    <div class="card">
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Sellers</th>
                        <th>Items</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Payment</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="mono">#BZR-08471</td>
                        <td>Rahul S.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">Leather Workshop</span>
                                <span class="pill pill-slate">TechParts Direct</span>
                            </div>
                        </td>
                        <td>5 items</td>
                        <td class="mono">₹7,509</td>
                        <td><span class="pill pill-green">Delivered</span></td>
                        <td>COD</td>
                        <td>25 Aug 2026</td>
                        <td>
                            <a href="#" class="action-link">View</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link">Dispute</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08472</td>
                        <td>Sneha M.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">Bloom & Co.</span>
                            </div>
                        </td>
                        <td>1 item</td>
                        <td class="mono">₹1,250</td>
                        <td><span class="pill pill-amber">Processing</span></td>
                        <td>Card</td>
                        <td>25 Aug 2026</td>
                        <td>
                            <a href="#" class="action-link">View</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link">Dispute</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08473</td>
                        <td>Vikram P.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">TechParts Direct</span>
                            </div>
                        </td>
                        <td>1 item</td>
                        <td class="mono">₹45,000</td>
                        <td><span class="pill pill-red">Disputed</span></td>
                        <td>Card</td>
                        <td>24 Aug 2026</td>
                        <td>
                            <a href="#" class="action-link">View</a>
                            <span class="action-sep">·</span>
                            <button class="action-link resolve-btn" style="background:none;border:none;cursor:pointer;padding:0;font-family:inherit;" onclick="document.getElementById('disputeModal').style.display='flex'">Resolve</button>
                        </td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08474</td>
                        <td>Amit K.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">Heritage Spices</span>
                                <span class="pill pill-slate">Mountain Brews</span>
                                <span class="pill pill-slate">Nordic Woodcraft</span>
                            </div>
                        </td>
                        <td>8 items</td>
                        <td class="mono">₹12,400</td>
                        <td><span class="pill pill-amber">Shipped</span></td>
                        <td>UPI</td>
                        <td>24 Aug 2026</td>
                        <td>
                            <a href="#" class="action-link">View</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link">Dispute</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08475</td>
                        <td>Rohan T.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">RetroGadgets</span>
                            </div>
                        </td>
                        <td>3 items</td>
                        <td class="mono">₹5,600</td>
                        <td><span class="pill pill-slate" style="color: #64748b;">Cancelled</span></td>
                        <td>UPI</td>
                        <td>23 Aug 2026</td>
                        <td>
                            <a href="#" class="action-link">View</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08476</td>
                        <td>Priya D.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">UrbanThreads</span>
                            </div>
                        </td>
                        <td>2 items</td>
                        <td class="mono">₹3,400</td>
                        <td><span class="pill pill-green">Delivered</span></td>
                        <td>Card</td>
                        <td>23 Aug 2026</td>
                        <td>
                            <a href="#" class="action-link">View</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link">Dispute</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08477</td>
                        <td>Neha J.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">Crafty Hands</span>
                                <span class="pill pill-slate">The Book Nook</span>
                            </div>
                        </td>
                        <td>4 items</td>
                        <td class="mono">₹2,100</td>
                        <td><span class="pill pill-green">Delivered</span></td>
                        <td>COD</td>
                        <td>22 Aug 2026</td>
                        <td>
                            <a href="#" class="action-link">View</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link">Dispute</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08478</td>
                        <td>Kavita L.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">Heritage Spices</span>
                            </div>
                        </td>
                        <td>12 items</td>
                        <td class="mono">₹1,850</td>
                        <td><span class="pill pill-green">Delivered</span></td>
                        <td>UPI</td>
                        <td>21 Aug 2026</td>
                        <td>
                            <a href="#" class="action-link">View</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link">Dispute</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08479</td>
                        <td>Sameer W.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">TechParts Direct</span>
                            </div>
                        </td>
                        <td>1 item</td>
                        <td class="mono">₹8,500</td>
                        <td><span class="pill pill-red">Disputed</span></td>
                        <td>Card</td>
                        <td>20 Aug 2026</td>
                        <td>
                            <a href="#" class="action-link">View</a>
                            <span class="action-sep">·</span>
                            <button class="action-link resolve-btn" style="background:none;border:none;cursor:pointer;padding:0;font-family:inherit;" onclick="document.getElementById('disputeModal').style.display='flex'">Resolve</button>
                        </td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08480</td>
                        <td>Sonia B.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">The Leather Workshop</span>
                            </div>
                        </td>
                        <td>2 items</td>
                        <td class="mono">₹4,200</td>
                        <td><span class="pill pill-green">Delivered</span></td>
                        <td>COD</td>
                        <td>19 Aug 2026</td>
                        <td>
                            <a href="#" class="action-link">View</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link">Dispute</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Dispute Resolution Modal -->
<div class="modal-overlay" id="disputeModal">
    <div class="modal-card">
        <h2>Resolve Dispute</h2>
        <div class="modal-summary">
            <p><strong>Order ID:</strong> <span class="mono">#BZR-08473</span></p>
            <p><strong>Customer:</strong> Vikram P.</p>
            <p><strong>Seller:</strong> TechParts Direct</p>
            <p style="margin-top: 1rem;"><strong>Issue Description:</strong></p>
            <p style="color: #475569;">"The item arrived damaged and the packaging was torn. I requested a replacement but the seller is unresponsive."</p>
        </div>
        
        <div class="form-group">
            <label class="form-label">Resolution Action</label>
            <select class="form-control">
                <option value="">-- Select an action --</option>
                <option value="refund">Refund Customer (Full)</option>
                <option value="partial">Partial Refund</option>
                <option value="favour">Favour Seller (Close Dispute)</option>
            </select>
        </div>
        
        <div class="form-group">
            <label class="form-label">Admin Notes (Internal)</label>
            <textarea class="form-control" rows="3" placeholder="Add resolution reasoning..."></textarea>
        </div>
        
        <div class="modal-actions">
            <button class="btn-slate" onclick="document.getElementById('disputeModal').style.display='none'">Cancel</button>
            <button class="btn-amber" onclick="document.getElementById('disputeModal').style.display='none'">Log Resolution</button>
        </div>
    </div>
</div>
@endsection
