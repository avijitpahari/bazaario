@extends('layouts.admin')

@section('title', 'Admin Dashboard')

@section('styles')
<style>
    .page-wrapper { margin-left: 220px; padding-top: 64px; padding-left: 2rem; padding-right: 2rem; padding-bottom: 2rem; background-color: #FFFDF8; min-height: 100vh; font-family: 'Inter', sans-serif; color: #1E1B16; }
    h1, h2, h3 { font-family: 'Fraunces', serif; color: #0F172A; }
    .mono { font-family: 'JetBrains Mono', monospace; }
    .card { background: #FFFFFF; border-radius: 13px; border: 1px solid rgba(15,23,42,0.12); padding: 1.5rem; }
    .grid-4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1.5rem; margin-bottom: 2rem; }
    .grid-23-13 { display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem; margin-bottom: 2rem; }
    .text-amber { color: #F5A623; }
    .text-green { color: #16A34A; }
    .text-red { color: #ef4444; }
    .text-slate { color: #475569; }
    .stat-title { font-size: 0.875rem; color: #475569; font-weight: 500; margin-bottom: 0.5rem; text-transform: uppercase; letter-spacing: 0.05em; }
    .stat-value { font-size: 2rem; font-weight: 700; }
    .stat-sub { font-size: 0.75rem; color: #64748b; margin-top: 0.25rem; }
    .bar-chart { display: flex; align-items: flex-end; height: 200px; gap: 10%; padding-top: 1rem; border-bottom: 1px solid rgba(15,23,42,0.12); }
    .bar-col { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: flex-end; }
    .bar { background-color: #F5A623; width: 100%; border-top-left-radius: 4px; border-top-right-radius: 4px; transition: height 0.3s ease; }
    .bar-label { margin-top: 0.5rem; font-size: 0.75rem; color: #475569; font-weight: 500; }
    .bar-value { font-size: 0.75rem; color: #0F172A; font-weight: 600; margin-bottom: 0.25rem; }
    .pending-list { list-style: none; padding: 0; margin: 0; }
    .pending-item { display: flex; justify-content: space-between; align-items: center; padding: 1rem 0; border-bottom: 1px solid rgba(15,23,42,0.06); }
    .pending-item:last-child { border-bottom: none; }
    .pending-info h4 { margin: 0 0 0.25rem 0; font-size: 0.95rem; font-family: 'Inter', sans-serif; }
    .pending-info p { margin: 0; font-size: 0.75rem; color: #64748b; }
    .btn-sm { padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 500; cursor: pointer; border: 1px solid transparent; }
    .btn-outline-green { border-color: #16A34A; color: #16A34A; background: transparent; }
    .btn-outline-red { border-color: #ef4444; color: #ef4444; background: transparent; }
    .table-wrapper { width: 100%; overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; text-align: left; }
    th { border-bottom: 2px solid rgba(15,23,42,0.12); padding: 1rem 0.5rem; color: #0F172A; font-weight: 600; font-size: 0.875rem; }
    td { border-bottom: 1px solid rgba(15,23,42,0.06); padding: 1rem 0.5rem; font-size: 0.875rem; vertical-align: middle; }
    tr:hover { background-color: #f8fafc; }
    .pill { display: inline-block; padding: 0.25rem 0.6rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 500; }
    .pill-green { background: #dcfce7; color: #16A34A; }
    .pill-amber { background: #fef3c7; color: #d97706; }
    .pill-red { background: #fee2e2; color: #ef4444; }
    .pill-slate { background: #f1f5f9; color: #475569; }
    .seller-tags { display: flex; flex-direction: column; gap: 4px; }
</style>
@endsection

@section('content')
<div class="page-wrapper">
    <h1 style="margin-bottom: 1.5rem;">Dashboard</h1>
    
    <div class="grid-4">
        <div class="card">
            <div class="stat-title">Total GMV</div>
            <div class="stat-value mono text-amber">₹48,72,340</div>
            <div class="stat-sub">all time</div>
        </div>
        <div class="card">
            <div class="stat-title">Active Sellers</div>
            <div class="stat-value mono text-green">142</div>
            <div class="stat-sub">across 12 categories</div>
        </div>
        <div class="card">
            <div class="stat-title">Pending Approvals</div>
            <div class="stat-value mono text-amber">7</div>
            <div class="stat-sub">awaiting review</div>
        </div>
        <div class="card">
            <div class="stat-title">Open Disputes</div>
            <div class="stat-value mono text-red">3</div>
            <div class="stat-sub">require attention</div>
        </div>
    </div>

    <div class="grid-23-13">
        <div class="card">
            <h2 style="font-size: 1.25rem; margin-bottom: 1rem; margin-top: 0;">GMV Trend (Last 6 Months)</h2>
            <div class="bar-chart">
                <div class="bar-col">
                    <div class="bar-value mono">₹6.2L</div>
                    <div class="bar" style="height: 45%;"></div>
                    <div class="bar-label">Jan</div>
                </div>
                <div class="bar-col">
                    <div class="bar-value mono">₹7.1L</div>
                    <div class="bar" style="height: 52%;"></div>
                    <div class="bar-label">Feb</div>
                </div>
                <div class="bar-col">
                    <div class="bar-value mono">₹8.4L</div>
                    <div class="bar" style="height: 62%;"></div>
                    <div class="bar-label">Mar</div>
                </div>
                <div class="bar-col">
                    <div class="bar-value mono">₹9.2L</div>
                    <div class="bar" style="height: 68%;"></div>
                    <div class="bar-label">Apr</div>
                </div>
                <div class="bar-col">
                    <div class="bar-value mono">₹10.8L</div>
                    <div class="bar" style="height: 80%;"></div>
                    <div class="bar-label">May</div>
                </div>
                <div class="bar-col">
                    <div class="bar-value mono">₹12.1L</div>
                    <div class="bar" style="height: 90%;"></div>
                    <div class="bar-label">Jun</div>
                </div>
            </div>
        </div>

        <div class="card">
            <h2 style="font-size: 1.25rem; margin-bottom: 1rem; margin-top: 0;">Pending Approvals</h2>
            <ul class="pending-list">
                <li class="pending-item">
                    <div class="pending-info">
                        <h4>Nordic Woodcraft</h4>
                        <p>Applied 24 Aug</p>
                    </div>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn-sm btn-outline-green">Approve</button>
                        <button class="btn-sm btn-outline-red">Reject</button>
                    </div>
                </li>
                <li class="pending-item">
                    <div class="pending-info">
                        <h4>Bloom & Petals Co.</h4>
                        <p>Applied 23 Aug</p>
                    </div>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn-sm btn-outline-green">Approve</button>
                        <button class="btn-sm btn-outline-red">Reject</button>
                    </div>
                </li>
                <li class="pending-item">
                    <div class="pending-info">
                        <h4>RetroTech Finds</h4>
                        <p>Applied 22 Aug</p>
                    </div>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn-sm btn-outline-green">Approve</button>
                        <button class="btn-sm btn-outline-red">Reject</button>
                    </div>
                </li>
                <li class="pending-item">
                    <div class="pending-info">
                        <h4>The Spice Garden</h4>
                        <p>Applied 21 Aug</p>
                    </div>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn-sm btn-outline-green">Approve</button>
                        <button class="btn-sm btn-outline-red">Reject</button>
                    </div>
                </li>
                <li class="pending-item">
                    <div class="pending-info">
                        <h4>UrbanThreads</h4>
                        <p>Applied 20 Aug</p>
                    </div>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn-sm btn-outline-green">Approve</button>
                        <button class="btn-sm btn-outline-red">Reject</button>
                    </div>
                </li>
                <li class="pending-item">
                    <div class="pending-info">
                        <h4>Crafty Hands Studio</h4>
                        <p>Applied 19 Aug</p>
                    </div>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn-sm btn-outline-green">Approve</button>
                        <button class="btn-sm btn-outline-red">Reject</button>
                    </div>
                </li>
                <li class="pending-item">
                    <div class="pending-info">
                        <h4>Mountain Brew Coffee</h4>
                        <p>Applied 18 Aug</p>
                    </div>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn-sm btn-outline-green">Approve</button>
                        <button class="btn-sm btn-outline-red">Reject</button>
                    </div>
                </li>
            </ul>
        </div>
    </div>

    <div class="card">
        <h2 style="font-size: 1.25rem; margin-bottom: 1rem; margin-top: 0;">Recent Orders</h2>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Sellers</th>
                        <th>Items</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="mono">#BZR-08471</td>
                        <td>Rahul S.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">Leather Workshop</span>
                                <span class="pill pill-slate">TechParts Direct</span>
                            </div>
                        </td>
                        <td>5 items</td>
                        <td class="mono">₹7,509</td>
                        <td><span class="pill pill-green">Delivered</span></td>
                        <td>25 Aug 2026</td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08472</td>
                        <td>Sneha M.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">Bloom & Co.</span>
                            </div>
                        </td>
                        <td>1 item</td>
                        <td class="mono">₹1,250</td>
                        <td><span class="pill pill-amber">Processing</span></td>
                        <td>25 Aug 2026</td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08473</td>
                        <td>Amit K.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">Heritage Spices</span>
                                <span class="pill pill-slate">Mountain Brews</span>
                                <span class="pill pill-slate">Nordic Woodcraft</span>
                            </div>
                        </td>
                        <td>8 items</td>
                        <td class="mono">₹12,400</td>
                        <td><span class="pill pill-amber">Shipped</span></td>
                        <td>24 Aug 2026</td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08474</td>
                        <td>Priya D.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">UrbanThreads</span>
                            </div>
                        </td>
                        <td>2 items</td>
                        <td class="mono">₹3,400</td>
                        <td><span class="pill pill-green">Delivered</span></td>
                        <td>24 Aug 2026</td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08475</td>
                        <td>Vikram P.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">TechParts Direct</span>
                            </div>
                        </td>
                        <td>1 item</td>
                        <td class="mono">₹45,000</td>
                        <td><span class="pill pill-red">Disputed</span></td>
                        <td>23 Aug 2026</td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08476</td>
                        <td>Neha J.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">Crafty Hands</span>
                                <span class="pill pill-slate">The Book Nook</span>
                            </div>
                        </td>
                        <td>4 items</td>
                        <td class="mono">₹2,100</td>
                        <td><span class="pill pill-green">Delivered</span></td>
                        <td>23 Aug 2026</td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08477</td>
                        <td>Rohan T.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">RetroGadgets</span>
                            </div>
                        </td>
                        <td>3 items</td>
                        <td class="mono">₹5,600</td>
                        <td><span class="pill pill-red">Cancelled</span></td>
                        <td>22 Aug 2026</td>
                    </tr>
                    <tr>
                        <td class="mono">#BZR-08478</td>
                        <td>Kavita L.</td>
                        <td>
                            <div class="seller-tags">
                                <span class="pill pill-slate">Heritage Spices</span>
                            </div>
                        </td>
                        <td>12 items</td>
                        <td class="mono">₹1,850</td>
                        <td><span class="pill pill-green">Delivered</span></td>
                        <td>22 Aug 2026</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
