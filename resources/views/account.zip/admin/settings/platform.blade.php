@extends('layouts.admin')

@section('title', 'Platform Settings')

@section('styles')
<style>
    .page-wrapper { margin-left: 220px; padding-top: 64px; padding-left: 2rem; padding-right: 2rem; padding-bottom: 2rem; background-color: #FFFDF8; min-height: 100vh; font-family: 'Inter', sans-serif; color: #1E1B16; }
    h1, h2, h3 { font-family: 'Fraunces', serif; color: #0F172A; margin-top: 0; }
    .card { background: #FFFFFF; border-radius: 13px; border: 1px solid rgba(15,23,42,0.12); padding: 1.5rem; margin-bottom: 1.5rem; }
    .card-danger { border-left: 4px solid #ef4444; }
    
    .badge-green { display: inline-block; background: #dcfce7; color: #16A34A; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 1rem; }
    
    .toggle-wrapper { display: flex; align-items: center; gap: 1rem; margin: 1.5rem 0 1rem 0; }
    .toggle-switch { position: relative; width: 60px; height: 32px; background-color: #16A34A; border-radius: 32px; cursor: pointer; transition: background-color 0.3s; }
    .toggle-switch::after { content: ''; position: absolute; top: 3px; left: 31px; width: 26px; height: 26px; background-color: white; border-radius: 50%; transition: left 0.3s; box-shadow: 0 2px 4px rgba(0,0,0,0.2); }
    .toggle-switch.off { background-color: #cbd5e1; }
    .toggle-switch.off::after { left: 3px; }
    .toggle-label { font-weight: 600; font-size: 1.125rem; color: #0F172A; }
    
    .warning-text { font-size: 0.875rem; color: #d97706; background: #fef3c7; padding: 1rem; border-radius: 8px; border-left: 3px solid #F5A623; line-height: 1.5; }
    .note-text { font-size: 0.875rem; color: #64748b; margin-top: 0.5rem; }
    
    .commission-display { font-family: 'JetBrains Mono', monospace; font-size: 3rem; font-weight: 700; color: #F5A623; margin: 1rem 0; }
    .input-group { display: flex; gap: 1rem; align-items: center; margin-bottom: 1rem; }
    .form-control { padding: 0.75rem 1rem; border: 1px solid rgba(15,23,42,0.12); border-radius: 8px; font-family: 'JetBrains Mono', monospace; font-size: 1rem; outline: none; width: 120px; text-align: center; }
    .form-control:focus { border-color: #F5A623; }
    
    .btn-amber { background: #F5A623; color: white; border-radius: 9999px; padding: 0.75rem 1.5rem; border: none; cursor: pointer; font-weight: 500; font-size: 1rem; font-family: 'Inter', sans-serif; }
    .btn-amber:hover { background: #d97706; }
</style>
@endsection

@section('content')
<div class="page-wrapper">
    <h1 style="margin-bottom: 1.5rem;">Platform Settings</h1>
    
    <div style="max-width: 800px;">
        <!-- Platform Mode Card -->
        <div class="card">
            <h2>Platform Mode</h2>
            <div class="badge-green">Multi-vendor</div>
            <p style="color: #475569; line-height: 1.5;">Currently, Bazaario is running in multi-vendor marketplace mode. This allows independent sellers to register, manage their own shops, and list products.</p>
            
            <div class="toggle-wrapper">
                <div class="toggle-switch"></div>
                <div class="toggle-label">Multi-vendor enabled</div>
            </div>
            
            <div class="warning-text">
                <strong>Warning:</strong> Switching to Single-vendor will hide the seller registration page, all seller badges, and flatten checkout to a single-seller display. No seller data is deleted from the database.
            </div>
        </div>

        <!-- Commission Rate Card -->
        <div class="card">
            <h2>Default Commission Rate</h2>
            <p style="color: #475569;">The percentage of each sale taken as the platform fee.</p>
            
            <div class="commission-display">8.0%</div>
            
            <div class="input-group">
                <input type="number" class="form-control" value="8.0" step="0.5" min="0" max="30">
                <button type="button" class="btn-amber">Save</button>
            </div>
            
            <p class="note-text">Note: Commission rate applies to all new orders. Existing orders are unaffected. Individual seller custom rates will override this default.</p>
        </div>

        <!-- Danger Zone Card -->
        <div class="card card-danger">
            <h2 style="color: #ef4444;">Maintenance Mode</h2>
            <p style="color: #475569; margin-bottom: 1.5rem;">Put the site into maintenance mode. Visitors will see the maintenance page instead of the storefront. Admin access remains active.</p>
            
            <div class="toggle-wrapper" style="margin: 0;">
                <div class="toggle-switch off"></div>
                <div class="toggle-label">Maintenance Mode Disabled</div>
            </div>
        </div>
    </div>
</div>

<script>
    // Simple toggle logic for visual feedback
    document.querySelectorAll('.toggle-switch').forEach(toggle => {
        toggle.addEventListener('click', function() {
            this.classList.toggle('off');
            const label = this.nextElementSibling;
            if(label.innerText.includes('Maintenance')) {
                label.innerText = this.classList.contains('off') ? 'Maintenance Mode Disabled' : 'Maintenance Mode Active';
                if(!this.classList.contains('off')) label.style.color = '#ef4444';
                else label.style.color = '#0F172A';
            } else {
                label.innerText = this.classList.contains('off') ? 'Single-vendor enabled' : 'Multi-vendor enabled';
            }
        });
    });
</script>
@endsection
