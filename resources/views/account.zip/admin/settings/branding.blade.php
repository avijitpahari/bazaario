@extends('layouts.admin')

@section('title', 'Branding Settings')

@section('styles')
<style>
    .page-wrapper { margin-left: 220px; padding-top: 64px; padding-left: 2rem; padding-right: 2rem; padding-bottom: 2rem; background-color: #FFFDF8; min-height: 100vh; font-family: 'Inter', sans-serif; color: #1E1B16; }
    h1, h2, h3 { font-family: 'Fraunces', serif; color: #0F172A; margin-top: 0; }
    .card { background: #FFFFFF; border-radius: 13px; border: 1px solid rgba(15,23,42,0.12); padding: 1.5rem; }
    .grid-55-45 { display: grid; grid-template-columns: 55% 45%; gap: 1.5rem; }
    
    .form-group { margin-bottom: 1.5rem; }
    .form-label { display: block; font-weight: 500; font-size: 0.875rem; margin-bottom: 0.5rem; color: #0F172A; }
    .form-control { width: 100%; box-sizing: border-box; padding: 0.75rem 1rem; border: 1px solid rgba(15,23,42,0.12); border-radius: 8px; font-family: 'Inter', sans-serif; font-size: 0.875rem; outline: none; transition: border-color 0.2s; }
    .form-control:focus { border-color: #F5A623; }
    
    .upload-zone { border: 2px dashed rgba(15,23,42,0.2); border-radius: 8px; padding: 2rem; text-align: center; background: #f8fafc; cursor: pointer; transition: all 0.2s; }
    .upload-zone:hover { border-color: #F5A623; background: #FFFDF8; }
    .upload-icon { font-size: 2rem; color: #cbd5e1; margin-bottom: 0.5rem; }
    .upload-text { font-size: 0.875rem; color: #475569; }
    
    .color-picker-wrap { display: flex; align-items: center; gap: 1rem; }
    .color-preview { width: 40px; height: 40px; border-radius: 8px; background-color: #F5A623; border: 1px solid rgba(15,23,42,0.12); }
    
    .btn-amber { background: #F5A623; color: white; border-radius: 9999px; padding: 0.75rem 1.5rem; border: none; cursor: pointer; font-weight: 500; font-size: 1rem; font-family: 'Inter', sans-serif; }
    .btn-amber:hover { background: #d97706; }
    
    .preview-card { position: sticky; top: 88px; }
    .preview-mockup { border: 1px solid rgba(15,23,42,0.12); border-radius: 8px; overflow: hidden; margin-top: 1rem; background: #f8fafc; }
    .preview-nav { background: #0F172A; color: white; padding: 1rem; display: flex; align-items: center; gap: 1rem; }
    .preview-logo-placeholder { width: 32px; height: 32px; background: #F5A623; border-radius: 4px; display: flex; align-items: center; justify-content: center; font-weight: bold; color: white; }
    .preview-brand-name { font-family: 'Fraunces', serif; font-size: 1.25rem; font-weight: 600; }
    .preview-body { padding: 2rem; }
    .preview-btn { background: #F5A623; color: white; padding: 0.5rem 1rem; border-radius: 9999px; display: inline-block; font-size: 0.875rem; font-weight: 500; }
    .preview-note { font-size: 0.75rem; color: #64748b; text-align: center; margin-top: 1rem; }
</style>
@endsection

@section('content')
<div class="page-wrapper">
    <h1 style="margin-bottom: 1.5rem;">Branding Settings</h1>
    
    <div class="grid-55-45">
        <div class="card">
            <form action="#" method="POST">
                <div class="form-group">
                    <label class="form-label">Site Name</label>
                    <input type="text" class="form-control" value="Bazaario" id="siteNameInput">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Tagline</label>
                    <input type="text" class="form-control" value="Your market, your rules." id="taglineInput">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Logo Upload (Primary)</label>
                    <div class="upload-zone">
                        <div class="upload-icon">🖼️</div>
                        <div class="upload-text">Drag and drop your logo here, or <strong>browse</strong></div>
                        <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 0.25rem;">Recommended: 200x50px PNG or SVG</div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Favicon Upload</label>
                    <div class="upload-zone" style="padding: 1rem;">
                        <div class="upload-text">Drag and drop icon here</div>
                        <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 0.25rem;">32x32px ICO or PNG</div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Primary Brand Color</label>
                    <div class="color-picker-wrap">
                        <div class="color-preview" id="colorPreview"></div>
                        <input type="text" class="form-control" value="#F5A623" style="width: 120px; font-family: 'JetBrains Mono', monospace;" id="colorInput">
                    </div>
                </div>
                
                <button type="button" class="btn-amber">Save Branding Settings</button>
            </form>
        </div>
        
        <div class="preview-card">
            <div class="card">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <h2 style="font-size: 1.125rem; margin: 0;">Live Preview</h2>
                    <span class="pill" style="background:#f1f5f9; font-size:0.75rem; padding: 0.25rem 0.5rem; border-radius: 4px;">Desktop</span>
                </div>
                
                <div class="preview-mockup">
                    <div class="preview-nav" id="previewNav">
                        <div class="preview-logo-placeholder" id="previewLogo">B</div>
                        <div class="preview-brand-name" id="previewName">Bazaario</div>
                    </div>
                    <div class="preview-body">
                        <h3 style="margin-top: 0; font-size: 1.5rem;" id="previewHero">Welcome to Bazaario</h3>
                        <p style="color: #475569; font-size: 0.875rem; margin-bottom: 1.5rem;" id="previewTagline">Your market, your rules.</p>
                        <div class="preview-btn" id="previewBtn">Shop Now</div>
                    </div>
                </div>
                
                <div class="preview-note">This preview updates automatically as you type.</div>
            </div>
        </div>
    </div>
</div>

<script>
    // Simple script to update preview (mock functionality for the blade file)
    document.getElementById('siteNameInput').addEventListener('input', function(e) {
        document.getElementById('previewName').textContent = e.target.value || 'Site Name';
        document.getElementById('previewHero').textContent = 'Welcome to ' + (e.target.value || 'Site Name');
        document.getElementById('previewLogo').textContent = (e.target.value || 'S').charAt(0).toUpperCase();
    });
    document.getElementById('taglineInput').addEventListener('input', function(e) {
        document.getElementById('previewTagline').textContent = e.target.value || 'Your tagline here';
    });
    document.getElementById('colorInput').addEventListener('input', function(e) {
        const color = e.target.value;
        document.getElementById('colorPreview').style.backgroundColor = color;
        document.getElementById('previewLogo').style.backgroundColor = color;
        document.getElementById('previewBtn').style.backgroundColor = color;
    });
</script>
@endsection
