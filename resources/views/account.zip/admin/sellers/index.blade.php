@extends('layouts.admin')

@section('title', 'All Sellers')

@section('styles')
<style>
    .page-wrapper { margin-left: 220px; padding-top: 64px; padding-left: 2rem; padding-right: 2rem; padding-bottom: 2rem; background-color: #FFFDF8; min-height: 100vh; font-family: 'Inter', sans-serif; color: #1E1B16; }
    h1, h2, h3 { font-family: 'Fraunces', serif; color: #0F172A; }
    .card { background: #FFFFFF; border-radius: 13px; border: 1px solid rgba(15,23,42,0.12); padding: 1.5rem; }
    .header-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
    .header-actions { display: flex; gap: 1rem; align-items: center; }
    .input-field, .select-field { padding: 0.5rem 1rem; border: 1px solid rgba(15,23,42,0.12); border-radius: 8px; font-family: 'Inter', sans-serif; font-size: 0.875rem; outline: none; }
    .input-field:focus, .select-field:focus { border-color: #F5A623; }
    .table-wrapper { width: 100%; overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; text-align: left; }
    th { border-bottom: 2px solid rgba(15,23,42,0.12); padding: 1rem 0.5rem; color: #0F172A; font-weight: 600; font-size: 0.875rem; }
    td { border-bottom: 1px solid rgba(15,23,42,0.06); padding: 1rem 0.5rem; font-size: 0.875rem; vertical-align: middle; }
    tr:hover { background-color: #f8fafc; }
    .pill { display: inline-block; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 500; }
    .pill-green { background: #dcfce7; color: #16A34A; }
    .pill-amber { background: #fef3c7; color: #d97706; }
    .pill-red { background: #fee2e2; color: #ef4444; }
    .action-link { color: #475569; text-decoration: none; font-weight: 500; font-size: 0.875rem; transition: color 0.2s; }
    .action-link:hover { color: #0F172A; text-decoration: underline; }
    .action-sep { color: #cbd5e1; margin: 0 0.25rem; }
    .mono { font-family: 'JetBrains Mono', monospace; }
    .pagination { display: flex; justify-content: flex-end; align-items: center; padding-top: 1.5rem; gap: 0.5rem; }
    .page-btn { padding: 0.4rem 0.75rem; border: 1px solid rgba(15,23,42,0.12); border-radius: 6px; background: #fff; cursor: pointer; font-size: 0.875rem; }
    .page-btn.active { background: #F5A623; border-color: #F5A623; color: #fff; }
    .page-btn:hover:not(.active) { background: #f8fafc; }
</style>
@endsection

@section('content')
<div class="page-wrapper">
    <div class="header-row">
        <h1 style="margin: 0;">All Sellers</h1>
        <div class="header-actions">
            <input type="text" class="input-field" placeholder="Search sellers...">
            <select class="select-field">
                <option value="all">Status: All</option>
                <option value="active">Active</option>
                <option value="pending">Pending</option>
                <option value="suspended">Suspended</option>
                <option value="rejected">Rejected</option>
            </select>
        </div>
    </div>
    
    <div class="card">
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Shop Name</th>
                        <th>Seller</th>
                        <th>Category</th>
                        <th>Products</th>
                        <th>Trust Score</th>
                        <th>Status</th>
                        <th>Joined</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>The Leather Workshop</strong></td>
                        <td>Rajesh K.</td>
                        <td>Accessories</td>
                        <td class="mono">138</td>
                        <td class="mono">96/100</td>
                        <td><span class="pill pill-green">Active</span></td>
                        <td>Jan 2024</td>
                        <td>
                            <a href="#" class="action-link">Suspend</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link">View</a>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>TechParts Direct</strong></td>
                        <td>Anita V.</td>
                        <td>Electronics</td>
                        <td class="mono">890</td>
                        <td class="mono">87/100</td>
                        <td><span class="pill pill-green">Active</span></td>
                        <td>Feb 2024</td>
                        <td>
                            <a href="#" class="action-link">Suspend</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link">View</a>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Heritage Spices</strong></td>
                        <td>Mohan G.</td>
                        <td>Food</td>
                        <td class="mono">210</td>
                        <td class="mono">94/100</td>
                        <td><span class="pill pill-green">Active</span></td>
                        <td>Mar 2024</td>
                        <td>
                            <a href="#" class="action-link">Suspend</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link">View</a>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Bloom & Co.</strong></td>
                        <td>Priya S.</td>
                        <td>Flowers</td>
                        <td class="mono">120</td>
                        <td class="mono">91/100</td>
                        <td><span class="pill pill-green">Active</span></td>
                        <td>Mar 2024</td>
                        <td>
                            <a href="#" class="action-link">Suspend</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link">View</a>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Nordic Woodcraft</strong></td>
                        <td>Erik L.</td>
                        <td>Home</td>
                        <td class="mono">45</td>
                        <td class="mono">—</td>
                        <td><span class="pill pill-amber">Pending</span></td>
                        <td>Aug 2024</td>
                        <td>
                            <a href="#" class="action-link" style="color: #16A34A;">Approve</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link" style="color: #ef4444;">Reject</a>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>UrbanThreads</strong></td>
                        <td>Meera K.</td>
                        <td>Fashion</td>
                        <td class="mono">67</td>
                        <td class="mono">78/100</td>
                        <td><span class="pill pill-green">Active</span></td>
                        <td>Apr 2024</td>
                        <td>
                            <a href="#" class="action-link">Suspend</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link">View</a>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Crafty Hands</strong></td>
                        <td>Sunita P.</td>
                        <td>Crafts</td>
                        <td class="mono">89</td>
                        <td class="mono">82/100</td>
                        <td><span class="pill pill-green">Active</span></td>
                        <td>May 2024</td>
                        <td>
                            <a href="#" class="action-link">Suspend</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link">View</a>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>RetroGadgets</strong></td>
                        <td>Vijay M.</td>
                        <td>Electronics</td>
                        <td class="mono">234</td>
                        <td class="mono">73/100</td>
                        <td><span class="pill pill-red">Suspended</span></td>
                        <td>Jun 2024</td>
                        <td>
                            <a href="#" class="action-link" style="color: #16A34A;">Reactivate</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link">View</a>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>The Book Nook</strong></td>
                        <td>Arjun S.</td>
                        <td>Books</td>
                        <td class="mono">156</td>
                        <td class="mono">88/100</td>
                        <td><span class="pill pill-green">Active</span></td>
                        <td>Jun 2024</td>
                        <td>
                            <a href="#" class="action-link">Suspend</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link">View</a>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Mountain Brews</strong></td>
                        <td>Kavita R.</td>
                        <td>Food</td>
                        <td class="mono">34</td>
                        <td class="mono">—</td>
                        <td><span class="pill pill-amber">Pending</span></td>
                        <td>Aug 2024</td>
                        <td>
                            <a href="#" class="action-link" style="color: #16A34A;">Approve</a>
                            <span class="action-sep">·</span>
                            <a href="#" class="action-link" style="color: #ef4444;">Reject</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="pagination">
            <button class="page-btn">Previous</button>
            <button class="page-btn active">1</button>
            <button class="page-btn">2</button>
            <button class="page-btn">3</button>
            <button class="page-btn">Next</button>
        </div>
    </div>
</div>
@endsection
