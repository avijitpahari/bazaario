@extends('layouts.admin')

@section('title', 'Seller Approvals')

@section('styles')
<style>
    .page-wrapper { margin-left: 220px; padding-top: 64px; padding-left: 2rem; padding-right: 2rem; padding-bottom: 2rem; background-color: #FFFDF8; min-height: 100vh; font-family: 'Inter', sans-serif; color: #1E1B16; }
    h1, h2, h3 { font-family: 'Fraunces', serif; color: #0F172A; }
    .card { background: #FFFFFF; border-radius: 13px; border: 1px solid rgba(15,23,42,0.12); padding: 1.5rem; }
    .header-row { display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem; }
    .badge-amber { background-color: #fef3c7; color: #d97706; padding: 0.25rem 0.75rem; border-radius: 9999px; font-weight: 600; font-size: 0.875rem; }
    .table-wrapper { width: 100%; overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; text-align: left; }
    th { border-bottom: 2px solid rgba(15,23,42,0.12); padding: 1rem 0.5rem; color: #0F172A; font-weight: 600; font-size: 0.875rem; }
    td { border-bottom: 1px solid rgba(15,23,42,0.06); padding: 1rem 0.5rem; font-size: 0.875rem; vertical-align: middle; }
    tr:hover { background-color: #f8fafc; }
    .btn-sm { padding: 0.4rem 0.8rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 500; cursor: pointer; border: 1px solid transparent; display: inline-block; text-decoration: none; text-align: center; }
    .btn-outline-green { border-color: #16A34A; color: #16A34A; background: transparent; }
    .btn-outline-green:hover { background: #16A34A; color: white; }
    .btn-outline-red { border-color: #ef4444; color: #ef4444; background: transparent; }
    .btn-outline-red:hover { background: #ef4444; color: white; }
    .text-link { color: #475569; text-decoration: none; font-weight: 500; margin-left: 0.5rem; font-size: 0.875rem; }
    .text-link:hover { text-decoration: underline; color: #0F172A; }
    .mono { font-family: 'JetBrains Mono', monospace; }
    
    /* 
    .empty-state { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 4rem 0; color: #475569; }
    .empty-icon { font-size: 3rem; color: #16A34A; margin-bottom: 1rem; }
    .empty-text { font-size: 1.125rem; font-weight: 500; }
    */
</style>
@endsection

@section('content')
<div class="page-wrapper">
    <div class="header-row">
        <h1 style="margin: 0;">Seller Approvals</h1>
        <span class="badge-amber">7 Pending</span>
    </div>
    
    <div class="card">
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Shop Name</th>
                        <th>Applicant</th>
                        <th>Category</th>
                        <th>Applied</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="mono">1</td>
                        <td><strong>Nordic Woodcraft</strong></td>
                        <td>Erik L.</td>
                        <td>Home & Furniture</td>
                        <td>1 day ago</td>
                        <td>
                            <button class="btn-sm btn-outline-green">Approve</button>
                            <button class="btn-sm btn-outline-red">Reject</button>
                            <a href="#" class="text-link">View Details</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="mono">2</td>
                        <td><strong>Bloom & Petals Co.</strong></td>
                        <td>Sarah J.</td>
                        <td>Flowers & Gifts</td>
                        <td>2 days ago</td>
                        <td>
                            <button class="btn-sm btn-outline-green">Approve</button>
                            <button class="btn-sm btn-outline-red">Reject</button>
                            <a href="#" class="text-link">View Details</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="mono">3</td>
                        <td><strong>RetroTech Finds</strong></td>
                        <td>Karan M.</td>
                        <td>Electronics</td>
                        <td>3 days ago</td>
                        <td>
                            <button class="btn-sm btn-outline-green">Approve</button>
                            <button class="btn-sm btn-outline-red">Reject</button>
                            <a href="#" class="text-link">View Details</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="mono">4</td>
                        <td><strong>The Spice Garden</strong></td>
                        <td>Anjali D.</td>
                        <td>Food & Gourmet</td>
                        <td>4 days ago</td>
                        <td>
                            <button class="btn-sm btn-outline-green">Approve</button>
                            <button class="btn-sm btn-outline-red">Reject</button>
                            <a href="#" class="text-link">View Details</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="mono">5</td>
                        <td><strong>UrbanThreads</strong></td>
                        <td>Rohit K.</td>
                        <td>Fashion</td>
                        <td>5 days ago</td>
                        <td>
                            <button class="btn-sm btn-outline-green">Approve</button>
                            <button class="btn-sm btn-outline-red">Reject</button>
                            <a href="#" class="text-link">View Details</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="mono">6</td>
                        <td><strong>Crafty Hands Studio</strong></td>
                        <td>Preeti V.</td>
                        <td>Art & Crafts</td>
                        <td>6 days ago</td>
                        <td>
                            <button class="btn-sm btn-outline-green">Approve</button>
                            <button class="btn-sm btn-outline-red">Reject</button>
                            <a href="#" class="text-link">View Details</a>
                        </td>
                    </tr>
                    <tr>
                        <td class="mono">7</td>
                        <td><strong>Mountain Brew Coffee</strong></td>
                        <td>Vikash R.</td>
                        <td>Beverages</td>
                        <td>1 week ago</td>
                        <td>
                            <button class="btn-sm btn-outline-green">Approve</button>
                            <button class="btn-sm btn-outline-red">Reject</button>
                            <a href="#" class="text-link">View Details</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <!-- 
        <div class="empty-state">
            <div class="empty-icon">✓</div>
            <div class="empty-text">All applications reviewed. Queue is clear!</div>
        </div> 
        -->
    </div>
</div>
@endsection
