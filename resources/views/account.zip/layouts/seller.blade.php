<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Seller Dashboard - Bazaario')</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,600;0,700;1,600;1,700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #0F172A;
            --accent: #F5A623;
            --secondary: #16A34A;
            --bg: #FFFDF8;
            --surface: #FFFFFF;
            --text: #1E1B16;
            --border: rgba(15,23,42,0.12);
            --radius: 13px;
            --radius-sm: 8px;
            --radius-pill: 9999px;
            --shadow: 0 1px 3px rgba(15,23,42,0.08), 0 1px 2px rgba(15,23,42,0.06);
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); color:var(--text); font-family:'Inter',sans-serif; font-size:15px; line-height:1.6; display: flex; min-height: 100vh; }
        h1,h2,h3,h4,h5 { font-family:'Fraunces',serif; color:var(--primary); line-height:1.2; margin-bottom: 0.5em; }
        .mono { font-family:'JetBrains Mono',monospace; }
        a { color: inherit; text-decoration: none; }
        
        .seller-rail { width: 64px; background: var(--primary); display: flex; flex-direction: column; align-items: center; padding-top: 24px; position: fixed; top: 0; bottom: 0; left: 0; z-index: 50; }
        .rail-item { width: 100%; height: 56px; display: flex; align-items: center; justify-content: center; color: rgba(255,255,255,0.7); border-left: 3px solid transparent; transition: all 0.2s; position: relative; cursor: pointer; margin-bottom: 8px; }
        .rail-item:hover { color: white; background: rgba(255,255,255,0.05); }
        .rail-item.active { border-left-color: var(--accent); color: var(--accent); background: rgba(255,255,255,0.1); }
        .rail-item svg { width: 24px; height: 24px; }
        .rail-item .tooltip { position: absolute; left: 70px; background: var(--primary); color: white; padding: 4px 10px; border-radius: 4px; font-size: 12px; pointer-events: none; opacity: 0; transition: opacity 0.2s; white-space: nowrap; z-index: 100; box-shadow: var(--shadow); }
        .rail-item:hover .tooltip { opacity: 1; }
        
        .main-wrapper { margin-left: 64px; flex: 1; display: flex; flex-direction: column; }
        
        .top-bar { height: 64px; background: var(--surface); border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; padding: 0 32px; position: sticky; top: 0; z-index: 40; }
        .shop-info { display: flex; align-items: center; gap: 12px; }
        .shop-name { font-weight: 600; color: var(--primary); }
        .verified-badge { display: inline-flex; align-items: center; gap: 4px; background: #dcfce7; color: #15803d; padding: 4px 10px; border-radius: var(--radius-pill); font-size: 12px; font-weight: 600; }
        .verified-badge svg { width: 14px; height: 14px; }
        
        .top-actions { display: flex; align-items: center; gap: 20px; }
        .icon-btn { background: none; border: none; cursor: pointer; color: var(--primary); position: relative; display: flex; align-items: center; justify-content: center; }
        .icon-btn svg { width: 20px; height: 20px; }
        .notification-dot { position: absolute; top: -2px; right: -2px; width: 8px; height: 8px; background: var(--accent); border-radius: 50%; }
        
        .avatar { width: 36px; height: 36px; border-radius: 50%; background: var(--primary); color: white; display: flex; align-items: center; justify-content: center; font-weight: 600; font-size: 14px; cursor: pointer; }
        
        .content-area { padding: 32px; flex: 1; }
        
        .card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow); }
    </style>
    @yield('styles')
</head>
<body>
    <nav class="seller-rail">
        <a href="/seller/dashboard" class="rail-item active">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>
            <span class="tooltip">Dashboard</span>
        </a>
        <a href="/seller/products" class="rail-item">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path></svg>
            <span class="tooltip">Products</span>
        </a>
        <a href="/seller/orders" class="rail-item">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path></svg>
            <span class="tooltip">Orders</span>
        </a>
        <a href="/seller/payouts" class="rail-item">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span class="tooltip">Payouts</span>
        </a>
        <a href="/seller/settings" class="rail-item">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
            <span class="tooltip">Settings</span>
        </a>
    </nav>

    <div class="main-wrapper">
        <header class="top-bar">
            <div class="shop-info">
                <span class="shop-name">Artisan Goods Co.</span>
                <span class="verified-badge">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    Verified Stall
                </span>
            </div>
            <div class="top-actions">
                <button class="icon-btn">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
                    <span class="notification-dot"></span>
                </button>
                <div class="avatar">AG</div>
            </div>
        </header>

        <main class="content-area">
            @yield('content')
        </main>
    </div>

    @yield('scripts')
</body>
</html>
