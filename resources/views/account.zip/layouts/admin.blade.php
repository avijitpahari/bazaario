<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Admin Panel - Bazaario')</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,600;0,700;1,600;1,700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #0F172A;
            --accent: #F5A623;
            --secondary: #16A34A;
            --bg: #FFFDF8;
            --surface: #FFFFFF;
            --text: #1E1B16;
            --border: rgba(15,23,42,0.12);
            --radius: 13px;
            --radius-sm: 8px;
            --radius-pill: 9999px;
            --shadow: 0 1px 3px rgba(15,23,42,0.08), 0 1px 2px rgba(15,23,42,0.06);
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); color:var(--text); font-family:'Inter',sans-serif; font-size:15px; line-height:1.6; display: flex; min-height: 100vh; }
        h1,h2,h3,h4,h5 { font-family:'Fraunces',serif; color:var(--primary); line-height:1.2; margin-bottom: 0.5em; }
        .mono { font-family:'JetBrains Mono',monospace; }
        a { color: inherit; text-decoration: none; }
        
        .admin-sidebar { width: 220px; background: var(--primary); display: flex; flex-direction: column; color: #FFFDF8; position: fixed; top: 0; bottom: 0; left: 0; z-index: 50; }
        .sidebar-brand { padding: 24px; font-family: 'Fraunces', serif; font-size: 20px; font-weight: 700; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 16px; }
        .nav-link { display: flex; align-items: center; gap: 12px; padding: 12px 24px; color: rgba(255,255,255,0.7); border-left: 3px solid transparent; transition: all 0.2s; font-weight: 500; }
        .nav-link:hover { color: white; background: rgba(255,255,255,0.05); }
        .nav-link.active { border-left-color: var(--accent); color: white; background: rgba(255,255,255,0.1); }
        .nav-link svg { width: 20px; height: 20px; }
        
        .main-wrapper { margin-left: 220px; flex: 1; display: flex; flex-direction: column; }
        
        .top-bar { height: 64px; background: var(--surface); border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; padding: 0 32px; position: sticky; top: 0; z-index: 40; }
        .breadcrumb { font-weight: 600; color: var(--primary); font-size: 16px; }
        
        .admin-profile { display: flex; align-items: center; gap: 12px; }
        .admin-name { font-weight: 500; font-size: 14px; }
        .avatar { width: 32px; height: 32px; border-radius: 50%; background: var(--accent); color: var(--primary); display: flex; align-items: center; justify-content: center; font-weight: 600; font-size: 13px; cursor: pointer; }
        
        .content-area { padding: 32px; flex: 1; }
        
        .card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow); }
    </style>
    @yield('styles')
</head>
<body>
    <aside class="admin-sidebar">
        <div class="sidebar-brand">Bazaario Admin</div>
        <nav>
            <a href="/admin/overview" class="nav-link active">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                Overview
            </a>
            <a href="/admin/sellers" class="nav-link">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                Sellers
            </a>
            <a href="/admin/orders" class="nav-link">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>
                Orders
            </a>
            <a href="/admin/categories" class="nav-link">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"></path></svg>
                Categories
            </a>
            <a href="/admin/reports" class="nav-link">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                Reports
            </a>
            <a href="/admin/settings" class="nav-link">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                Settings
            </a>
        </nav>
    </aside>

    <div class="main-wrapper">
        <header class="top-bar">
            <div class="breadcrumb">Admin Panel</div>
            <div class="admin-profile">
                <span class="admin-name">Platform Admin</span>
                <div class="avatar">PA</div>
            </div>
        </header>

        <main class="content-area">
            @yield('content')
        </main>
    </div>

    @yield('scripts')
</body>
</html>
