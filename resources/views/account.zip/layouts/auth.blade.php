<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Authentication - Bazaario')</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,600;0,700;1,600;1,700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #0F172A;
            --accent: #F5A623;
            --secondary: #16A34A;
            --bg: #FFFDF8;
            --surface: #FFFFFF;
            --text: #1E1B16;
            --border: rgba(15,23,42,0.12);
            --radius: 13px;
            --radius-sm: 8px;
            --radius-pill: 9999px;
            --shadow: 0 1px 3px rgba(15,23,42,0.08), 0 1px 2px rgba(15,23,42,0.06);
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); color:var(--text); font-family:'Inter',sans-serif; font-size:15px; line-height:1.6; display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 24px; }
        h1,h2,h3,h4,h5 { font-family:'Fraunces',serif; color:var(--primary); line-height:1.2; margin-bottom: 0.5em; }
        a { color: inherit; text-decoration: none; }
        
        .auth-container { width: 100%; max-width: 440px; }
        
        .card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 40px; box-shadow: var(--shadow); }
        
        .brand { text-align: center; margin-bottom: 32px; display: block; font-family: 'Fraunces', serif; font-size: 28px; font-weight: 700; color: var(--primary); }
        
        .btn-primary { background: var(--primary); color: white; border: none; padding: 12px 24px; border-radius: var(--radius); font-weight: 500; cursor: pointer; display: flex; width: 100%; align-items: center; justify-content: center; transition: background 0.2s; font-size: 16px; margin-top: 24px; }
        .btn-primary:hover { background: #1e293b; }
        
        .input-group { margin-bottom: 20px; }
        .label { display: block; font-size: 14px; font-weight: 500; color: var(--primary); margin-bottom: 8px; }
        .input { width: 100%; padding: 12px 16px; border: 1px solid var(--border); border-radius: var(--radius-sm); font-family: 'Inter', sans-serif; font-size: 15px; outline: none; transition: border-color 0.2s; background: var(--surface); }
        .input:focus { border-color: var(--accent); }
    </style>
    @yield('styles')
</head>
<body style="background:var(--bg);">
    <div class="auth-container">
        <a href="/" class="brand">Bazaario</a>
        @yield('content')
    </div>
    @yield('scripts')
</body>
</html>
