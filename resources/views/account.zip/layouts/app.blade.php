<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Bazaario — The Open Market')</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,600;0,700;1,600;1,700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #0F172A;
            --accent: #F5A623;
            --secondary: #16A34A;
            --bg: #FFFDF8;
            --surface: #FFFFFF;
            --text: #1E1B16;
            --border: rgba(15,23,42,0.12);
            --radius: 13px;
            --radius-sm: 8px;
            --radius-pill: 9999px;
            --shadow: 0 1px 3px rgba(15,23,42,0.08), 0 1px 2px rgba(15,23,42,0.06);
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); color:var(--text); font-family:'Inter',sans-serif; font-size:15px; line-height:1.6; }
        h1,h2,h3,h4,h5 { font-family:'Fraunces',serif; color:var(--primary); line-height:1.2; margin-bottom: 0.5em; }
        .mono { font-family:'JetBrains Mono',monospace; }
        
        a { color: inherit; text-decoration: none; }
        
        .container { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
        .section { padding: 64px 0; }
        
        .btn-primary { background: var(--primary); color: white; border: none; padding: 10px 20px; border-radius: var(--radius); font-weight: 500; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; transition: background 0.2s; }
        .btn-primary:hover { background: #1e293b; }
        
        .btn-secondary { background: var(--surface); color: var(--primary); border: 1px solid var(--border); padding: 10px 20px; border-radius: var(--radius); font-weight: 500; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; transition: background 0.2s; }
        .btn-secondary:hover { background: #f8fafc; }
        
        .card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow); }
        
        .badge { display: inline-flex; align-items: center; padding: 4px 10px; border-radius: var(--radius-sm); font-size: 12px; font-weight: 600; }
        .badge-amber { background: #fef3c7; color: #b45309; }
        .badge-green { background: #dcfce7; color: #15803d; }
        .badge-red { background: #fee2e2; color: #b91c1c; }
        .badge-slate { background: #f1f5f9; color: #475569; }
        
        .pill { display: inline-flex; align-items: center; padding: 6px 16px; border-radius: var(--radius-pill); background: var(--surface); border: 1px solid var(--border); font-size: 14px; font-weight: 500; }
        
        .input { width: 100%; padding: 10px 14px; border: 1px solid var(--border); border-radius: var(--radius-sm); font-family: 'Inter', sans-serif; font-size: 15px; outline: none; transition: border-color 0.2s; background: var(--surface); }
        .input:focus { border-color: var(--accent); }
        
        .label { display: block; font-size: 14px; font-weight: 500; color: var(--primary); margin-bottom: 6px; }
        
        .divider { height: 1px; background: var(--border); margin: 24px 0; }
        
        .tag { display: inline-flex; align-items: center; background: rgba(15,23,42,0.05); padding: 4px 12px; border-radius: var(--radius-pill); font-size: 13px; color: var(--primary); }
    </style>
    @yield('styles')
</head>
<body>
    @include('partials.nav')
    <main>
        @yield('content')
    </main>
    @include('partials.footer')
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
            const mobileMenu = document.getElementById('mobile-menu');
            if(mobileMenuToggle && mobileMenu) {
                mobileMenuToggle.addEventListener('click', function() {
                    mobileMenu.style.display = mobileMenu.style.display === 'block' ? 'none' : 'block';
                });
            }
        });
    </script>
    @yield('scripts')
</body>
</html>
